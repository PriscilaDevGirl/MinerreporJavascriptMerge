/*!
 * reveal.js 2.1 r30
 * http://lab.hakim.se/reveal-js
 * MIT licensed
 * 
 * Copyright (C) 2011-2012 Hakim El Hattab, http://hakim.se
 */
var Reveal=(function(){var l=".reveal .slides>section",b=".reveal .slides>section.present>section",R={controls:true,progress:true,history:false,keyboard:true,overview:true,loop:false,autoSlide:0,mouseWheel:true,rollingLinks:true,theme:null,transition:"default",dependencies:[]},m=0,e=0,y,G,ah=[],f={},T="WebkitPerspective" in document.body.style||"MozPerspective" in document.body.style||"msPerspective" in document.body.style||"OPerspective" in document.body.style||"perspective" in document.body.style,n="WebkitTransform" in document.body.style||"MozTransform" in document.body.style||"msTransform" in document.body.style||"OTransform" in document.body.style||"transform" in document.body.style,z=0,k=0,C=0,aa={startX:0,startY:0,startSpan:0,startCount:0,handled:false,threshold:40};
function i(ai){if((!n&&!T)){document.body.setAttribute("class","no-transforms");return;}t(R,ai);P();d();V();}function P(){f.theme=document.querySelector("#theme");
f.wrapper=document.querySelector(".reveal");if(!f.wrapper.querySelector(".progress")&&R.progress){var al=document.createElement("div");al.classList.add("progress");
al.innerHTML="<span></span>";f.wrapper.appendChild(al);}if(!f.wrapper.querySelector(".controls")&&R.controls){var ak=document.createElement("aside");ak.classList.add("controls");
ak.innerHTML='<a class="left" href="#">&#x25C4;</a><a class="right" href="#">&#x25BA;</a><a class="up" href="#">&#x25B2;</a><a class="down" href="#">&#x25BC;</a>';
f.wrapper.appendChild(ak);}if(!f.wrapper.querySelector(".state-background")){var aj=document.createElement("div");aj.classList.add("state-background");
f.wrapper.appendChild(aj);}if(!f.wrapper.querySelector(".pause-overlay")){var ai=document.createElement("div");ai.classList.add("pause-overlay");f.wrapper.appendChild(ai);
}f.progress=document.querySelector(".reveal .progress");f.progressbar=document.querySelector(".reveal .progress span");if(R.controls){f.controls=document.querySelector(".reveal .controls");
f.controlsLeft=document.querySelector(".reveal .controls .left");f.controlsRight=document.querySelector(".reveal .controls .right");f.controlsUp=document.querySelector(".reveal .controls .up");
f.controlsDown=document.querySelector(".reveal .controls .down");}}function d(){if(navigator.userAgent.match(/(iphone|ipod|android)/i)){document.documentElement.style.overflow="scroll";
document.body.style.height="120%";window.addEventListener("load",ab,false);window.addEventListener("orientationchange",ab,false);}}function V(){var aj=[],an=[];
for(var ak=0,ai=R.dependencies.length;ak<ai;ak++){var al=R.dependencies[ak];if(!al.condition||al.condition()){if(al.async){an.push(al.src);}else{aj.push(al.src);
}if(typeof al.callback==="function"){head.ready(al.src.match(/([\w\d_\-]*)\.?[^\\\/]*$/i)[0],al.callback);}}}function am(){head.js.apply(null,an);H();}if(aj.length){head.ready(am);
head.js.apply(null,aj);}else{am();}}function H(){E();K();J();N();}function K(){if(T===false){R.transition="linear";}if(R.controls&&f.controls){f.controls.style.display="block";
}if(R.progress&&f.progress){f.progress.style.display="block";}if(R.theme&&f.theme){var ak=f.theme.getAttribute("href");var ai=/[^\/]*?(?=\.css)/;var aj=ak.match(ai)[0];
if(R.theme!==aj){ak=ak.replace(ai,R.theme);f.theme.setAttribute("href",ak);}}if(R.transition!=="default"){f.wrapper.classList.add(R.transition);}if(R.mouseWheel){document.addEventListener("DOMMouseScroll",p,false);
document.addEventListener("mousewheel",p,false);}if(R.rollingLinks){M();}}function E(){document.addEventListener("touchstart",A,false);document.addEventListener("touchmove",ad,false);
document.addEventListener("touchend",W,false);window.addEventListener("hashchange",w,false);if(R.keyboard){document.addEventListener("keydown",af,false);
}if(R.controls&&f.controls){f.controlsLeft.addEventListener("click",q(B),false);f.controlsRight.addEventListener("click",q(j),false);f.controlsUp.addEventListener("click",q(u),false);
f.controlsDown.addEventListener("click",q(F),false);}}function U(){document.removeEventListener("keydown",af,false);document.removeEventListener("touchstart",A,false);
document.removeEventListener("touchmove",ad,false);document.removeEventListener("touchend",W,false);window.removeEventListener("hashchange",w,false);if(R.controls&&f.controls){f.controlsLeft.removeEventListener("click",q(B),false);
f.controlsRight.removeEventListener("click",q(j),false);f.controlsUp.removeEventListener("click",q(u),false);f.controlsDown.removeEventListener("click",q(F),false);
}}function t(aj,ai){for(var ak in ai){aj[ak]=ai[ak];}}function S(ak,ai){var al=ak.x-ai.x,aj=ak.y-ai.y;return Math.sqrt(al*al+aj*aj);}function q(ai){return function(aj){aj.preventDefault();
ai.call();};}function ab(){setTimeout(function(){window.scrollTo(0,1);},0);}function r(aj,ai){var ak=document.createEvent("HTMLEvents",1,2);ak.initEvent(aj,true,true);
t(ak,ai);f.wrapper.dispatchEvent(ak);}function af(aj){if(document.querySelector(":focus")!==null||aj.shiftKey||aj.altKey||aj.ctrlKey||aj.metaKey){return;
}var ai=true;switch(aj.keyCode){case 80:case 33:Y();break;case 78:case 34:x();break;case 72:case 37:B();break;case 76:case 39:j();break;case 75:case 38:u();
break;case 74:case 40:F();break;case 36:O(0);break;case 35:O(Number.MAX_VALUE);break;case 32:L()?ac():x();break;case 13:L()?ac():ai=false;break;case 66:case 190:Z();
break;default:ai=false;}if(ai){aj.preventDefault();}else{if(aj.keyCode===27&&T){X();aj.preventDefault();}}N();}function A(ai){aa.startX=ai.touches[0].clientX;
aa.startY=ai.touches[0].clientY;aa.startCount=ai.touches.length;if(ai.touches.length===2){aa.startSpan=S({x:ai.touches[1].clientX,y:ai.touches[1].clientY},{x:aa.startX,y:aa.startY});
}}function ad(an){if(!aa.handled){var al=an.touches[0].clientX;var ak=an.touches[0].clientY;if(an.touches.length===2&&aa.startCount===2){var am=S({x:an.touches[1].clientX,y:an.touches[1].clientY},{x:aa.startX,y:aa.startY});
if(Math.abs(aa.startSpan-am)>aa.threshold){aa.handled=true;if(am<aa.startSpan){I();}else{ac();}}}else{if(an.touches.length===1){var aj=al-aa.startX,ai=ak-aa.startY;
if(aj>aa.threshold&&Math.abs(aj)>Math.abs(ai)){aa.handled=true;B();}else{if(aj<-aa.threshold&&Math.abs(aj)>Math.abs(ai)){aa.handled=true;j();}else{if(ai>aa.threshold){aa.handled=true;
u();}else{if(ai<-aa.threshold){aa.handled=true;F();}}}}}}an.preventDefault();}else{if(navigator.userAgent.match(/android/gi)){an.preventDefault();}}}function W(ai){aa.handled=false;
}function p(ai){clearTimeout(z);z=setTimeout(function(){var aj=ai.detail||-ai.wheelDelta;if(aj>0){x();}else{Y();}},100);}function w(ai){J();}function D(ai){if(L()){ai.preventDefault();
ac();m=this.getAttribute("data-index-h");e=this.getAttribute("data-index-v");a();}}function M(){if(T&&!("msPerspective" in document.body.style)){var aj=document.querySelectorAll(".reveal .slides section a:not(.image)");
for(var ak=0,ai=aj.length;ak<ai;ak++){var al=aj[ak];if(al.textContent&&!al.querySelector("img")&&(!al.className||!al.classList.contains(al,"roll"))){al.classList.add("roll");
al.innerHTML='<span data-title="'+al.text+'">'+al.innerHTML+"</span>";}}}}function I(){if(R.overview){f.wrapper.classList.add("overview");var ai=document.querySelectorAll(l);
for(var an=0,al=ai.length;an<al;an++){var ak=ai[an],ar="translateZ(-2500px) translate("+((an-m)*105)+"%, 0%)";ak.setAttribute("data-index-h",an);ak.style.display="block";
ak.style.WebkitTransform=ar;ak.style.MozTransform=ar;ak.style.msTransform=ar;ak.style.OTransform=ar;ak.style.transform=ar;if(!ak.classList.contains("stack")){ak.addEventListener("click",D,true);
}var aq=ak.querySelectorAll("section");for(var am=0,aj=aq.length;am<aj;am++){var ap=aq[am],ao="translate(0%, "+((am-(an===m?e:0))*105)+"%)";ap.setAttribute("data-index-h",an);
ap.setAttribute("data-index-v",am);ap.style.display="block";ap.style.WebkitTransform=ao;ap.style.MozTransform=ao;ap.style.msTransform=ao;ap.style.OTransform=ao;
ap.style.transform=ao;ap.addEventListener("click",D,true);}}}}function ac(){if(R.overview){f.wrapper.classList.remove("overview");var al=Array.prototype.slice.call(document.querySelectorAll(".reveal .slides section"));
for(var ak=0,ai=al.length;ak<ai;ak++){var aj=al[ak];aj.style.WebkitTransform="";aj.style.MozTransform="";aj.style.msTransform="";aj.style.OTransform="";
aj.style.transform="";aj.removeEventListener("click",D);}a();}}function X(ai){if(typeof ai==="boolean"){ai?I():ac();}else{L()?ac():I();}}function L(){return f.wrapper.classList.contains("overview");
}function c(){f.wrapper.classList.add("paused");}function o(){f.wrapper.classList.remove("paused");}function Z(){if(ae()){o();}else{c();}}function ae(){return f.wrapper.classList.contains("paused");
}function ag(aj,al){var an=Array.prototype.slice.call(document.querySelectorAll(aj)),ao=an.length;if(ao){if(R.loop){al%=ao;if(al<0){al=ao+al;}}al=Math.max(Math.min(al,ao-1),0);
for(var am=0;am<ao;am++){var ai=an[am];if(L()===false){var ap=Math.abs((al-am)%(ao-3))||0;ai.style.display=ap>3?"none":"block";}an[am].classList.remove("past");
an[am].classList.remove("present");an[am].classList.remove("future");if(am<al){an[am].classList.add("past");}else{if(am>al){an[am].classList.add("future");
}}if(ai.querySelector("section")){an[am].classList.add("stack");}}an[al].classList.add("present");var ak=an[al].getAttribute("data-state");if(ak){ah=ah.concat(ak.split(" "));
}}else{al=0;}return al;}function a(ao,at){y=G;var al=ah.concat();ah.length=0;var ar=m,aj=e;m=ag(l,ao===undefined?m:ao);e=ag(b,at===undefined?e:at);stateLoop:for(var am=0,ap=ah.length;
am<ap;am++){for(var ak=0;ak<al.length;ak++){if(al[ak]===ah[am]){al.splice(ak,1);continue stateLoop;}}document.documentElement.classList.add(ah[am]);r(ah[am]);
}while(al.length){document.documentElement.classList.remove(al.pop());}if(R.progress&&f.progress){f.progressbar.style.width=(m/(document.querySelectorAll(l).length-1))*window.innerWidth+"px";
}if(L()){I();}s();clearTimeout(C);C=setTimeout(h,1500);var ai=document.querySelectorAll(l);var aq=ai[m],an=aq.querySelectorAll("section");G=an[e]||aq;if(m!==ar||e!==aj){r("slidechanged",{indexh:m,indexv:e,previousSlide:y,currentSlide:G});
}else{y=null;}if(y){y.classList.remove("present");}}function s(){if(!R.controls||!f.controls){return;}var ai=g();[f.controlsLeft,f.controlsRight,f.controlsUp,f.controlsDown].forEach(function(aj){aj.classList.remove("enabled");
});if(ai.left){f.controlsLeft.classList.add("enabled");}if(ai.right){f.controlsRight.classList.add("enabled");}if(ai.up){f.controlsUp.classList.add("enabled");
}if(ai.down){f.controlsDown.classList.add("enabled");}}function g(){var ai=document.querySelectorAll(l),aj=document.querySelectorAll(b);return{left:m>0,right:m<ai.length-1,up:e>0,down:e<aj.length-1};
}function J(){var an=window.location.hash;var am=an.slice(2).split("/"),ak=an.replace(/#|\//gi,"");if(isNaN(parseInt(am[0],10))&&ak.length){var ai=document.querySelector("#"+ak);
if(ai){var ao=Reveal.getIndices(ai);O(ao.h,ao.v);}else{O(m,e);}}else{var al=parseInt(am[0],10)||0,aj=parseInt(am[1],10)||0;O(al,aj);}}function h(){if(R.history){var ai="/";
if(m>0||e>0){ai+=m;}if(e>0){ai+="/"+e;}window.location.hash=ai;}}function v(){if(document.querySelector(b+".present")){var aj=document.querySelectorAll(b+".present .fragment:not(.visible)");
if(aj.length){aj[0].classList.add("visible");r("fragmentshown",{fragment:aj[0]});return true;}}else{var ai=document.querySelectorAll(l+".present .fragment:not(.visible)");
if(ai.length){ai[0].classList.add("visible");r("fragmentshown",{fragment:ai[0]});return true;}}return false;}function Q(){if(document.querySelector(b+".present")){var aj=document.querySelectorAll(b+".present .fragment.visible");
if(aj.length){aj[aj.length-1].classList.remove("visible");r("fragmenthidden",{fragment:aj[aj.length-1]});return true;}}else{var ai=document.querySelectorAll(l+".present .fragment.visible");
if(ai.length){ai[ai.length-1].classList.remove("visible");r("fragmenthidden",{fragment:ai[ai.length-1]});return true;}}return false;}function N(){clearTimeout(k);
if(R.autoSlide){k=setTimeout(x,R.autoSlide);}}function O(aj,ai){a(aj,ai);}function B(){if(L()||Q()===false){a(m-1,0);}}function j(){if(L()||v()===false){a(m+1,0);
}}function u(){if(L()||Q()===false){a(m,e-1);}}function F(){if(L()||v()===false){a(m,e+1);}}function Y(){if(Q()===false){if(g().up){u();}else{var ai=document.querySelector(".reveal .slides>section.past:nth-child("+m+")");
if(ai){e=(ai.querySelectorAll("section").length+1)||0;m--;a();}}}}function x(){if(v()===false){g().down?F():j();}N();}return{initialize:i,navigateTo:O,navigateLeft:B,navigateRight:j,navigateUp:u,navigateDown:F,navigatePrev:Y,navigateNext:x,toggleOverview:X,addEventListeners:E,removeEventListeners:U,getIndices:function(ai){var am=m,ak=e;
if(ai){var an=!!ai.parentNode.nodeName.match(/section/gi);var al=an?ai.parentNode:ai;var aj=Array.prototype.slice.call(document.querySelectorAll(l));am=Math.max(aj.indexOf(al),0);
if(an){ak=Math.max(Array.prototype.slice.call(ai.parentNode.children).indexOf(ai),0);}}return{h:am,v:ak};},getPreviousSlide:function(){return y;},getCurrentSlide:function(){return G;
},getQueryHash:function(){var ai={};location.search.replace(/[A-Z0-9]+?=(\w*)/gi,function(aj){ai[aj.split("=").shift()]=aj.split("=").pop();});return ai;
},addEventListener:function(aj,ak,ai){if("addEventListener" in window){(f.wrapper||document.querySelector(".reveal")).addEventListener(aj,ak,ai);}},removeEventListener:function(aj,ak,ai){if("addEventListener" in window){(f.wrapper||document.querySelector(".reveal")).removeEventListener(aj,ak,ai);
}}};})();