console.log('server/main.js loaded');
