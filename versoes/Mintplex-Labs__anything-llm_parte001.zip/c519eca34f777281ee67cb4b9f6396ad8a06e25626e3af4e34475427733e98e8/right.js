// Anything with "null" requires a translation. Contribute to translation via a PR!
const TRANSLATIONS = {
  onboarding: {
    home: {
      getStarted: "להתחלה",
      welcome: "ברוכים הבאים",
    },
    llm: {
      title: "העדפות מודל שפה (LLM)",
      description:
        "AnythingLLM יכול לעבוד עם ספקי מודלי שפה (LLM) רבים. זה יהיה השירות שיטפל בצ'אט.",
    },
    userSetup: {
      title: "הגדרת משתמש",
      description: "הגדר את הגדרות המשתמש שלך.",
      howManyUsers: "כמה משתמשים ישתמשו במופע זה?",
      justMe: "רק אני",
      myTeam: "הצוות שלי",
      instancePassword: "סיסמת מופע",
      setPassword: "האם תרצה להגדיר סיסמה?",
      passwordReq: "סיסמאות חייבות להכיל לפחות 8 תווים.",
      passwordWarn: "חשוב לשמור סיסמה זו מכיוון שאין שיטת שחזור.",
      adminUsername: "שם משתמש של חשבון מנהל",
      adminPassword: "סיסמת חשבון מנהל",
      adminPasswordReq: "סיסמאות חייבות להכיל לפחות 8 תווים.",
      teamHint:
        "כברירת מחדל, אתה תהיה המנהל היחיד. לאחר סיום ההצטרפות תוכל ליצור ולהזמין אחרים להיות משתמשים או מנהלים. אל תאבד את סיסמתך, מכיוון שרק מנהלים יכולים לאפס סיסמאות.",
    },
    data: {
      title: "טיפול בנתונים ופרטיות",
      description: "אנו מחויבים לשקיפות ושליטה בכל הנוגע לנתונים האישיים שלך.",
      settingsHint: "ניתן להגדיר מחדש הגדרות אלה בכל עת בהגדרות.",
    },
    survey: {
      title: "ברוכים הבאים ל-AnythingLLM",
      description:
        "עזרו לנו לבנות את AnythingLLM כך שיתאים לצרכים שלכם. אופציונלי.",
      email: "מה האימייל שלך?",
      useCase: "לאיזו מטרה תשתמש ב-AnythingLLM?",
      useCaseWork: "לעבודה",
      useCasePersonal: "לשימוש אישי",
      useCaseOther: "אחר",
      comment: "איך שמעת על AnythingLLM?",
      commentPlaceholder:
        "Reddit, Twitter, GitHub, YouTube, וכו' - ספר לנו איך מצאת אותנו!",
      skip: "דלג על הסקר",
      thankYou: "תודה על המשוב!",
    },
  },
  common: {
    "workspaces-name": "שם סביבת העבודה",
    selection: "בחירת מודל",
    saving: "שומר...",
    save: "שמור שינויים",
    previous: "עמוד קודם",
    next: "עמוד הבא",
    optional: "אופציונלי",
    yes: "כן",
    no: "לא",
    search: "חיפוש",
    username_requirements:
      "שם המשתמש חייב להיות באורך 2-64 תווים, להתחיל באות קטנה ולהכיל רק אותיות קטנות, מספרים, קווים תחתונים, מקפים ונקודות.",
    on: "על",
    none: "אין",
    stopped: "עצר",
    loading: "טעינה",
    refresh: "רענן",
  },
  settings: {
    title: "הגדרות מופע",
    invites: "הזמנות",
    users: "משתמשים",
    workspaces: "סביבות עבודה",
    "workspace-chats": "צ'אטים של סביבות עבודה",
    customization: "התאמה אישית",
    interface: "העדפות ממשק משתמש",
    branding: "מיתוג והתאמה אישית (Whitelabeling)",
    chat: "צ'אט",
    "api-keys": "מפתחות API למפתחים",
    llm: "מודל שפה (LLM)",
    transcription: "תמלול",
    embedder: "מטמיע (Embedder)",
    "text-splitting": "פיצול טקסט וחלוקה למקטעים (Chunking)",
    "voice-speech": "קול ודיבור",
    "vector-database": "מסד נתונים וקטורי",
    embeds: "הטמעות צ'אט (Embeds)",
    security: "אבטחה",
    "event-logs": "יומני אירועים",
    privacy: "פרטיות ונתונים",
    "ai-providers": "ספקי בינה מלאכותית",
    "agent-skills": "כישורי סוכן",
    admin: "מנהל",
    tools: "כלים",
    "system-prompt-variables": "משתני הנחיית מערכת",
    "experimental-features": "תכונות ניסיוניות",
    contact: "צור קשר עם התמיכה",
    "browser-extension": "תוסף דפדפן",
    "mobile-app": "AnythingLLM Mobile",
    "community-hub": {
      title: "מרכז קהילתי",
      trending: "גלו את הנושאים החמים",
      "your-account": "החשבון שלך",
      "import-item": "ייבוא פריט",
    },
    channels: "ערוצים",
    "available-channels": {
      telegram: "טלגרם",
    },
    "scheduled-jobs": "משימות מתוכננות",
    "model-router": "מודל של נתב",
  },
  login: {
    "multi-user": {
      welcome: "ברוכים הבאים ל",
      "placeholder-username": "שם משתמש",
      "placeholder-password": "סיסמה",
      login: "התחברות",
      validating: "מאמת...",
      "forgot-pass": "שכחת סיסמה",
      reset: "איפוס",
    },
    "sign-in": "התחבר לחשבון {{appName}} שלך.",
    "password-reset": {
      title: "איפוס סיסמה",
      description: "ספק את המידע הדרוש למטה כדי לאפס את סיסמתך.",
      "recovery-codes": "קודיי שחזור",
      "back-to-login": "חזרה להתחברות",
    },
  },
  "main-page": {
    quickActions: {
      createAgent: "צור סוכן",
      editWorkspace: "ערוך את סביבת העבודה",
      uploadDocument: "העלה מסמך",
    },
    greeting: "במה אוכל לעזור לך היום?",
  },
  "new-workspace": {
    title: "סביבת עבודה חדשה",
    placeholder: "סביבת העבודה שלי",
  },
  "workspaces—settings": {
    general: "הגדרות כלליות",
    chat: "הגדרות צ'אט",
    vector: "מסד נתונים וקטורי",
    members: "חברים",
    agent: "תצורת סוכן",
  },
  general: {
    vector: {
      title: "ספירת וקטורים",
      description: "המספר הכולל של וקטורים במסד הנתונים הווקטורי שלך.",
    },
    names: {
      description: "זה ישנה רק את שם התצוגה של סביבת העבודה שלך.",
    },
    message: {
      title: "הודעות צ'אט מוצעות",
      description: "התאם אישית את ההודעות שיוצעו למשתמשי סביבת העבודה שלך.",
      add: "הוסף הודעה חדשה",
      save: "שמור הודעות",
      heading: "הסבר לי",
      body: "את היתרונות של AnythingLLM",
    },
    delete: {
      title: "מחק סביבת עבודה",
      description:
        "מחק סביבת עבודה זו ואת כל הנתונים שלה. פעולה זו תמחק את סביבת העבודה עבור כל המשתמשים.",
      delete: "מחק סביבת עבודה",
      deleting: "מוחק סביבת עבודה...",
      "confirm-start": "אתה עומד למחוק את כל",
      "confirm-end":
        "סביבת העבודה שלך. פעולה זו תסיר את כל הטמעות הווקטורים ממסד הנתונים הווקטורי שלך.\n\nקבצי המקור המקוריים יישארו ללא שינוי. פעולה זו אינה הפיכה.",
    },
  },
  chat: {
    llm: {
      title: "ספק מודל שפה (LLM) של סביבת העבודה",
      description:
        "ספק ומודל ה-LLM הספציפיים שישמשו עבור סביבת עבודה זו. כברירת מחדל, הוא משתמש בספק ובהגדרות ה-LLM של המערכת.",
      search: "חפש בכל ספקי ה-LLM",
    },
    model: {
      title: "מודל צ'אט של סביבת העבודה",
      description:
        "מודל הצ'אט הספציפי שישמש עבור סביבת עבודה זו. אם ריק, ישתמש בהעדפת ה-LLM של המערכת.",
    },
    mode: {
      title: "מצב צ'אט",
      chat: {
        title: "צ'אט",
        description:
          "יוכל לספק תשובות בהתבסס על הידע הכללי של ה-LLM ועל ההקשר הרלוונטי מהמסמכים. <b> ו-</b>\nתצטרכו להשתמש בפקודה @agent כדי להשתמש בכלי.",
      },
      query: {
        title: "שאילתה",
        description:
          "יוענו עם תשובות <b>רק</b>במידה ויימצא הקשר של המסמך.<br />תצטרכו להשתמש בפקודה @agent כדי להשתמש בכלי.",
      },
      automatic: {
        description:
          "התוכנה תשתמש באופן אוטומטי בכלים אם המודל והספק תומכים בהם. <br />אם אין תמיכה בכלים מקומיים, תצטרכו להשתמש בפקודה @agent כדי להשתמש בכלים.",
        title: "סוכן",
      },
    },
    history: {
      title: "היסטוריית צ'אט",
      "desc-start": "מספר הצ'אטים הקודמים שייכללו בזיכרון לטווח קצר של התגובה.",
      recommend: "מומלץ 20. ",
    },
    prompt: {
      title: "הנחיית מערכת",
      description:
        "ההנחיה שתשמש בסביבת עבודה זו. הגדר את ההקשר וההוראות לבינה המלאכותית כדי ליצור תגובה. עליך לספק הנחיה מנוסחת בקפידה כדי שה-AI יוכל ליצור תגובה רלוונטית ומדויקת.",
      history: {
        title: "היסטוריית הנחיות מערכת",
        clearAll: "נקה הכל",
        noHistory: "אין היסטוריית הנחיות מערכת זמינה",
        restore: "שחזר",
        delete: "מחק",
        publish: "פרסם במרכז הקהילה",
        deleteConfirm: "האם אתה בטוח שברצונך למחוק פריט היסטוריה זה?",
        clearAllConfirm:
          "האם אתה בטוח שברצונך לנקות את כל ההיסטוריה? לא ניתן לבטל פעולה זו.",
        expand: "הרחב",
      },
    },
    refusal: {
      title: "תגובת סירוב במצב שאילתה",
      "desc-start": "כאשר במצב",
      query: "שאילתה",
      "desc-end":
        ", ייתכן שתרצה להחזיר תגובת סירוב מותאמת אישית כאשר לא נמצא הקשר.",
      "tooltip-title": "למה אני רואה את זה?",
      "tooltip-description":
        "אתה נמצא במצב שאילתה, אשר משתמש רק במידע מהמסמכים שלך. עבור למצב צ'אט לשיחות גמישות יותר, או לחץ כאן כדי לבקר בתיעוד שלנו וללמוד עוד על מצבי צ'אט.",
    },
    temperature: {
      title: "טמפרטורת LLM",
      "desc-end":
        "ככל שהמספר גבוה יותר, כך התגובה יצירתית יותר. עבור מודלים מסוימים, הדבר עלול להוביל לתגובות לא קוהרנטיות כאשר הערך גבוה מדי.",
    },
  },
  "vector-workspace": {
    identifier: "מזהה מסד נתונים וקטורי",
    snippets: {
      title: "מקטעי הקשר מרביים",
      description:
        "הגדרה זו שולטת בכמות המרבית של מקטעי הקשר שיישלחו למודל השפה עבור כל צ'אט או שאילתה.",
      recommend: "מומלץ: 4",
    },
    doc: {
      title: "סף דמיון מסמכים",
      description:
        "ציון הדמיון המינימלי הנדרש כדי שמקור ייחשב קשור לצ'אט. ככל שהמספר גבוה יותר, כך המקור חייב להיות דומה יותר לצ'אט.",
      zero: "ללא הגבלה",
      low: "נמוך (ציון דמיון ≥ 0.25)",
      medium: "בינוני (ציון דמיון ≥ 0.50)",
      high: "גבוה (ציון דמיון ≥ 0.75)",
    },
    reset: {
      reset: "אפס מסד נתונים וקטורי",
      resetting: "מנקה וקטורים...",
      confirm:
        "אתה עומד לאפס את מסד הנתונים הווקטורי של סביבת עבודה זו. פעולה זו תסיר את כל הטמעות הווקטורים הקיימות.\n\nקבצי המקור המקוריים יישארו ללא שינוי. פעולה זו אינה הפיכה.",
      error: "לא ניתן היה לאפס את מסד הנתונים הווקטורי של סביבת העבודה!",
      success: "מסד הנתונים הווקטורי של סביבת העבודה אופס!",
    },
  },
  agent: {
    "performance-warning":
      "הביצועים של מודלי שפה שאינם תומכים במפורש בקריאת כלים (tool-calling) תלויים מאוד ביכולות ובדיוק של המודל. ייתכן שיכולות מסוימות יהיו מוגבלות או לא פונקציונליות.",
    provider: {
      title: "ספק מודל שפה (LLM) של סוכן סביבת העבודה",
      description:
        "ספק ומודל ה-LLM הספציפיים שישמשו עבור סוכן ה-@agent של סביבת עבודה זו.",
    },
    mode: {
      chat: {
        title: "מודל צ'אט של סוכן סביבת העבודה",
        description:
          "מודל הצ'אט הספציפי שישמש עבור סוכן ה-@agent של סביבת עבודה זו.",
      },
      title: "מודל סוכן של סביבת העבודה",
      description:
        "מודל ה-LLM הספציפי שישמש עבור סוכן ה-@agent של סביבת עבודה זו.",
      wait: "-- ממתין למודלים --",
    },
    skill: {
      rag: {
        title: "RAG וזיכרון לטווח ארוך",
        description:
          'אפשר לסוכן למנף את המסמכים המקומיים שלך כדי לענות על שאילתות או בקש מהסוכן "לזכור" חלקי תוכן לאחזור זיכרון לטווח ארוך.',
      },
      view: {
        title: "צפייה וסיכום מסמכים",
        description:
          "אפשר לסוכן לרשום ולסכם את התוכן של קבצי סביבת העבודה המוטמעים כעת.",
      },
      scrape: {
        title: "גירוד אתרי אינטרנט",
        description: "אפשר לסוכן לבקר ולגרד את התוכן של אתרי אינטרנט.",
      },
      generate: {
        title: "יצירת תרשימים",
        description:
          "אפשר לסוכן ברירת המחדל ליצור סוגים שונים של תרשימים מנתונים שסופקו או ניתנו בצ'אט.",
      },
      web: {
        title: "חיפוש וגלישה באינטרנט בזמן אמת",
        description:
          "אפשרו לסוכן שלכם לחפש באינטרנט כדי לענות על שאלותיכם, על ידי חיבור לספק שירותי חיפוש (SERP).",
      },
      sql: {
        title: "חיבור SQL",
        description:
          "אפשרו לסוכן שלכם לנצל את SQL כדי לענות על שאלותיכם, על ידי חיבור למספר ספקי מסדי נתונים של SQL.",
      },
      default_skill:
        "כברירת מחדל, הכישורים הזה מופעל, אך ניתן להשבית אותו אם אינכם רוצים שהוא יהיה זמין עבור הסוכן.",
      filesystem: {
        title: "גישה למערכת הקבצים",
        description:
          "אפשרו למתווך שלכם לקרוא, לכתוב, לחפש ולנהל קבצים בספריית מסוימת. תומך בעריכת קבצים, ניווט בספריות וחיפוש תוכן.",
        learnMore: "למידע נוסף על השימוש בכישרון זה",
        configuration: "הגדרות",
        readActions: "קריאת פעולות",
        writeActions: "פעולות",
        warning:
          "גישה למערכת הקבצים עלולה להיות מסוכנת, שכן היא עלולה לשנות או למחוק קבצים. אנא התייעצו עם ה<a>תיעוד</a> לפני הפעלתה.",
        skills: {
          "read-text-file": {
            title: "קרא קובץ",
            description: "קריאת תוכן קבצים (טקסט, קוד, PDF, תמונות וכו')",
          },
          "read-multiple-files": {
            title: "קריאת מספר קבצים",
            description: "קרא מספר קבצים בו זמנית.",
          },
          "list-directory": {
            title: "רשימת אנשי קשר",
            description: "רשימת קבצים וספריות בתיקייה",
          },
          "search-files": {
            title: "חיפוש קבצים",
            description: "חיפוש קבצים לפי שם או תוכן",
          },
          "get-file-info": {
            title: "קבל מידע על הקובץ",
            description: "קבל מידע מפורט על קבצים",
          },
          "edit-file": {
            title: "ערוך קובץ",
            description: "בצעו עריכה של קבצי טקסט על בסיס שורות.",
          },
          "create-directory": {
            title: "יצירת תיקייה",
            description: "ליצור תיקיות חדשות",
          },
          "move-file": {
            title: "העתקה/שינוי שם של קובץ",
            description: "הזיזו או שנו את שמות הקבצים והתיקיות.",
          },
          "copy-file": {
            title: "העתק קובץ",
            description: "העתקת קבצים וספריות",
          },
          "write-text-file": {
            title: "יצירת קובץ טקסט",
            description: "יצירת קבצי טקסט חדשים או החלפת קבצי טקסט קיימים",
          },
        },
      },
      createFiles: {
        title: "יצירת מסמכים",
        description:
          "אפשרו למתווך שלכם ליצור פורמטים של מסמכים בינאריים, כמו מצגות של פאוורPoint, גיליונות אלקטרוניים של Excel, מסמכי Word ו-PDF. ניתן להוריד את הקבצים ישירות מהחלון של השיחה.",
        configuration: "סוגי המסמכים הזמינים",
        skills: {
          "create-text-file": {
            title: "קבצי טקסט",
            description:
              "צרו קבצי טקסט עם כל תוכן ותוספת (כגון .txt, .md, .json, .csv וכו').",
          },
          "create-pptx": {
            title: "מצגות של פאוור פוינט",
            description:
              "צרו מצגות חדשות בפורמט PowerPoint, הכוללות שקופיות, כותרות ונקודות עיקריות.",
          },
          "create-pdf": {
            title: "מסמכים בפורמט PDF",
            description:
              "יצירת מסמכים בפורמט PDF ממחרוזות markdown או טקסט פשוט, עם עיצוב בסיסי.",
          },
          "create-xlsx": {
            title: "גיליונות אקסל",
            description:
              "צור מסמכי Excel עבור נתונים טבלאיים, הכוללים גיליונות ועריכת עיצוב.",
          },
          "create-docx": {
            title: "מסמכים בפורמט Word",
            description: "צור מסמכים בפורמט Word עם עיצוב ועיצוב בסיסיים.",
          },
        },
      },
      gmail: {
        title: "חיבור ל-GMail",
        description:
          'אפשר לאгент שלכם לתקשר עם Gmail – לחפש הודעות דוא"ל, לקרוא דיונים, ליצור טיוטות, לשלוח הודעות דוא"ל ולנהל תיבת הדואר. <a>קרא את התיעוד</a>.',
        multiUserWarning:
          "שילוב עם ג'ימל אינו זמין במצב רב משתמשים מטעמי אבטחה. אנא כבו את מצב רב משתמשים כדי להשתמש בתכונה זו.",
        configuration: "הגדרת חשבון Gmail",
        deploymentId: "מזהה הפריסה",
        deploymentIdHelp: "מזהה הפריסה מהאפליקציה שלך של Google Apps Script.",
        apiKey: "מפתח API",
        apiKeyHelp:
          "מפתח ה-API שבה הגדרת בסביבת העבודה של Google Apps Script שלך.",
        configurationRequired:
          "אנא הגדירו את מזהה ההפצה ואת מפתח ה-API כדי לאפשר את יכולות Gmail.",
        configured: "הוגדר",
        searchSkills: "כישורים לחיפוש...",
        noSkillsFound: "לא נמצאו תוצאות התואמות את החיפוש שלך.",
        categories: {
          search: {
            title: 'חיפוש וקריאת הודעות דוא"ל',
            description: 'חפש וקרא הודעות דוא"ל מהתיבת הדוא"ל של ג\'ימל שלך.',
          },
          drafts: {
            title: 'הודעות דוא"ל לדוגמה',
            description: 'יצירה, עריכה וניהול של טיוטות של הודעות דוא"ל.',
          },
          send: {
            title: "שליחה ומתן מענה למיילים",
            description: "שלחו מיילים ונענו לדיונים באופן מיידי.",
          },
          threads: {
            title: 'ניהול שרשראות דוא"ל',
            description:
              'ניהול תכתובות דוא"ל – סימון כ"קרא/לא קרא", ארכיון, תיבת זבל',
          },
          account: {
            title: "נתונים על שילוב",
            description: "צפו בסטטיסטיקות של תיבת הדואר ובתמונות החשבון",
          },
        },
        skills: {
          search: {
            title: 'חיפוש הודעות דוא"ל',
            description: "חיפוש הודעות דוא\"ל באמצעות תחביר שאילתות של ג'ימייל",
          },
          readThread: {
            title: "קרא את השרשור",
            description: "קרא את כל שרשרת האימיילים שנוצרה על ידי ID.",
          },
          createDraft: {
            title: "יצירת טיוטה",
            description: "צור טיוטת אימייל חדשה",
          },
          createDraftReply: {
            title: "יצירת תגובה ראשונית",
            description: "צור תגובה ראשונית לפורום קיים.",
          },
          updateDraft: {
            title: "גרסה עדכנית",
            description: 'עדכן הודעת דוא"ל קיימת',
          },
          getDraft: {
            title: "קבל טיוטה",
            description: "השגת גרסה ספציפית לפי מספר זיהוי",
          },
          listDrafts: {
            title: "גרסאות טיוטה",
            description: "רשום את כל ההודעות המאובזרות",
          },
          deleteDraft: {
            title: "מחיקת טיוטה",
            description: "מחיקת תגובה מקושטת",
          },
          sendDraft: {
            title: "שלח טיוטה",
            description: "שלח גרסה קיימת של מייל",
          },
          sendEmail: {
            title: "שלח אימייל",
            description: "שלח מייל באופן מיידי",
          },
          replyToThread: {
            title: "תגובה לדיון",
            description: "התגובה מיידית לשרשור אימיילים",
          },
          markRead: {
            title: "מרק רד",
            description: 'סמנו נושא כ"קרא"',
          },
          markUnread: {
            title: "סמן כלא קרא",
            description: "סמנו נושא כלא קרא",
          },
          moveToTrash: {
            title: "העבר למיחזור",
            description: "העברת נושא לקבצי האשפה",
          },
          moveToArchive: {
            title: "ארכיון",
            description: "שמור את הדיון",
          },
          moveToInbox: {
            title: "העבר לסמאר",
            description: "העבר את הדיון לתיבת הדואר הנכנס",
          },
          getMailboxStats: {
            title: "סטטיסטיקות של תיבת דואר",
            description:
              "קבל ספירה של הודעות שטרם נקראו וסטטיסטיקות של תיבת הדואר.",
          },
          getInbox: {
            title: "קבל תיבת הדואר",
            description:
              'דרך פשוטה ומהירה לקבל את הודעות הדוא"ל מהתיבת הדוא"ל של ג\'ימל',
          },
        },
      },
      outlook: {
        title: "חיבור ל-Outlook",
        description:
          'אפשר לאגנט שלכם לתקשר עם Microsoft Outlook – לחפש הודעות דוא"ל, לקרוא דיונים, ליצור טיוטות, לשלוח הודעות דוא"ל ולנהל תיבת הדואר שלכם באמצעות Microsoft Graph API. <a>קראו את התיעוד</a>.',
        multiUserWarning:
          "שילוב עם Outlook אינו זמין במצב רב-משתמשים מטעמי אבטחה. אנא בטל את מצב רב-משתמשים כדי להשתמש בתכונה זו.",
        configuration: "הגדרת תצורה (Outlook)",
        authType: "סוג חשבון",
        authTypeHelp:
          'בחר איזה סוגי חשבונות מיקרוסופט יכולים לאמת. "כל החשבונות" תומך הן בחשבונות אישיים והן בחשבונות עבודה/לימודים. "רק חשבונות אישיים" מגביל את השימוש לחשבונות מיקרוסופט אישיים בלבד. "רק חשבונות ארגוניים" מגביל את השימוש לחשבונות עבודה/לימודים מחשבון Azure AD ספציפי.',
        authTypeCommon: "כל החשבונות (אישיים וקשורים לעבודה/לימודים)",
        authTypeConsumers: "חשבונות אישיים של מיקרוסופט בלבד",
        authTypeOrganization: "חשבונות רק עבור ארגונים (דורש מזהה שוכר)",
        clientId: "מספר זיהוי של לקוח (יישום)",
        clientIdHelp: "מזהה היישום (לקוח) מההרשמה של היישום שלך ב-Azure AD",
        tenantId: "מספר מזהה (שוכר)",
        tenantIdHelp:
          "מזהה ה-ID של הלקוח (שוכר) מההרשמה של היישום שלך ב-Azure AD. נדרש רק לאימות מתוך הארגון בלבד.",
        clientSecret: "סוד לקוח",
        clientSecretHelp:
          "הערך הסודי של הלקוח מההרשמה של היישום שלך ב-Azure AD",
        configurationRequired:
          "אנא הגדירו את מזהה הלקוח והסיסמה כדי לאפשר את יכולות Outlook.",
        authRequired:
          "שמרו את הפרטים שלכם תחילה, ולאחר מכן השתמשו באימות של מיקרוסופט כדי להשלים את ההגדרה.",
        authenticateWithMicrosoft: "אימות באמצעות מיקרוסופט",
        authenticated: "התחברות מוצלחת עם Microsoft Outlook.",
        revokeAccess: "ביטול גישה",
        configured: "מוגדר",
        searchSkills: "כישורים במחקר...",
        noSkillsFound: "אין התאמות לחיפוש שלך.",
        categories: {
          search: {
            title: 'חיפוש וקריאת הודעות דוא"ל',
            description: 'חפש וקרא הודעות דוא"ל מהתיבת הדוא"ל של Outlook שלך.',
          },
          drafts: {
            title: 'הודעות דוא"ל לדוגמה',
            description: 'יצירה, עריכה וניהול של טיוטות של הודעות דוא"ל',
          },
          send: {
            title: 'שלח הודעות דוא"ל',
            description: "שלחו מיילים חדשים או הגיבו למיילים באופן מיידי.",
          },
          account: {
            title: "נתוני אינטגרציה",
            description: "צפו בסטטיסטיקות של תיבת הדואר ובמידע על החשבון.",
          },
        },
        skills: {
          getInbox: {
            title: "קבל תיבת דואר",
            description: "קבל מיילים חדשים מהתיבת הדואר שלך ב-Outlook.",
          },
          search: {
            title: 'חיפוש הודעות דוא"ל',
            description: 'חיפוש הודעות דוא"ל באמצעות תחביר החיפוש של Microsoft',
          },
          readThread: {
            title: "קרא שיחה",
            description: 'קראו את כל רצף ההודעות בדוא"ל.',
          },
          createDraft: {
            title: "יצירת טיוטה",
            description: "צור טיוטת מייל חדשה או טיוטת תגובה למייל קיים.",
          },
          updateDraft: {
            title: "גרסה עדכנית",
            description: 'עדכן הודעת דוא"ל קיימת',
          },
          listDrafts: {
            title: "גרסאות ראשוניות",
            description: "רשום את כל ההודעות המיילים המוצעות",
          },
          deleteDraft: {
            title: "מחיקת טיוטה",
            description: "מחיקת טיוטת אימייל",
          },
          sendDraft: {
            title: "שלח טיוטה",
            description: "שלח גרסה קיימת של מייל",
          },
          sendEmail: {
            title: "שלח מייל",
            description: "שלח מייל חדש או הגיב למייל קיים באופן מיידי.",
          },
          getMailboxStats: {
            title: "סטטיסטיקות של תיבת דואר",
            description: "קבל ספירת תיקיות ונתונים סטטיסטיים עבור תיבות דואר.",
          },
        },
      },
      googleCalendar: {
        title: "חיבור ל-Google Calendar",
        description:
          "אפשרו לסוכן שלכם לתקשר עם גוגל קלנדר - לצפות בקלנדרים, לקבל אירועים, ליצור ולעדכן אירועים, ולנהל אישורי השתתפות. <a>קראו את התיעוד</a>.",
        multiUserWarning:
          "שילוב עם גוגל קלנדר אינו זמין במצב רב-משתמשים מטעמי אבטחה. אנא כבו את מצב רב-משתמשים כדי להשתמש בתכונה זו.",
        configuration: "הגדרת גלובל קלנדר",
        deploymentId: "מזהה הפריסה",
        deploymentIdHelp: "מזהה הפריסה מהאפליקציה שלך של Google Apps Script",
        apiKey: "מפתח API",
        apiKeyHelp:
          "המפתח של ה-API שקבעת בהגדרות של סקריפט האפליקציות של גוגל.",
        configurationRequired:
          "אנא הגדירו את מזהה ההפצה ואת מפתח ה-API כדי לאפשר את הפונקציונליות של גוגל קלנדר.",
        configured: "מוגדר",
        searchSkills: "כישורים לחיפוש...",
        noSkillsFound: "אין התאמות לחיפוש שלך.",
        categories: {
          calendars: {
            title: "יומני",
            description: "צפו ונהלו את הלוחות שלכם בגוגל",
          },
          readEvents: {
            title: "קרא על אירועים",
            description: "צפו וחפשו אירועים בלוח השנה",
          },
          writeEvents: {
            title: "יצירה ועדכון אירועים",
            description: "ליצור אירועים חדשים ולשנות את האירועים הקיימים.",
          },
          rsvp: {
            title: "ניהול אישורי השתתפות",
            description: "נהלו את סטטוס התגובה שלכם לאירועים",
          },
        },
        skills: {
          listCalendars: {
            title: "רשימת לוחות",
            description: "רשום את כל הקלנדרים שבבעלותך או אליהם מנויים.",
          },
          getCalendar: {
            title: "קבל פרטים על הקלנדר",
            description: "קבל מידע מפורט על לוח שנה ספציפי.",
          },
          getEvent: {
            title: "קבל אירוע",
            description: "קבל מידע מפורט על אירוע ספציפי",
          },
          getEventsForDay: {
            title: "מצא אירועים ליום",
            description: "קבלו את כל האירועים המתוכננים לתאריך ספציפי.",
          },
          getEvents: {
            title: "קבל אירועים (טווח תאריכים)",
            description: "קבל אירועים בטווח תאריכים מותאם אישית",
          },
          getUpcomingEvents: {
            title: "רשימת אירועים עתידיים",
            description:
              "מצאו אירועים של היום, השבוע או החודש באמצעות מילות מפתח פשוטות.",
          },
          quickAdd: {
            title: "הוספה מהירה של אירוע",
            description:
              'ליצור אירוע מתוך טקסט טבעי (למשל, "פגישה מחר בשעה 15:00")',
          },
          createEvent: {
            title: "יצירת אירוע",
            description: "צור אירוע חדש עם שליטה מלאה על כל התכונות.",
          },
          updateEvent: {
            title: "עדכון אירוע",
            description: "עדכן אירוע קיים בלוח השנה",
          },
          setMyStatus: {
            title: "הגדר סטטוס אישור השתתפות",
            description: "לקבל, לדחות, או לקבל באופן זמני אירוע",
          },
        },
      },
    },
    mcp: {
      title: "שרתי MCP",
      "loading-from-config": "טעינת שרתי MCP מהקובץ בתצורה",
      "learn-more": "למידע נוסף על שרתי MCP.",
      "no-servers-found": "לא נמצאו שרתי MCP.",
      "tool-warning":
        "על מנת להשיג את הביצועים הטובים ביותר, שקלו לבטל כלים לא רצויים כדי לחסוך במשאבים.",
      "stop-server": "עצור את שרת ה-MCP",
      "start-server": "הפעל שרת MCP",
      "delete-server": "מחיקת שרת ה-MCP",
      "tool-count-warning":
        "שרת ה-MCP הזה כולל <b>כלי{{count}} שפעילים, אשר יצרוך מידע הקשר בכל צ'אט. </b> מומלץ לבטל את הכליות הלא רצויות כדי לחסוך במידע ההקשר.",
      "startup-command": "פקודת התחלה",
      command: "פקודה",
      arguments: "טיעונים",
      "not-running-warning":
        "שרת ה-MCP הזה אינו פועל – ייתכן שהוא מושבת או שהוא חווה תקלה בעת ההפעלה.",
      "tool-call-arguments": "ארגומנטים לפונקציות",
      "tools-enabled": "הכלים פעלו/היו זמינים",
    },
    settings: {
      title: "הגדרות מיומנויות של סוכן",
      "max-tool-calls": {
        title: 'מספר קריאות "Max Tool" לכל תגובה',
        description:
          "מספר הכלים המקסימלי שאгент יכול לקשור כדי ליצור תגובה אחת. זה מונע קריאות מרובות של כלים ומחזורים אינסופיים.",
      },
      "intelligent-skill-selection": {
        title: "בחירת מיומנויות בהתאם ליכולות",
        description:
          "אפשרו שימוש בלתי מוגבל בכלים וצמצום השימוש בטוקנים עד 80% לכל שאילתה – ה-AnythingLLM בוחר באופן אוטומטי את הכישורים המתאימים ביותר לכל בקשה.",
        "max-tools": {
          title: "כלים של מקס",
          description:
            "מספר המינימום של כלי העבודה שניתן לבחור עבור כל שאילתה. אנו ממליצים להגדיר ערך גבוה יותר עבור מודלים עם הקשר רחב יותר.",
        },
      },
      "clarifying-questions": {
        title: "אפשר לסוכן לשאול שאלות הבהרה.",
        "beta-badge": "בטא",
        description:
          "כאשר הפונקציה מופעלת, ניתן לבקש מהנציגים לעצור ולשאול שאלות קצרות להבהרה, במקרה שההנחיה שלך אינה ברורה.",
        "max-per-turn": {
          title: "מספר שאלות מקסימלי לסיבוב",
          description: "כמה שאלות הבהרה יכול סוכן לשאול במהלך סקר אחד?",
        },
      },
    },
  },
  recorded: {
    title: "צ'אטים של סביבת עבודה",
    description:
      "אלה כל הצ'אטים וההודעות המוקלטים שנשלחו על ידי משתמשים, מסודרים לפי תאריך יצירתם.",
    export: "יצא",
    table: {
      id: "מזהה",
      by: "נשלח על ידי",
      workspace: "סביבת עבודה",
      prompt: "הנחיה",
      response: "תגובה",
      at: "נשלח ב",
    },
  },
  customization: {
    interface: {
      title: "העדפות ממשק משתמש",
      description: "הגדר את העדפות ממשק המשתמש שלך עבור AnythingLLM.",
    },
    branding: {
      title: "מיתוג והתאמה אישית (Whitelabeling)",
      description: "התאם אישית את מופע ה-AnythingLLM שלך עם מיתוג מותאם אישית.",
    },
    chat: {
      title: "צ'אט",
      description: "הגדר את העדפות הצ'אט שלך עבור AnythingLLM.",
      auto_submit: {
        title: "שליחה אוטומטית של קלט קולי",
        description: "שלח אוטומטית קלט קולי לאחר פרק זמן של שקט",
      },
      auto_speak: {
        title: "הקראה אוטומטית של תגובות",
        description: "הקרא אוטומטית תגובות מה-AI",
      },
      spellcheck: {
        title: "הפעל בדיקת איות",
        description: "הפעל או השבת בדיקת איות בשדה הקלט של הצ'אט",
      },
    },
    items: {
      theme: {
        title: "ערכת נושא",
        description: "בחר את ערכת הצבעים המועדפת עליך ליישום.",
      },
      "show-scrollbar": {
        title: "הצג פס גלילה",
        description: "הפעל או השבת את פס הגלילה בחלון הצ'אט.",
      },
      "support-email": {
        title: "אימייל תמיכה",
        description:
          "הגדר את כתובת האימייל לתמיכה שתהיה נגישה למשתמשים כאשר הם זקוקים לעזרה.",
      },
      "app-name": {
        title: "שם",
        description: "הגדר שם שיוצג בדף ההתחברות לכל המשתמשים.",
      },
      "display-language": {
        title: "שפת תצוגה",
        description:
          "בחר את השפה המועדפת להצגת ממשק המשתמש של AnythingLLM - כאשר תרגומים זמינים.",
      },
      logo: {
        title: "לוגו מותג",
        description: "העלה את הלוגו המותאם אישית שלך להצגה בכל העמודים.",
        add: "הוסף לוגו מותאם אישית",
        recommended: "גודל מומלץ: 800x200",
        remove: "הסר",
        replace: "החלף",
      },
      "browser-appearance": {
        title: "מראה הדפדפן",
        description:
          "התאם אישית את מראה לשונית הדפדפן והכותרת כשהאפליקציה פתוחה.",
        tab: {
          title: "כותרת",
          description:
            "הגדר כותרת לשונית מותאמת אישית כשהאפליקציה פתוחה בדפדפן.",
        },
        favicon: {
          title: "סמל אתר (Favicon)",
          description: "השתמש בסמל אתר מותאם אישית עבור לשונית הדפדפן.",
        },
      },
      "sidebar-footer": {
        title: "פריטי כותרת תחתונה בסרגל הצד",
        description:
          "התאם אישית את פריטי הכותרת התחתונה המוצגים בתחתית סרגל הצד.",
        icon: "סמל",
        link: "קישור",
      },
      "render-html": {
        title: "הצגת קוד HTML בשיחת צ'אט",
        description:
          "הצגת תגובות HTML בתגובות של עוזר.\nזה יכול להוביל לאיכות תגובה גבוהה בהרבה, אך גם עלול לגרום לסיכונים פוטנציאליים של אבטחה.",
      },
    },
  },
  api: {
    title: "מפתחות API",
    description:
      "מפתחות API מאפשרים למחזיק בהם לגשת ולנהל באופן תכנותי את מופע AnythingLLM זה.",
    link: "קרא את תיעוד ה-API",
    generate: "צור מפתח API חדש",
    empty: "לא נמצאו מפתחות API",
    actions: "פעולות",
    messages: {
      error: "שגיאה: {{error}}",
    },
    modal: {
      title: "יצירת מפתח API חדש",
      cancel: "ביטול",
      close: "סגירה",
      create: "צור מפתח API",
      helper:
        "לאחר יצירתו, ניתן להשתמש במפתח ה-API כדי לגשת למופע AnythingLLM זה ולהגדיר אותו באופן תכנותי.",
      name: {
        label: "שם",
        placeholder: "אינטגרציית ייצור",
        helper: "אופציונלי. השתמש בשם ברור כדי שתוכל לזהות את המפתח הזה בהמשך.",
      },
    },
    row: {
      copy: "העתק מפתח API",
      copied: "הועתק",
      unnamed: "--",
      deleteConfirm:
        "האם אתה בטוח שברצונך להשבית את מפתח ה-API הזה?\nלאחר מכן לא יהיה ניתן להשתמש בו יותר.\n\nלא ניתן לבטל פעולה זו.",
    },
    table: {
      name: "שם",
      key: "מפתח API",
      by: "נוצר על ידי",
      created: "נוצר",
    },
  },
  llm: {
    title: "העדפות מודל שפה (LLM)",
    description:
      "אלה האישורים וההגדרות עבור ספק הצ'אט וההטמעה המועדף עליך. חשוב שמפתחות אלה יהיו עדכניים ונכונים, אחרת AnythingLLM לא יפעל כראוי.",
    provider: "ספק LLM",
    providers: {
      azure_openai: {
        azure_service_endpoint: "נקודת קצה של שירות Azure",
        api_key: "מפתח API",
        chat_deployment_name: "שם פריסת צ'אט",
        chat_model_token_limit: "מגבלת אסימוני מודל צ'אט",
        model_type: "סוג מודל",
        default: "ברירת מחדל",
        reasoning: "היגיון",
        model_type_tooltip:
          'אם השימוש שלך כולל מודל הסקה (o1, o1-mini, o3-mini וכו\'), הגדר זאת ל"הסקה". אחרת, בקשות השיחה שלך עלולות להיכשל.',
      },
    },
  },
  transcription: {
    title: "העדפות מודל תמלול",
    description:
      "אלה האישורים וההגדרות עבור ספק מודל התמלול המועדף עליך. חשוב שמפתחות אלה יהיו עדכניים ונכונים, אחרת קובצי מדיה ושמע לא יתומללו.",
    provider: "ספק תמלול",
    "warn-start":
      "שימוש במודל ה-whisper המקומי על מכונות עם זיכרון RAM או מעבד מוגבלים עלול לגרום להאטה של AnythingLLM בעת עיבוד קובצי מדיה.",
    "warn-recommend":
      "אנו ממליצים על לפחות 2GB של זיכרון RAM והעלאת קבצים קטנים מ-10Mb.",
    "warn-end": "המודל המובנה יורד אוטומטית בשימוש הראשון.",
  },
  embedding: {
    title: "העדפות הטמעה (Embedding)",
    "desc-start":
      "בעת שימוש במודל שפה שאינו תומך באופן מובנה במנוע הטמעה - ייתכן שתצטרך לציין בנוסף אישורים להטמעת טקסט.",
    "desc-end":
      "הטמעה היא תהליך של הפיכת טקסט לווקטורים. אישורים אלה נדרשים כדי להפוך את הקבצים וההנחיות שלך לפורמט ש-AnythingLLM יכול להשתמש בו לעיבוד.",
    provider: {
      title: "ספק הטמעה",
    },
  },
  text: {
    title: "העדפות פיצול טקסט וחלוקה למקטעים (Chunking)",
    "desc-start":
      "לפעמים, ייתכן שתרצה לשנות את הדרך ברירת המחדל שבה מסמכים חדשים מפוצלים ומחולקים למקטעים לפני הכנסתם למסד הנתונים הווקטורי שלך.",
    "desc-end":
      "עליך לשנות הגדרה זו רק אם אתה מבין כיצד פועל פיצול טקסט ואת תופעות הלוואי שלו.",
    size: {
      title: "גודל מקטע טקסט",
      description: "זוהי הכמות המרבית של תווים שיכולה להיות בווקטור יחיד.",
      recommend: "אורך מרבי של מודל הטמעה הוא",
    },
    overlap: {
      title: "חפיפת מקטעי טקסט",
      description:
        "זוהי החפיפה המרבית של תווים המתרחשת במהלך חלוקה למקטעים בין שני מקטעי טקסט סמוכים.",
    },
  },
  vector: {
    title: "מסד נתונים וקטורי",
    description:
      "אלה האישורים וההגדרות לאופן פעולת מופע ה-AnythingLLM שלך. חשוב שמפתחות אלה יהיו עדכניים ונכונים.",
    provider: {
      title: "ספק מסד נתונים וקטורי",
      description: "אין צורך בתצורה עבור LanceDB.",
    },
  },
  embeddable: {
    title: "ווידג'טים של צ'אט להטמעה",
    description:
      "ווידג'טים של צ'אט להטמעה הם ממשקי צ'אט ציבוריים הקשורים לסביבת עבודה אחת. הם מאפשרים לך לבנות סביבות עבודה שתוכל לפרסם לעולם.",
    create: "צור הטמעה",
    table: {
      workspace: "סביבת עבודה",
      chats: "צ'אטים שנשלחו",
      active: "דומיינים פעילים",
      created: "נוצר",
    },
  },
  "embed-chats": {
    title: "היסטוריית צ'אט מוטמע",
    export: "יצא",
    description: "אלה כל הצ'אטים וההודעות המוקלטים מכל הטמעה שפרסמת.",
    table: {
      embed: "הטמעה",
      sender: "שולח",
      message: "הודעה",
      response: "תגובה",
      at: "נשלח ב",
    },
  },
  event: {
    title: "יומני אירועים",
    description: "צפה בכל הפעולות והאירועים המתרחשים במופע זה לצורך ניטור.",
    clear: "נקה יומני אירועים",
    table: {
      type: "סוג אירוע",
      user: "משתמש",
      occurred: "התרחש ב",
    },
  },
  privacy: {
    title: "פרטיות וטיפול בנתונים",
    description:
      "זוהי התצורה שלך לאופן שבו ספקים צד שלישי מחוברים ו-AnythingLLM מטפלים בנתונים שלך.",
    anonymous: "טלמטריה אנונימית מופעלת",
  },
  connectors: {
    "search-placeholder": "חפש מחברי נתונים",
    "no-connectors": "לא נמצאו מחברי נתונים.",
    obsidian: {
      vault_location: "מיקום כספת",
      vault_description:
        "בחר את תיקיית כספת ה-Obsidian שלך כדי לייבא את כל ההערות והחיבורים ביניהן.",
      selected_files: "נמצאו {{count}} קבצי markdown",
      importing: "מייבא כספת...",
      import_vault: "ייבא כספת",
      processing_time: "זה עשוי לקחת זמן מה, תלוי בגודל הכספת שלך.",
      vault_warning:
        "כדי למנוע התנגשויות, ודא שכספת ה-Obsidian שלך אינה פתוחה כעת.",
    },
    github: {
      name: "מאגר GitHub",
      description: "ייבא מאגר GitHub ציבורי או פרטי שלם בלחיצה אחת.",
      URL: "כתובת URL של מאגר GitHub",
      URL_explained: "כתובת ה-URL של מאגר ה-GitHub שברצונך לאסוף.",
      token: "אסימון גישה של GitHub",
      optional: "אופציונלי",
      token_explained: "אסימון גישה למניעת הגבלת קצב.",
      token_explained_start: "ללא ",
      token_explained_link1: "אסימון גישה אישי",
      token_explained_middle:
        ", ה-API של GitHub עשוי להגביל את מספר הקבצים שניתן לאסוף עקב הגבלות קצב. תוכל ",
      token_explained_link2: "ליצור אסימון גישה זמני",
      token_explained_end: " כדי למנוע בעיה זו.",
      ignores: "התעלמות מקבצים",
      git_ignore:
        "רשום בפורמט .gitignore כדי להתעלם מקבצים ספציפיים במהלך האיסוף. הקש אנטר לאחר כל ערך שברצונך לשמור.",
      task_explained:
        "לאחר השלמה, כל הקבצים יהיו זמינים להטמעה בסביבות עבודה בבורר המסמכים.",
      branch: "ענף שממנו ברצונך לאסוף קבצים.",
      branch_loading: "-- טוען ענפים זמינים --",
      branch_explained: "ענף שממנו ברצונך לאסוף קבצים.",
      token_information:
        "ללא מילוי <b>אסימון הגישה של GitHub</b>, מחבר נתונים זה יוכל לאסוף רק את הקבצים ב<b>רמה העליונה</b> של המאגר עקב הגבלות הקצב של ה-API הציבורי של GitHub.",
      token_personal: "קבל אסימון גישה אישי בחינם עם חשבון GitHub כאן.",
    },
    gitlab: {
      name: "מאגר GitLab",
      description: "ייבא מאגר GitLab ציבורי או פרטי שלם בלחיצה אחת.",
      URL: "כתובת URL של מאגר GitLab",
      URL_explained: "כתובת ה-URL של מאגר ה-GitLab שברצונך לאסוף.",
      token: "אסימון גישה של GitLab",
      optional: "אופציונלי",
      token_description: "בחר ישויות נוספות לאחזור מה-API של GitLab.",
      token_explained_start: "ללא ",
      token_explained_link1: "אסימון גישה אישי",
      token_explained_middle:
        ", ה-API של GitLab עשוי להגביל את מספר הקבצים שניתן לאסוף עקב הגבלות קצב. תוכל ",
      token_explained_link2: "ליצור אסימון גישה זמני",
      token_explained_end: " כדי למנוע בעיה זו.",
      fetch_issues: "אחזר בעיות (Issues) כמסמכים",
      ignores: "התעלמות מקבצים",
      git_ignore:
        "רשום בפורמט .gitignore כדי להתעלם מקבצים ספציפיים במהלך האיסוף. הקש אנטר לאחר כל ערך שברצונך לשמור.",
      task_explained:
        "לאחר השלמה, כל הקבצים יהיו זמינים להטמעה בסביבות עבודה בבורר המסמכים.",
      branch: "ענף שממנו ברצונך לאסוף קבצים",
      branch_loading: "-- טוען ענפים זמינים --",
      branch_explained: "ענף שממנו ברצונך לאסוף קבצים.",
      token_information:
        "ללא מילוי <b>אסימון הגישה של GitLab</b>, מחבר נתונים זה יוכל לאסוף רק את הקבצים ב<b>רמה העליונה</b> של המאגר עקב הגבלות הקצב של ה-API הציבורי של GitLab.",
      token_personal: "קבל אסימון גישה אישי בחינם עם חשבון GitLab כאן.",
    },
    youtube: {
      name: "תמלול YouTube",
      description: "ייבא את התמלול של סרטון YouTube שלם מקישור.",
      URL: "כתובת URL של סרטון YouTube",
      URL_explained_start:
        "הזן את כתובת ה-URL של כל סרטון YouTube כדי לאחזר את התמלול שלו. לסרטון חייבות להיות ",
      URL_explained_link: "כתוביות סגורות",
      URL_explained_end: " זמינות.",
      task_explained:
        "לאחר השלמה, התמלול יהיה זמין להטמעה בסביבות עבודה בבורר המסמכים.",
    },
    "website-depth": {
      name: "גרדן קישורים המוני",
      description: "גרד אתר ואת קישורי המשנה שלו עד לעומק מסוים.",
      URL: "כתובת אתר אינטרנט",
      URL_explained: "כתובת ה-URL של האתר שברצונך לגרד.",
      depth: "עומק זחילה",
      depth_explained:
        "זהו מספר קישורי הילד שהעובד יעקוב אחריהם מכתובת ה-URL המקורית.",
      max_pages: "מספר עמודים מרבי",
      max_pages_explained: "המספר המרבי של קישורים לגירוד.",
      task_explained:
        "לאחר השלמה, כל התוכן שנגרד יהיה זמין להטמעה בסביבות עבודה בבורר המסמכים.",
    },
    confluence: {
      name: "Confluence",
      description: "ייבא עמוד Confluence שלם בלחיצה אחת.",
      deployment_type: "סוג פריסת Confluence",
      deployment_type_explained:
        "קבע אם מופע ה-Confluence שלך מתארח בענן של Atlassian או באירוח עצמי.",
      base_url: "כתובת בסיס של Confluence",
      base_url_explained: "זוהי כתובת הבסיס של מרחב ה-Confluence שלך.",
      space_key: "מפתח מרחב של Confluence",
      space_key_explained:
        "זהו מפתח המרחבים של מופע ה-Confluence שלך שישמש. בדרך כלל מתחיל ב-~",
      username: "שם משתמש ב-Confluence",
      username_explained: "שם המשתמש שלך ב-Confluence",
      auth_type: "סוג אימות Confluence",
      auth_type_explained:
        "בחר את סוג האימות שבו ברצונך להשתמש כדי לגשת לדפי ה-Confluence שלך.",
      auth_type_username: "שם משתמש ואסימון גישה",
      auth_type_personal: "אסימון גישה אישי",
      token: "אסימון גישה של Confluence",
      token_explained_start:
        "עליך לספק אסימון גישה לאימות. תוכל ליצור אסימון גישה",
      token_explained_link: "כאן",
      token_desc: "אסימון גישה לאימות",
      pat_token: "אסימון גישה אישי של Confluence",
      pat_token_explained: "אסימון הגישה האישי שלך ב-Confluence.",
      task_explained:
        "לאחר השלמה, תוכן העמוד יהיה זמין להטמעה בסביבות עבודה בבורר המסמכים.",
      bypass_ssl: "התעלמות מאימות תעודת SSL",
      bypass_ssl_explained:
        "אפשר להפעיל את האפשרות זו כדי לעקוף את אימות תעודת ה-SSL עבור מופעי Confluence המאוחסנים באופן עצמאי עם תעודה שחתמה באופן עצמי.",
    },
    manage: {
      documents: "מסמכים",
      "data-connectors": "מחברי נתונים",
      "desktop-only":
        "עריכת הגדרות אלה זמינה רק במחשב שולחני. אנא גש לדף זה משולחן העבודה שלך כדי להמשיך.",
      dismiss: "התעלם",
      editing: "עורך",
    },
    directory: {
      "my-documents": "המסמכים שלי",
      "new-folder": "תיקייה חדשה",
      "search-document": "חפש מסמך",
      "no-documents": "אין מסמכים",
      "move-workspace": "העבר לסביבת עבודה",
      "delete-confirmation":
        "האם אתה בטוח שברצונך למחוק קבצים ותיקיות אלה?\nפעולה זו תסיר את הקבצים מהמערכת ותסיר אותם אוטומטית מכל סביבת עבודה קיימת.\nפעולה זו אינה הפיכה.",
      "removing-message":
        "מסיר {{count}} מסמכים ו-{{folderCount}} תיקיות. אנא המתן.",
      "move-success": "{{count}} מסמכים הועברו בהצלחה.",
      no_docs: "אין מסמכים",
      select_all: "בחר הכל",
      deselect_all: "בטל בחירת הכל",
      remove_selected: "הסר נבחרים",
      save_embed: "שמור והטמע",
      "total-documents_one": "{{count}} מסמך",
      "total-documents_other": "מסמכים {{count}}",
    },
    upload: {
      "processor-offline": "מעבד המסמכים אינו זמין",
      "processor-offline-desc":
        "אין באפשרותנו להעלות את הקבצים שלך כרגע מכיוון שמעבד המסמכים אינו מקוון. אנא נסה שוב מאוחר יותר.",
      "click-upload": "לחץ להעלאה או גרור ושחרר",
      "file-types": "תומך בקבצי טקסט, csv, גיליונות אלקטרוניים, קבצי שמע ועוד!",
      "or-submit-link": "או שלח קישור",
      "placeholder-link": "https://example.com",
      fetching: "מאחזר...",
      "fetch-website": "אחזר אתר אינטרנט",
      "privacy-notice":
        "קבצים אלה יועלו למעבד המסמכים הפועל במופע זה של AnythingLLM. קבצים אלה אינם נשלחים או משותפים עם צד שלישי.",
    },
    pinning: {
      what_pinning: "מהי הצמדת מסמכים?",
      pin_explained_block1:
        "כאשר אתה <b>מצמיד</b> מסמך ב-AnythingLLM, אנו נזריק את כל תוכן המסמך לחלון ההנחיה שלך כדי שמודל השפה שלך יבין אותו במלואו.",
      pin_explained_block2:
        "זה עובד בצורה הטובה ביותר עם <b>מודלים בעלי הקשר רחב</b> או קבצים קטנים שהם קריטיים לבסיס הידע שלו.",
      pin_explained_block3:
        "אם אינך מקבל את התשובות הרצויות מ-AnythingLLM כברירת מחדל, הצמדה היא דרך מצוינת לקבל תשובות איכותיות יותר בלחיצה אחת.",
      accept: "אוקיי, הבנתי",
    },
    watching: {
      what_watching: "מה עושה מעקב אחר מסמך?",
      watch_explained_block1:
        "כאשר אתה <b>עוקב</b> אחר מסמך ב-AnythingLLM, אנו נסנכרן <i>אוטומטית</i> את תוכן המסמך שלך ממקורו המקורי במרווחי זמן קבועים. זה יעדכן אוטומטית את התוכן בכל סביבת עבודה שבה קובץ זה מנוהל.",
      watch_explained_block2:
        "תכונה זו תומכת כיום בתוכן מבוסס-אינטרנט ולא תהיה זמינה עבור מסמכים שהועלו ידנית.",
      watch_explained_block3_start:
        "תוכל לנהל אילו מסמכים נמצאים במעקב מתוך תצוגת ",
      watch_explained_block3_link: "מנהל הקבצים",
      watch_explained_block3_end: " של המנהל.",
      accept: "אוקיי, הבנתי",
    },
  },
  chat_window: {
    attachments_processing: "קבצים מצורפים בעיבוד. אנא המתן...",
    send_message: "שלח הודעה",
    attach_file: "צרף קובץ לצ'אט זה",
    text_size: "שנה גודל טקסט.",
    microphone: "אמור את ההנחיה שלך.",
    send: "שלח הודעת הנחיה לסביבת העבודה",
    tts_speak_message: "הקרא הודעה (TTS)",
    copy: "העתק",
    regenerate: "צור מחדש",
    regenerate_response: "צור תגובה מחדש",
    good_response: "תגובה טובה",
    more_actions: "פעולות נוספות",
    fork: "פצל (Fork)",
    delete: "מחק",
    cancel: "בטל",
    edit_prompt: "ערוך הנחיה",
    edit_response: "ערוך תגובה",
    preset_reset_description: "נקה את היסטוריית הצ'אט שלך והתחל צ'אט חדש",
    add_new_preset: " הוסף הגדרה קבועה חדשה",
    command: "פקודה",
    your_command: "הפקודה-שלך",
    placeholder_prompt: "זהו התוכן שיוזרק לפני ההנחיה שלך.",
    description: "תיאור",
    placeholder_description: "מגיב עם שיר על מודלי שפה.",
    save: "שמור",
    small: "קטן",
    normal: "רגיל",
    large: "גדול",
    workspace_llm_manager: {
      search: "חפש ספקי LLM",
      loading_workspace_settings: "טוען הגדרות סביבת עבודה...",
      available_models: "מודלים זמינים עבור {{provider}}",
      available_models_description: "בחר מודל לשימוש בסביבת עבודה זו.",
      save: "השתמש במודל זה",
      saving: "מגדיר מודל כברירת מחדל של סביבת העבודה...",
      missing_credentials: "חסרים אישורים לספק זה!",
      missing_credentials_description: "לחץ להגדרת אישורים",
    },
    submit: "הגש",
    edit_info_user:
      '"שלח" מחזיר את התגובה של הבינה המלאכותית. "שמור" מעדכן רק את ההודעה שלך.',
    edit_info_assistant: "השינויים שאתם מבצעים יישמרו ישירות בתגובה זו.",
    see_less: "ראה פחות",
    see_more: "לראות עוד",
    tools: "כלים",
    text_size_label: "גודל הטקסט",
    select_model: "בחר מודל",
    sources: "מקורות",
    document: "מסמך",
    similarity_match: "משחק",
    source_count_one: "{{count}} - הפניה",
    source_count_other: "{{count}} – מקורות",
    add_new: "הוסף חדש",
    edit: "עריכה",
    publish: "להוציא לאור",
    stop_generating: "הפסיקו ליצור תגובה",
    slash_commands: "פקודות קיצור",
    agent_skills: "כישורים של סוכן",
    manage_agent_skills: "ניהול מיומנויות של סוכנים",
    agent_skills_disabled_in_session:
      'לא ניתן לשנות כישורים במהלך סשן פעיל. יש להשתמש בפקודה "/exit" כדי לסיים את הסשן תחילה.',
    start_agent_session: "התחלת סשן עם סוכן",
    use_agent_session_to_use_tools:
      "ניתן להשתמש בכלי הדיון באמצעות פתיחת סשן עם נציג על ידי שימוש בסימן '@agent' בתחילת ההודעה.",
    agent_invocation: {
      model_wants_to_call: "המודל רוצה להתקשר",
      approve: "אישור",
      reject: "דחייה",
      always_allow: "יש תמיד להקצות {{skillName}}",
      tool_call_was_approved: "הבקשה לקבלת הכלי אושרה.",
      tool_call_was_rejected: "בקשת השימוש בכלי נדחתה.",
      clarifying_skip: "השליח יחליט",
      clarifying_submit: "הגש",
      clarifying_skipped: "אתם מאפשרים לסוכן לקבל את ההחלטה.",
      clarifying_timeout: "לא התקבל מענה בזמן.",
      clarifying_pagination: "{{current}} של {{total}}",
      clarifying_prev_aria: "השאלה הקודמת",
      clarifying_next_aria: "השאלה הבאה",
      clarifying_close_aria: "סגור ודלג",
      clarifying_other: "שאר",
      clarifying_other_placeholder: "הקלידו את התשובה",
      batch_progress: "{{answered}} מ-{{total}} השיב",
      batch_skip_this: "למעלה",
      batch_submit_all: "יש לשלוח את כל",
      batch_next: "הבא",
      answer_skipped: "[המשתמש עבר לשלב הבא]",
    },
    custom_skills: "כישורים מותאמים אישית",
    agent_flows: "זרימת סוכנים",
    no_tools_found: "לא נמצאו כלים תואמים.",
    loading_mcp_servers: "טעינת שרתי ה-MCP...",
    app_integrations: "אינטגרציות עם אפליקציות",
    sub_skills: "כישורים ספציפיים",
    memories: {
      title: "זיכרונות",
      empty:
        "עד כה, אין זיכרונות. לאחר שתתקשרו עם הצ'אטבוט, זיכרונות נוספים יתמלאו.",
      empty_cta: "ליצור זיכרון חדש",
      tab_workspace: "חלל עבודה",
      tab_global: "גלובלי",
      toggle: {
        label: "אפשרות להתאים אישית",
        description:
          "אפשר לאשתף את העוזר שלך במידע עלייך או על סביבת העבודה, ובכך להשתמש בו בשיחות.",
      },
      auto_extraction: {
        label: "זיכרונות אוטומטיים",
        description:
          "אפשר להגדיר את העוזר שלך ליצור תזכורות באופן אוטומטי ברקע.",
      },
      menu: {
        edit: "עריכה",
        delete: "מחיקה",
        move_to_global: "התפשטות גלובלית",
        move_to_workspace: "מעבר למרחב העבודה",
      },
      modal: {
        create_title: "צור זיכרון",
        edit_title: "עריכת זיכרון",
        create_description:
          'הזיכרונות צריכים להיות הצהרה אחת, תמציתית. לדוגמה: "המשתמש מעדיף את Python על פני JavaScript".',
        edit_description: "עדכן את התוכן של הזיכרון הזה.",
        label: "זיכרון",
        placeholder:
          "לדוגמה, שם המשתמש הוא ג'ואי, המשתמש עובד על פלטפורמת AnythingLLM, וכן הלאה.",
        create: "צור",
        save: "שמור",
        cancel: "בטל",
      },
    },
    stt_unsupported: "אין תמיכה בגישה למイクרופון בדפדפן זה.",
    stt_mic_denied: "לא ניתן לגשת למכשיר המיקרופון. אנא אפשרו גישה ונסו שוב.",
    stt_transcription_failed: "לא הצליח הטרנסקריפציה: {{error}}",
    export: "ייצוא צ'אט כ...",
    exporting: "ייצוא...",
  },
  profile_settings: {
    edit_account: "ערוך חשבון",
    profile_picture: "תמונת פרופיל",
    remove_profile_picture: "הסר תמונת פרופיל",
    username: "שם משתמש",
    new_password: "סיסמה חדשה",
    password_description: "הסיסמה חייבת להכיל לפחות 8 תווים",
    cancel: "בטל",
    update_account: "עדכן חשבון",
    theme: "העדפת ערכת נושא",
    language: "שפה מועדפת",
    failed_upload: "העלאת תמונת הפרופיל נכשלה: {{error}}",
    upload_success: "תמונת הפרופיל הועלתה.",
    failed_remove: "הסרת תמונת הפרופיל נכשלה: {{error}}",
    profile_updated: "הפרופיל עודכן.",
    failed_update_user: "עדכון המשתמש נכשל: {{error}}",
    account: "חשבון",
    support: "תמיכה",
    signout: "התנתק",
  },
  "keyboard-shortcuts": {
    title: "קיצורי מקלדת",
    shortcuts: {
      settings: "פתח הגדרות",
      workspaceSettings: "פתח הגדרות סביבת עבודה נוכחית",
      home: "עבור לדף הבית",
      workspaces: "נהל סביבות עבודה",
      apiKeys: "הגדרות מפתחות API",
      llmPreferences: "העדפות מודל שפה (LLM)",
      chatSettings: "הגדרות צ'אט",
      help: "הצג עזרה לקיצורי מקלדת",
      showLLMSelector: "הצג בורר מודלי שפה לסביבת עבודה",
    },
  },
  community_hub: {
    publish: {
      system_prompt: {
        success_title: "הצלחה!",
        success_description: "הנחיית המערכת שלך פורסמה במרכז הקהילה!",
        success_thank_you: "תודה על השיתוף בקהילה!",
        view_on_hub: "צפה במרכז הקהילה",
        modal_title: "פרסם הנחיית מערכת",
        name_label: "שם",
        name_description: "זהו שם התצוגה של הנחיית המערכת שלך.",
        name_placeholder: "הנחיית המערכת שלי",
        description_label: "תיאור",
        description_description:
          "זהו התיאור של הנחיית המערכת שלך. השתמש בזה כדי לתאר את מטרת ההנחיה.",
        tags_label: "תגיות",
        tags_description:
          "תגיות משמשות לתיוג הנחיית המערכת שלך לחיפוש קל יותר. ניתן להוסיף מספר תגיות. עד 5 תגיות. עד 20 תווים לתגית.",
        tags_placeholder: "הקלד והקש אנטר להוספת תגיות",
        visibility_label: "נראות",
        public_description: "הנחיות מערכת ציבוריות נראות לכולם.",
        private_description: "הנחיות מערכת פרטיות נראות רק לך.",
        publish_button: "פרסם במרכז הקהילה",
        submitting: "מפרסם...",
        prompt_label: "הנחיה",
        prompt_description: "זוהי הנחיית המערכת בפועל שתשמש להנחיית מודל השפה.",
        prompt_placeholder: "הזן את הנחיית המערכת שלך כאן...",
      },
      agent_flow: {
        success_title: "הצלחה!",
        success_description: "זרימת הסוכן שלך פורסמה במרכז הקהילה!",
        success_thank_you: "תודה על השיתוף בקהילה!",
        view_on_hub: "צפה במרכז הקהילה",
        modal_title: "פרסם זרימת סוכן",
        name_label: "שם",
        name_description: "זהו שם התצוגה של זרימת הסוכן שלך.",
        name_placeholder: "זרימת הסוכן שלי",
        description_label: "תיאור",
        description_description:
          "זהו התיאור של זרימת הסוכן שלך. השתמש בזה כדי לתאר את מטרת הזרימה.",
        tags_label: "תגיות",
        tags_description:
          "תגיות משמשות לתיוג זרימת הסוכן שלך לחיפוש קל יותר. ניתן להוסיף מספר תגיות. עד 5 תגיות. עד 20 תווים לתגית.",
        tags_placeholder: "הקלד והקש אנטר להוספת תגיות",
        visibility_label: "נראות",
        submitting: "מפרסם...",
        submit: "פרסם במרכז הקהילה",
        privacy_note:
          "זרימות סוכן תמיד מועלות כפרטיות כדי להגן על נתונים רגישים. תוכל לשנות את הנראות במרכז הקהילה לאחר הפרסום. אנא ודא שהזרימה שלך אינה מכילה מידע רגיש או פרטי לפני הפרסום.",
      },
      slash_command: {
        success_title: "הצלחה!",
        success_description: "פקודת הסלאש שלך פורסמה במרכז הקהילה!",
        success_thank_you: "תודה על השיתוף בקהילה!",
        view_on_hub: "צפה במרכז הקהילה",
        modal_title: "פרסם פקודת סלאש",
        name_label: "שם",
        name_description: "זהו שם התצוגה של פקודת הסלאש שלך.",
        name_placeholder: "פקודת הסלאש שלי",
        description_label: "תיאור",
        description_description:
          "זהו התיאור של פקודת הסלאש שלך. השתמש בזה כדי לתאר את מטרת הפקודה.",
        tags_label: "תגיות",
        tags_description:
          "תגיות משמשות לתיוג פקודת הסלאש שלך לחיפוש קל יותר. ניתן להוסיף מספר תגיות. עד 5 תגיות. עד 20 תווים לתגית.",
        tags_placeholder: "הקלד והקש אנטר להוספת תגיות",
        visibility_label: "נראות",
        public_description: "פקודות סלאש ציבוריות נראות לכולם.",
        private_description: "פקודות סלאש פרטיות נראות רק לך.",
        publish_button: "פרסם במרכז הקהילה",
        submitting: "מפרסם...",
        prompt_label: "הנחיה",
        prompt_description: "זוהי ההנחיה שתשמש כאשר פקודת הסלאש תופעל.",
        prompt_placeholder: "הזן את ההנחיה שלך כאן...",
      },
      generic: {
        unauthenticated: {
          title: "נדרש אימות",
          description:
            "עליך להתאמת עם מרכז הקהילה של AnythingLLM לפני פרסום פריטים.",
          button: "התחבר למרכז הקהילה",
        },
      },
    },
  },
  security: {
    title: "אבטחה",
    multiuser: {
      title: "מצב ריבוי משתמשים",
      description:
        "הגדר את המופע שלך לתמיכה בצוות שלך על ידי הפעלת מצב ריבוי משתמשים.",
      enable: {
        "is-enable": "מצב ריבוי משתמשים מופעל",
        enable: "הפעל מצב ריבוי משתמשים",
        description:
          "כברירת מחדל, אתה תהיה המנהל היחיד. כמנהל תצטרך ליצור חשבונות לכל המשתמשים או המנהלים החדשים. אל תאבד את סיסמתך, מכיוון שרק משתמש מנהל יכול לאפס סיסמאות.",
        username: "שם משתמש של חשבון מנהל",
        password: "סיסמת חשבון מנהל",
      },
    },
    password: {
      title: "הגנת סיסמה",
      description:
        "הגן על מופע ה-AnythingLLM שלך באמצעות סיסמה. אם תשכח אותה, אין שיטת שחזור, אז ודא שאתה שומר סיסמה זו.",
      "password-label": "סיסמת מופע",
    },
  },
  home: {
    welcome: "ברוכים הבאים",
    chooseWorkspace: "בחר סביבת עבודה כדי להתחיל לשוחח!",
    notAssigned:
      "אינך מוקצה לכל סביבת עבודה.\nיש ליצור קשר עם המנהל שלך כדי לבקש גישה לסביבת עבודה.",
    goToWorkspace: 'עבור לסביבת עבודה "{{workspace}}"',
  },
  telegram: {
    title: "בוט של טלגרם",
    description:
      "חברו את ההתקנה של AnythingLLM ל-Telegram, כך שתוכלו לתקשר עם סביבות העבודה שלכם ממכשיר כלשהו.",
    setup: {
      step1: {
        title: "שלב 1: צרו את הבוט שלכם ב-Telegram",
        description:
          "פתח את <code> ב-Telegram, שלח </code> לכתובת <code>@BotFather, עקוב אחר ההוראות, והעתק את מזהה ה-API.",
        "open-botfather": "פתוח את BotFather",
        "instruction-1": "1. פתחו את הקישור או סרקו את קוד ה-QR",
        "instruction-2":
          "2. שלחו את <code>/newbot</code> לכתובת <code>@BotFather</code>",
        "instruction-3": "3. בחרו שם וכינוי משתמש עבור הבוט שלכם",
        "instruction-4": "4. העתק את מזהה ה-API שקיבלת.",
      },
      step2: {
        title: "שלב 2: חברו את הבוט שלכם",
        description:
          "הדבק את טוקן ה-API שקיבלת מחשבון @BotFather ובחר את חלל העבודה הראשי עבור הבוט שלך, כדי שיוכל לתקשר.",
        "bot-token": "טוקן בוט",
        connecting: "חיבור...",
        "connect-bot": "צ'אטבוט",
      },
      security: {
        title: "הגדרות אבטחה מומלצות",
        description:
          "לנוחיות נוספת, יש לבצע את ההגדרות הללו דרך חשבון ה-@BotFather.",
        "disable-groups": "— למנוע הוספת רובוטים לקבוצות",
        "disable-inline": "– למנוע שימוש בבוט בחיפוש ישיר",
        "obscure-username":
          "השתמש בשם משתמש של בוט שאינו בולט, כדי להקטין את הסיכוי שהוא יימצא.",
      },
      "toast-enter-token": "אנא הזן את טוקן הבוט.",
      "toast-connect-failed": "לא הצליח להתחבר עם הבוט.",
    },
    connected: {
      status: "מחובר",
      "status-disconnected": "נתקע – הטוקן עשוי להיות פג או לא תקין",
      "placeholder-token": "הדבק את מפתח הבוט החדש...",
      reconnect: "שוב קשר",
      workspace: "חלל עבודה",
      "bot-link": "קישור לבוט",
      "voice-response": "תגובה קולית",
      disconnecting: "ניתוק...",
      disconnect: "ניתוק",
      "voice-text-only": "טקסט בלבד",
      "voice-mirror": "משקף (להגיב בקול כאשר המשתמש שולח קול)",
      "voice-always": "יש לציין תמיד (לשלוח קבצי אודיו עם כל תגובה)",
      "toast-disconnect-failed": "לא הצלחתי לבטל את פעולת הבוט.",
      "toast-reconnect-failed": "לא הצליח לשחזר את הבוט.",
      "toast-voice-failed": "לא הצליח לעדכן את מצב השמע.",
      "toast-approve-failed": "לא ניתן לאשר את המשתמש.",
      "toast-deny-failed": "לא הצליח לסרב לבקשה של המשתמש.",
      "toast-revoke-failed": "לא הצלחתי לבטל את החשבון של המשתמש.",
    },
    users: {
      "pending-description":
        "משתמשים הממתינים לאישור. יש להתאים את הקוד שמוצג כאן עם הקוד המוצג בשיחה שלהם ב-Telegram.",
      unknown: "לא ידוע",
    },
  },
  scheduledJobs: {
    title: "משימות מתוכננות",
    enableNotifications: "אפשר להפעיל התראות בדפדפן עבור תוצאות חיפוש עבודה.",
    description:
      "צור משימות AI חוזרות שיופעלו על פי לוח זמנים. כל משימה תפעיל שאילתה עם כלים אופציונליים ותשמור על התוצאה לבדיקה.",
    newJob: "תפקיד חדש",
    loading: "טעינה...",
    emptyTitle: "אין משימות מתוכננות עדיין",
    emptySubtitle: "צרו אחד כדי להתחיל.",
    table: {
      name: "שם",
      schedule: "לוח זמנים",
      status: "סטטוס",
      lastRun: "הפעולה האחרונה",
      nextRun: "הפעולה הבאה",
      actions: "פעולות",
    },
    confirmDelete: "האם אתה בטוח שאתה רוצה למחוק משימה זו שתוכננה?",
    toast: {
      deleted: "המשרה נמחקת",
      triggered: "התעסוקה בוצעה בהצלחה.",
      triggerFailed: "לא הצליח להפעיל את העבודה",
      triggerSkipped: "העבודה כבר נמצאת בשלבי ביצוע.",
      killed: "העבודה הסתיימה בהצלחה.",
      killFailed: "לא הצלחתי לעצור את העבודה",
    },
    row: {
      neverRun: "לעולם אל תרוץ",
      viewRuns: "מסלולים",
      runNow: "תתחילו עכשיו",
      enable: "אפשר",
      disable: "לכבות",
      edit: "עריכה",
      delete: "מחיקה",
    },
    modal: {
      titleEdit: "עריכת משימה מתוכננת",
      titleNew: "משימה מתוזמנת חדשה",
      nameLabel: "שם",
      namePlaceholder: "לדוגמה: תקציר חדשות יומי",
      promptLabel: "הוראה",
      promptPlaceholder: "ההוראה להפעיל בכל ביצוע...",
      scheduleLabel: "לוח זמנים",
      modeBuilder: "מבנה",
      modeCustom: "מותאם אישית",
      cronPlaceholder: "ביטוי לזמני ביצוע (למשל, 0 9 * * *)",
      currentSchedule: "לוח הזמנים הנוכחי:",
      toolsLabel: "כלים (אופציונלי)",
      toolsDescription:
        "בחר את כלי העבודה שניתן להשתמש בהם עבור משימה זו. אם לא נבחרו כלים, המשימה תפעל ללא שימוש בכלים.",
      toolsSearch: "חיפוש",
      toolsNoResults: "אין כלים המתאימים",
      required: "נדרש",
      requiredFieldsBanner: "אנא מלאו את כל השדות הנדרשים כדי ליצור משרה.",
      cancel: "בטל",
      saving: "חיסכון...",
      updateJob: "עדכון משרה",
      createJob: "יצירת משרה",
      jobUpdated: "פרסום מעודכן",
      jobCreated: "תפקיד נוצר",
    },
    builder: {
      fallbackWarning:
        'הביטוי הזה אינו ניתן לעריכה באופן ויזואלי. עברו למצב "מותאם אישית" כדי לשמור עליו, או שנה את כל מה שמתחת כדי להחליף אותו.',
      run: "לרוץ",
      frequency: {
        minute: "כל דקה",
        hour: "לכל שעה",
        day: "יומי",
        week: "שבועי",
        month: "חודשי",
      },
      every: "כל",
      minuteOne: "1 דקה",
      minuteOther: "{{count}} דקות",
      atMinute: "במהלך",
      pastEveryHour: "כל שעה",
      at: "במהלך",
      on: "על",
      onDay: "ביום",
      ofEveryMonth: "של כל חודש",
      weekdays: {
        sun: "שמש",
        mon: "יום שני",
        tue: "יום שני",
        wed: "יום רביעי",
        thu: "יום רביעי",
        fri: "יום שישי",
        sat: "שבת",
      },
    },
    runHistory: {
      back: "חזרה למחיפוש עבודה",
      title: "היסטוריית ריצות: {{name}}",
      schedule: "לוח זמנים:",
      emptyTitle: "עדיין לא בוצעו עבודות עבור פרויקט זה.",
      emptySubtitle: "הפעל את העבודה עכשיו וראה את התוצאות שלה.",
      runNow: "התחילו עכשיו",
      table: {
        status: "סטטוס",
        started: "התחיל",
        duration: "משך זמן",
        error: "שגיאה",
      },
      stopJob: "להפסיק עבודה",
    },
    runDetail: {
      loading: "טעינת פרטי הריצה...",
      notFound: "לא נמצאה פעולה.",
      back: "חזרה",
      unknownJob: "תפקיד לא ידוע",
      runHeading: "{{name}} — הפעל את מספר {{id}}",
      duration: "משך: {{value}}",
      creating: "יצירה...",
      threadFailed: "לא הצליח ליצור דיון.",
      sections: {
        prompt: "הוראה",
        error: "שגיאה",
        thinking: "מחשבות ({{count}})",
        toolCalls: "קריאות לכלי ({{count}})",
        files: "קבצים ({{count}})",
        response: "תגובה",
        metrics: "מדדים",
      },
      metrics: {
        promptTokens: "מילות מפתח:",
        completionTokens: "טוקנים לסיום:",
      },
      stopJob: "הפסק עבודה",
      killing: "עצירה...",
      continueInThread: "להמשיך בשיחה",
    },
    toolCall: {
      arguments: "טיעונים:",
      showResult: "הצג תוצאה",
      hideResult: "הסתר תוצאה",
    },
    file: {
      unknown: "קובץ לא מזוהה",
      download: "הורדה",
      downloadFailed: "לא הצליח להוריד את הקובץ",
      types: {
        powerpoint: "פאוורPoint",
        pdf: "מסמך PDF",
        word: "מסמך מילה",
        spreadsheet: "טבלה",
        generic: "קובץ",
      },
    },
    status: {
      completed: "הושלם",
      failed: "נכשל",
      timed_out: "הזמן פג",
      running: "ריצה",
      queued: "באי תור",
    },
  },
  "model-router": {
    title: "מודלים של ראוטרים",
    description:
      "נתב מודל מאפשר לך להגדיר כללים כך שהודעות צ'אט יועברו באופן אוטומטי לספקי ומודלים שונים של מודלים של שפה, בהתאם לתנאים.",
    table: {
      name: "שם",
      fallback: "תוכנית מגירה",
      rules: "כללים",
      workspaces: "חללי עבודה",
    },
    "no-routers": "עדיין אין מודלים של נתבים",
    "empty-description":
      "אין מכשירי רשת מוגדרים עדיין. יש להגדיר אחד כדי להתחיל.",
    "new-router-button": "ראוטר חדש",
    "delete-confirm":
      'האם אתה בטוח שאתה רוצה למחוק את הראוטר "{{name}}"?\nפעולה זו תסיר את כל הכללים שלה ותנתק כל סביבת עבודה המשתמשת בה.\n\nפעולה זו אינה ניתנת לבטל.',
    "toast-deleted": "נת המס שלך הוסרו",
    "toast-delete-failed": "לא הצלחתי למחוק את הראוטר: {{error}}",
    "new-router": {
      title: "יצירת מכשיר מודם חדש",
      name: "שם",
      "name-placeholder": "למשל, כלי אופטימיזציה של עלויות",
      description: "תיאור",
      "description-placeholder": "תיאור אופציונלי",
      "fallback-label": "ספק ראשי ומודל",
      "fallback-description":
        "משמש כאשר אין כלל ניתוב התואם. משמש גם להערכת כללים שסווגו על ידי מודל שפה גדול (LLM).",
      "cooldown-label": "זמן קירור (שניות)",
      "cooldown-help":
        "כמה זמן החלטת המסלול נשמרת לפני הערכת החוקים מחדש. הגדרות ל-0 כדי לבטל את השמירה.",
      "name-required": "יש לציין שם.",
      "fallback-required": "יש לציין את ספק השירות העיקרי ואת המודל הרלוונטי.",
      cancel: "בטל",
      create: "יצירת נתב",
    },
    "edit-router": {
      "back-to-routers": "חזרה למודלים של ראוטרים",
      title: "עריכת נתב: {{name}}",
      save: "שמור שינויים",
      "toast-update-failed": "לא הצלחתי לעדכן את הנתב.",
    },
    rules: {
      title: "כללי ניתוב",
      "title-with-name": "כללי ניתוב: {{name}}",
      description:
        "הגדירו את הכללים שקובעים מתי וכיצד הודעות צ'אט מועברות לספקים ודגמים ספציפיים.",
      "add-rule": "הוסף כלל",
      "delete-confirm": 'מחיקת הכלל "{{title}}"?',
      "toast-delete-failed": "לא הצליח למחוק את הכלל.",
      "toast-reorder-failed": "לא הצליח ליישם את הכללים",
      "no-rules": "עדיין אין כללים.",
      "empty-description":
        "הוסף כלל שיגרום לניתוב הודעות צ'אט לספקים ומודלים ספציפיים.",
      "new-rule-button": "חוק חדש",
      "calculated-section-label": "כללים שנקבעו – נבדקו תחילה, בסדר עדיפויות.",
      "llm-section-label":
        "כללי LLM – נבדקים כקבוצה, אם אף אחד מהכללים שחושבו לא התאים.",
      "llm-rule-body":
        'בצע את הפעולה "<desc>"{{description}}" "</desc>" ואז פנה ל-<route>{{route}}</route>',
      "calculated-no-conditions":
        "ללא תנאים – מסל הגעה ל<route>{{route}}</route>",
      "calculated-single-condition":
        "אם <prop> נמצא במיקום {{property}} וגם </prop> נמצא במיקום {{comparator}} וגם <val> נמצא במיקום {{value}} אז, יש להעביר את המסלול ל-<route> במיקום {{route}}",
      "calculated-multi-condition":
        "אם {{quantifier}} של <cond> נמצא ב{{conditions}} של </cond>, אז יש לכוון את המסלול ל<route> של {{route}} של </route>",
      "comparator-contains": "כולל",
      "comparator-matches": "משחקים",
      "comparator-between": "בין",
      "badge-llm": "מודל שפה גדול (LLM)",
      "badge-calculated": "חישב",
      "aria-drag-to-reorder": "גרור כדי לסדר מחדש",
      "aria-edit-rule": "כלל עריכה",
      "aria-delete-rule": "מחיקת חוק",
      "quantifier-any": "כל",
      "quantifier-all": "כל",
    },
    "rule-form": {
      "title-label": "כותרת",
      "rule-type": "סוג כלל",
      "property-label": "רכוש",
      "property-select": "בחר",
      "comparator-label": "מַשְׁבֵּח",
      "comparator-select": "בחר",
      "value-label": "ערך",
      "add-condition": "הוסף תנאי",
      "remove-condition": "להסיר את התנאי",
      "conditions-incomplete":
        "התנאי {{index}} אינו שלם – יש למלא את השדה עבור המיקום, המשוואה והערך.",
      "match-description-label": "תיאור המשחק",
      "match-description-placeholder":
        "למשל, המשתמש שואל על נושאים משפטיים, חוזים או נושאים הקשורים לציות לחוק.",
      "match-description-help":
        "תארו את המצב שבו אתם רוצים שהכלל הזה יחול. ה-LLM שלכם ישמש כדי לקבוע אם יש להשתמש בו.",
      "route-to-label": "מסלול להגעה לספק והמודל",
      "route-to-description": "כאשר כלל זה מתאים, יש להשתמש בספק/מודל הזה.",
      cancel: "בטל",
      saving: "חיסכון...",
      "update-rule": "כלל עדכון",
      "create-rule": "יצירת כלל",
      "title-required": "יש לציין כותרת.",
      "toast-save-failed": "לא הצליח לשמור את הכלל",
      "type-calculated-label": "חישב",
      "type-calculated-description":
        "התאמה על סמך תכונות של ההודעה, כגון תוכן, מספר הטוקנים או שעת היום.",
      "type-llm-label": "קטגוריית LLM",
      "type-llm-description":
        "השתמש במודל שפה גדול (LLM) כדי לסווג את ההודעה על סמך תיאור שאתה מספק.",
      "prop-prompt-content": "תוכן מומלץ",
      "prop-token-count": "ספירת טוקנים בשיחה",
      "prop-message-count": "מספר הודעות שיחה",
      "prop-current-hour": "שעה הנוכחית (0-23)",
      "prop-has-image": "האם יש תמונה מצורפת?",
      "cmp-contains": "כולל",
      "cmp-matches-regex": "ביטויים (רגולרי)",
      "cmp-equals": "שווה ל",
      "cmp-not-equals": "אינו שווה",
      "cmp-greater-than": "גדול יותר",
      "cmp-greater-than-or-equal": "גדול או שווה",
      "cmp-less-than": "פחות מ",
      "cmp-less-than-or-equal": "פחות או שווה ל",
      "cmp-between": "בין (כולל)",
      "placeholder-between-hour": "למשל, 9:17 (מ-9 בבוקר עד 17:00)",
      "placeholder-between-numeric": "למשל, 10,50",
      "placeholder-hour": "למשל, 18 (0-23)",
      "placeholder-message-count": "למשל, 10",
      "placeholder-numeric": "למשל, 4000",
      "placeholder-contains": "למשל, שפת תכנות, פייתון, רוסט",
      "placeholder-matches": "לדוגמה: /\\bpython\\b/i",
      "placeholder-default": "לדוגמה, קוד",
      "help-contains":
        "רשימה המופרדת בפסיקים – תואמת אם השאילתה מכילה אחד מהערכים (ללא התחשבות בגודל האותיות).",
      "help-matches":
        "תבנית רגולרי. יש להשתמש ב-/pattern/ עם דגלים כדי להגדיר רגישות לאותיות (ברירת המחדל היא אי רגישות לאותיות).",
      "bool-true": "נכון",
      "bool-false": "לא נכון",
    },
    "provider-picker": {
      "select-provider": "בחר ספק",
      "setup-required": "(נדרש התקנה)",
      "loading-models": "טעינת מודלים...",
      "select-model": "בחר מודל",
      "enter-model": "הזן שם המודל",
      "select-provider-first": "בחרו ספק תחילה",
      "configure-to-continue": "הגדר את {{name}} כדי להמשיך",
      "configure-provider": "הגדר {{name}}",
      "setup-credentials":
        "הזן את הפרטים הנדרשים כדי להשתמש ב-{{name}} כמיקוד.",
      cancel: "בטל",
      "save-settings": "שמירת הגדרות",
      "toast-save-failed": "לא הצליח לשמור הגדרות: {{error}}",
    },
    "router-selection": {
      "loading-routers": "טעינת מכשירי רשת מותאמים אישית...",
      "no-routers-prefix-settings": "עדיין לא הגדרתי נתב מסוג מסוים.",
      "no-routers-prefix-workspace": "אין מכשירי רשת מוגדרים.",
      "no-routers-link": "צור אחת בהגדרות של רשת הווירטואלית.",
      "model-router-label": "מודם לדוגמה",
      "select-router": "בחר נתב",
      "select-description":
        "בחר את הראוטר שתרצה להשתמש בו עבור אזור העבודה הזה.",
      "no-routers-chat":
        'אין מכשירי רשת מוגדרים. צרו אחד בתפריט "הגדרות" > "ספקי בינה מלאכותית" > "מכשיר רשת".',
      "rule-count": "({{count}} כללים)",
    },
    metrics: {
      "model-router-default": "מודל של רשת אלחוטית",
    },
    chat: {
      "select-router-error": "בחר/י נתב",
      "invalid-model": "בחירת מודל לא תקינה",
      "routed-to": "מופנה ל-{{model}} בתוך <route>",
      "routed-to-rule":
        "נשלח דרך <route>{{model}}</route> באמצעות <rule>{{ruleTitle}}</rule>",
    },
  },
};

export default TRANSLATIONS;
