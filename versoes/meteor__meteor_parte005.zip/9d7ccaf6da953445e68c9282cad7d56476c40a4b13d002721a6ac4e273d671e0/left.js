Package.describe({
  summary: "The Meteor command-line tool",
  version: '1.5.0-beta.12'
});

Package.includeTool();
