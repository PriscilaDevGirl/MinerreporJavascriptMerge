/*!
 * reveal.js 2.1 r32
 * http://lab.hakim.se/reveal-js
 * MIT licensed
 * 
 * Copyright (C) 2011-2012 Hakim El Hattab, http://hakim.se
 */
var Reveal=(function(){var l=".reveal .slides>section",b=".reveal .slides>section.present>section",R={controls:true,progress:true,history:false,keyboard:true,overview:true,loop:false,autoSlide:0,mouseWheel:true,rollingLinks:true,theme:null,transition:"default",dependencies:[]},Y=R.autoSlide,m=0,e=0,y,G,ai=[],f={},T="WebkitPerspective" in document.body.style||"MozPerspective" in document.body.style||"msPerspective" in document.body.style||"OPerspective" in document.body.style||"perspective" in document.body.style,n="WebkitTransform" in document.body.style||"MozTransform" in document.body.style||"msTransform" in document.body.style||"OTransform" in document.body.style||"transform" in document.body.style,z=0,k=0,D=0,ab={startX:0,startY:0,startSpan:0,startCount:0,handled:false,threshold:80};
function i(aj){if((!n&&!T)){document.body.setAttribute("class","no-transforms");return;}t(R,aj);P();d();V();}function P(){f.theme=document.querySelector("#theme");
f.wrapper=document.querySelector(".reveal");if(!f.wrapper.querySelector(".progress")&&R.progress){var am=document.createElement("div");am.classList.add("progress");
am.innerHTML="<span></span>";f.wrapper.appendChild(am);}if(!f.wrapper.querySelector(".controls")&&R.controls){var al=document.createElement("aside");al.classList.add("controls");
al.innerHTML='<a class="left" href="#">&#x25C4;</a><a class="right" href="#">&#x25BA;</a><a class="up" href="#">&#x25B2;</a><a class="down" href="#">&#x25BC;</a>';
f.wrapper.appendChild(al);}if(!f.wrapper.querySelector(".state-background")){var ak=document.createElement("div");ak.classList.add("state-background");
f.wrapper.appendChild(ak);}if(!f.wrapper.querySelector(".pause-overlay")){var aj=document.createElement("div");aj.classList.add("pause-overlay");f.wrapper.appendChild(aj);
}f.progress=document.querySelector(".reveal .progress");f.progressbar=document.querySelector(".reveal .progress span");if(R.controls){f.controls=document.querySelector(".reveal .controls");
f.controlsLeft=document.querySelector(".reveal .controls .left");f.controlsRight=document.querySelector(".reveal .controls .right");f.controlsUp=document.querySelector(".reveal .controls .up");
f.controlsDown=document.querySelector(".reveal .controls .down");}}function d(){if(navigator.userAgent.match(/(iphone|ipod|android)/i)){document.documentElement.style.overflow="scroll";
document.body.style.height="120%";window.addEventListener("load",ac,false);window.addEventListener("orientationchange",ac,false);}}function V(){var ak=[],ao=[];
for(var al=0,aj=R.dependencies.length;al<aj;al++){var am=R.dependencies[al];if(!am.condition||am.condition()){if(am.async){ao.push(am.src);}else{ak.push(am.src);
}if(typeof am.callback==="function"){head.ready(am.src.match(/([\w\d_\-]*)\.?[^\\\/]*$/i)[0],am.callback);}}}function an(){head.js.apply(null,ao);H();}if(ak.length){head.ready(an);
head.js.apply(null,ak);}else{an();}}function H(){E();K();J();N();}function K(){if(T===false){R.transition="linear";}if(R.controls&&f.controls){f.controls.style.display="block";
}if(R.progress&&f.progress){f.progress.style.display="block";}if(R.theme&&f.theme){var al=f.theme.getAttribute("href");var aj=/[^\/]*?(?=\.css)/;var ak=al.match(aj)[0];
if(R.theme!==ak){al=al.replace(aj,R.theme);f.theme.setAttribute("href",al);}}if(R.transition!=="default"){f.wrapper.classList.add(R.transition);}if(R.mouseWheel){document.addEventListener("DOMMouseScroll",p,false);
document.addEventListener("mousewheel",p,false);}if(R.rollingLinks){M();}}function E(){document.addEventListener("touchstart",A,false);document.addEventListener("touchmove",ae,false);
document.addEventListener("touchend",W,false);window.addEventListener("hashchange",w,false);if(R.keyboard){document.addEventListener("keydown",ag,false);
}if(R.controls&&f.controls){f.controlsLeft.addEventListener("click",q(B),false);f.controlsRight.addEventListener("click",q(j),false);f.controlsUp.addEventListener("click",q(u),false);
f.controlsDown.addEventListener("click",q(F),false);}}function U(){document.removeEventListener("keydown",ag,false);document.removeEventListener("touchstart",A,false);
document.removeEventListener("touchmove",ae,false);document.removeEventListener("touchend",W,false);window.removeEventListener("hashchange",w,false);if(R.controls&&f.controls){f.controlsLeft.removeEventListener("click",q(B),false);
f.controlsRight.removeEventListener("click",q(j),false);f.controlsUp.removeEventListener("click",q(u),false);f.controlsDown.removeEventListener("click",q(F),false);
}}function t(ak,aj){for(var al in aj){ak[al]=aj[al];}}function S(al,aj){var am=al.x-aj.x,ak=al.y-aj.y;return Math.sqrt(am*am+ak*ak);}function q(aj){return function(ak){ak.preventDefault();
aj.call();};}function ac(){setTimeout(function(){window.scrollTo(0,1);},0);}function r(ak,aj){var al=document.createEvent("HTMLEvents",1,2);al.initEvent(ak,true,true);
t(al,aj);f.wrapper.dispatchEvent(al);}function ag(ak){if(document.querySelector(":focus")!==null||ak.shiftKey||ak.altKey||ak.ctrlKey||ak.metaKey){return;
}var aj=true;switch(ak.keyCode){case 80:case 33:Z();break;case 78:case 34:x();break;case 72:case 37:B();break;case 76:case 39:j();break;case 75:case 38:u();
break;case 74:case 40:F();break;case 36:O(0);break;case 35:O(Number.MAX_VALUE);break;case 32:L()?ad():x();break;case 13:L()?ad():aj=false;break;case 66:case 190:aa();
break;default:aj=false;}if(aj){ak.preventDefault();}else{if(ak.keyCode===27&&T){X();ak.preventDefault();}}N();}function A(aj){ab.startX=aj.touches[0].clientX;
ab.startY=aj.touches[0].clientY;ab.startCount=aj.touches.length;if(aj.touches.length===2&&R.overview){ab.startSpan=S({x:aj.touches[1].clientX,y:aj.touches[1].clientY},{x:ab.startX,y:ab.startY});
}}function ae(ao){if(!ab.handled){var am=ao.touches[0].clientX;var al=ao.touches[0].clientY;if(ao.touches.length===2&&ab.startCount===2&&R.overview){var an=S({x:ao.touches[1].clientX,y:ao.touches[1].clientY},{x:ab.startX,y:ab.startY});
if(Math.abs(ab.startSpan-an)>ab.threshold){ab.handled=true;if(an<ab.startSpan){I();}else{ad();}}ao.preventDefault();}else{if(ao.touches.length===1&&ab.startCount!==2){var ak=am-ab.startX,aj=al-ab.startY;
if(ak>ab.threshold&&Math.abs(ak)>Math.abs(aj)){ab.handled=true;B();}else{if(ak<-ab.threshold&&Math.abs(ak)>Math.abs(aj)){ab.handled=true;j();}else{if(aj>ab.threshold){ab.handled=true;
u();}else{if(aj<-ab.threshold){ab.handled=true;F();}}}}ao.preventDefault();}}}else{if(navigator.userAgent.match(/android/gi)){ao.preventDefault();}}}function W(aj){ab.handled=false;
}function p(aj){clearTimeout(z);z=setTimeout(function(){var ak=aj.detail||-aj.wheelDelta;if(ak>0){x();}else{Z();}},100);}function w(aj){J();}function C(aj){if(L()){aj.preventDefault();
ad();m=this.getAttribute("data-index-h");e=this.getAttribute("data-index-v");a();}}function M(){if(T&&!("msPerspective" in document.body.style)){var ak=document.querySelectorAll(".reveal .slides section a:not(.image)");
for(var al=0,aj=ak.length;al<aj;al++){var am=ak[al];if(am.textContent&&!am.querySelector("img")&&(!am.className||!am.classList.contains(am,"roll"))){am.classList.add("roll");
am.innerHTML='<span data-title="'+am.text+'">'+am.innerHTML+"</span>";}}}}function I(){if(R.overview){f.wrapper.classList.add("overview");var aj=document.querySelectorAll(l);
for(var ao=0,am=aj.length;ao<am;ao++){var al=aj[ao],at="translateZ(-2500px) translate("+((ao-m)*105)+"%, 0%)";al.setAttribute("data-index-h",ao);al.style.display="block";
al.style.WebkitTransform=at;al.style.MozTransform=at;al.style.msTransform=at;al.style.OTransform=at;al.style.transform=at;if(!al.classList.contains("stack")){al.addEventListener("click",C,true);
}var ar=al.querySelectorAll("section");for(var an=0,ak=ar.length;an<ak;an++){var aq=ar[an],ap="translate(0%, "+((an-(ao===m?e:0))*105)+"%)";aq.setAttribute("data-index-h",ao);
aq.setAttribute("data-index-v",an);aq.style.display="block";aq.style.WebkitTransform=ap;aq.style.MozTransform=ap;aq.style.msTransform=ap;aq.style.OTransform=ap;
aq.style.transform=ap;aq.addEventListener("click",C,true);}}}}function ad(){if(R.overview){f.wrapper.classList.remove("overview");var am=Array.prototype.slice.call(document.querySelectorAll(".reveal .slides section"));
for(var al=0,aj=am.length;al<aj;al++){var ak=am[al];ak.style.WebkitTransform="";ak.style.MozTransform="";ak.style.msTransform="";ak.style.OTransform="";
ak.style.transform="";ak.removeEventListener("click",C);}a();}}function X(aj){if(typeof aj==="boolean"){aj?I():ad();}else{L()?ad():I();}}function L(){return f.wrapper.classList.contains("overview");
}function c(){f.wrapper.classList.add("paused");}function o(){f.wrapper.classList.remove("paused");}function aa(){if(af()){o();}else{c();}}function af(){return f.wrapper.classList.contains("paused");
}function ah(am,ar){var ak=Array.prototype.slice.call(document.querySelectorAll(am)),aq=ak.length;if(aq){if(R.loop){ar%=aq;if(ar<0){ar=aq+ar;}}ar=Math.max(Math.min(ar,aq-1),0);
for(var ao=0;ao<aq;ao++){var ap=ak[ao];if(L()===false){var aj=Math.abs((ar-ao)%(aq-3))||0;ap.style.display=aj>3?"none":"block";}ak[ao].classList.remove("past");
ak[ao].classList.remove("present");ak[ao].classList.remove("future");if(ao<ar){ak[ao].classList.add("past");}else{if(ao>ar){ak[ao].classList.add("future");
}}if(ap.querySelector("section")){ak[ao].classList.add("stack");}}ak[ar].classList.add("present");var al=ak[ar].getAttribute("data-state");if(al){ai=ai.concat(al.split(" "));
}var an=ak[ar].getAttribute("data-autoslide");if(an){Y=parseInt(an);}else{Y=R.autoSlide;}}else{ar=0;}return ar;}function a(ap,au){y=G;var am=ai.concat();
ai.length=0;var at=m,ak=e;m=ah(l,ap===undefined?m:ap);e=ah(b,au===undefined?e:au);stateLoop:for(var an=0,aq=ai.length;an<aq;an++){for(var al=0;al<am.length;
al++){if(am[al]===ai[an]){am.splice(al,1);continue stateLoop;}}document.documentElement.classList.add(ai[an]);r(ai[an]);}while(am.length){document.documentElement.classList.remove(am.pop());
}if(R.progress&&f.progress){f.progressbar.style.width=(m/(document.querySelectorAll(l).length-1))*window.innerWidth+"px";}if(L()){I();}s();clearTimeout(D);
D=setTimeout(h,1500);var aj=document.querySelectorAll(l);var ar=aj[m],ao=ar.querySelectorAll("section");G=ao[e]||ar;if(m!==at||e!==ak){r("slidechanged",{indexh:m,indexv:e,previousSlide:y,currentSlide:G});
}else{y=null;}if(y){y.classList.remove("present");}}function s(){if(!R.controls||!f.controls){return;}var aj=g();[f.controlsLeft,f.controlsRight,f.controlsUp,f.controlsDown].forEach(function(ak){ak.classList.remove("enabled");
});if(aj.left){f.controlsLeft.classList.add("enabled");}if(aj.right){f.controlsRight.classList.add("enabled");}if(aj.up){f.controlsUp.classList.add("enabled");
}if(aj.down){f.controlsDown.classList.add("enabled");}}function g(){var aj=document.querySelectorAll(l),ak=document.querySelectorAll(b);return{left:m>0,right:m<aj.length-1,up:e>0,down:e<ak.length-1};
}function J(){var ao=window.location.hash;var an=ao.slice(2).split("/"),al=ao.replace(/#|\//gi,"");if(isNaN(parseInt(an[0],10))&&al.length){var aj=document.querySelector("#"+al);
if(aj){var ap=Reveal.getIndices(aj);O(ap.h,ap.v);}else{O(m,e);}}else{var am=parseInt(an[0],10)||0,ak=parseInt(an[1],10)||0;O(am,ak);}}function h(){if(R.history){var aj="/";
if(m>0||e>0){aj+=m;}if(e>0){aj+="/"+e;}window.location.hash=aj;}}function v(){if(document.querySelector(b+".present")){var ak=document.querySelectorAll(b+".present .fragment:not(.visible)");
if(ak.length){ak[0].classList.add("visible");r("fragmentshown",{fragment:ak[0]});return true;}}else{var aj=document.querySelectorAll(l+".present .fragment:not(.visible)");
if(aj.length){aj[0].classList.add("visible");r("fragmentshown",{fragment:aj[0]});return true;}}return false;}function Q(){if(document.querySelector(b+".present")){var ak=document.querySelectorAll(b+".present .fragment.visible");
if(ak.length){ak[ak.length-1].classList.remove("visible");r("fragmenthidden",{fragment:ak[ak.length-1]});return true;}}else{var aj=document.querySelectorAll(l+".present .fragment.visible");
if(aj.length){aj[aj.length-1].classList.remove("visible");r("fragmenthidden",{fragment:aj[aj.length-1]});return true;}}return false;}function N(){clearTimeout(k);
if(Y){k=setTimeout(x,Y);}}function O(ak,aj){a(ak,aj);}function B(){if(L()||Q()===false){a(m-1,0);}}function j(){if(L()||v()===false){a(m+1,0);}}function u(){if(L()||Q()===false){a(m,e-1);
}}function F(){if(L()||v()===false){a(m,e+1);}}function Z(){if(Q()===false){if(g().up){u();}else{var aj=document.querySelector(".reveal .slides>section.past:nth-child("+m+")");
if(aj){e=(aj.querySelectorAll("section").length+1)||0;m--;a();}}}}function x(){if(v()===false){g().down?F():j();}N();}return{initialize:i,navigateTo:O,navigateLeft:B,navigateRight:j,navigateUp:u,navigateDown:F,navigatePrev:Z,navigateNext:x,toggleOverview:X,addEventListeners:E,removeEventListeners:U,getIndices:function(aj){var an=m,al=e;
if(aj){var ao=!!aj.parentNode.nodeName.match(/section/gi);var am=ao?aj.parentNode:aj;var ak=Array.prototype.slice.call(document.querySelectorAll(l));an=Math.max(ak.indexOf(am),0);
if(ao){al=Math.max(Array.prototype.slice.call(aj.parentNode.children).indexOf(aj),0);}}return{h:an,v:al};},getPreviousSlide:function(){return y;},getCurrentSlide:function(){return G;
},getQueryHash:function(){var aj={};location.search.replace(/[A-Z0-9]+?=(\w*)/gi,function(ak){aj[ak.split("=").shift()]=ak.split("=").pop();});return aj;
},addEventListener:function(ak,al,aj){if("addEventListener" in window){(f.wrapper||document.querySelector(".reveal")).addEventListener(ak,al,aj);}},removeEventListener:function(ak,al,aj){if("addEventListener" in window){(f.wrapper||document.querySelector(".reveal")).removeEventListener(ak,al,aj);
}}};})();