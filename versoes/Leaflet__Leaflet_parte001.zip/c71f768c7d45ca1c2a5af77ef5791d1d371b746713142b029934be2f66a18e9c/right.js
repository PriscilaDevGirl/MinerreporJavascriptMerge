
L.Projection.Mercator = {
	MAX_LATITUDE: 85.0840591556,
	
	R_MINOR: 6356752.3142,
	R_MAJOR: 6378137,
		
	project: function(/*LatLng*/ latlng) /*-> Point*/ {
		var d = L.LatLng.DEG_TO_RAD,
			max = this.MAX_LATITUDE,
			lat = Math.max(Math.min(max, latlng.lat), -max),
			r = this.R_MAJOR,
			x = latlng.lng * d * r,
			y = lat * d,
			tmp = this.R_MINOR / r,
			eccent = Math.sqrt(1.0 - tmp * tmp),
			con = eccent * Math.sin(y);
			
		con = Math.pow((1 - con)/(1 + con), eccent * 0.5);
		
		var ts = Math.tan(0.5 * ((Math.PI * 0.5) - y)) / con;
		y = -this.R_MINOR * Math.log(ts);
		
		return new L.Point(x, y);
	},
	
	unproject: function(/*Point*/ point, /*Boolean*/ unbounded) /*-> LatLng*/ {	
		var d = L.LatLng.RAD_TO_DEG,
			r = this.R_MAJOR,
			lng = point.x * d / r,
			tmp = this.R_MINOR / r,
			eccent = Math.sqrt(1 - (tmp * tmp)),
			ts = Math.exp(- point.y / this.R_MINOR),
			phi = Math.PI/2 - 2 * Math.atan(ts),
			numIter = 15,
			tol = 1e-7,
			i = numIter,
			dphi = 0.1,
			con;
		
		while ((Math.abs(dphi) > tol) && (--i > 0)) {
			con = eccent * Math.sin(phi);
			dphi = Math.PI/2 - 2 * Math.atan(ts * Math.pow((1.0 - con)/(1.0 + con), 0.5 * eccent)) - phi;
			phi += dphi;
		}
			
		return new L.LatLng(phi * d, lng, unbounded);
	}
};
