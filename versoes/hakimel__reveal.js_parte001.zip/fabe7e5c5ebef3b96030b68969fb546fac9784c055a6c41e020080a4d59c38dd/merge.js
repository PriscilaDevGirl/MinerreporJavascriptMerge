/*!
 * reveal.js 1.3
 * http://lab.hakim.se/reveal-js
 * MIT licensed
 * 
 * Copyright (C) 2012 Hakim El Hattab, http://hakim.se
 */
var Reveal=(function(){var j="#reveal .slides>section",a="#reveal .slides>section.present>section",e=!!("ontouchstart" in window),k=0,c=0,H={controls:false,progress:false,history:false,loop:false,mouseWheel:true,rollingLinks:true,transition:"default",theme:"default"},U=[],d={},J=document.body.style.perspectiveProperty!==undefined||document.body.style.WebkitPerspective!==undefined||document.body.style.MozPerspective!==undefined||document.body.style.msPerspective!==undefined||document.body.style.OPerspective!==undefined,l=document.body.style.transformProperty!==undefined||document.body.style.WebkitTransform!==undefined||document.body.style.MozTransform!==undefined||document.body.style.msTransform!==undefined||document.body.style.OTransform!==undefined,v=0,y=0,P={startX:0,startY:0,startSpan:0,startCount:0,handled:false,threshold:40};
function h(W){if(!l&&!J){document.body.setAttribute("class","no-transforms");return;}d.wrapper=document.querySelector("#reveal");d.progress=document.querySelector("#reveal .progress");
d.progressbar=document.querySelector("#reveal .progress span");d.controls=document.querySelector("#reveal .controls");d.controlsLeft=document.querySelector("#reveal .controls .left");
d.controlsRight=document.querySelector("#reveal .controls .right");d.controlsUp=document.querySelector("#reveal .controls .up");d.controlsDown=document.querySelector("#reveal .controls .down");
A();q(H,W);if(J===false){H.transition="linear";}if(H.controls){d.controls.style.display="block";}if(H.progress){d.progress.style.display="block";}if(H.transition!=="default"){d.wrapper.classList.add(H.transition);
}if(H.theme!=="default"){d.wrapper.classList.add(H.theme);}if(H.mouseWheel){document.addEventListener("DOMMouseScroll",m,false);document.addEventListener("mousewheel",m,false);
}if(H.rollingLinks){E();}D();if(navigator.userAgent.match(/(iphone|ipod|android)/i)){document.documentElement.style.overflow="scroll";document.body.style.height="120%";
window.addEventListener("load",Q,false);window.addEventListener("orientationchange",Q,false);}}function A(){document.addEventListener("keydown",T,false);
document.addEventListener("touchstart",w,false);document.addEventListener("touchmove",S,false);document.addEventListener("touchend",L,false);window.addEventListener("hashchange",t,false);
d.controlsLeft.addEventListener("click",n(x),false);d.controlsRight.addEventListener("click",n(i),false);d.controlsUp.addEventListener("click",n(r),false);
d.controlsDown.addEventListener("click",n(B),false);}function K(){document.removeEventListener("keydown",T,false);document.removeEventListener("touchstart",w,false);
document.removeEventListener("touchmove",S,false);document.removeEventListener("touchend",L,false);window.removeEventListener("hashchange",t,false);d.controlsLeft.removeEventListener("click",n(x),false);
d.controlsRight.removeEventListener("click",n(i),false);d.controlsUp.removeEventListener("click",n(r),false);d.controlsDown.removeEventListener("click",n(B),false);
}function q(X,W){for(var Y in W){X[Y]=W[Y];}}function I(Y,W){var Z=Y.x-W.x,X=Y.y-W.y;return Math.sqrt(Z*Z+X*X);}function n(W){return function(X){X.preventDefault();
W.call();};}function Q(){setTimeout(function(){window.scrollTo(0,1);},0);}function T(X){if(X.target.contentEditable!="inherit"||X.shiftKey||X.altKey||X.ctrlKey||X.metaKey){return;
}var W=false;switch(X.keyCode){case 80:case 33:N();W=true;break;case 78:case 34:u();W=true;break;case 72:case 37:x();W=true;break;case 76:case 39:i();W=true;
break;case 75:case 38:r();W=true;break;case 74:case 40:B();W=true;break;case 36:F(0);W=true;break;case 35:F(Number.MAX_VALUE);W=true;break;case 32:O()?R():u();
W=true;break;case 13:if(O()){R();W=true;}break;}if(W){X.preventDefault();}else{if(X.keyCode===27&&J){if(O()){R();}else{C();}X.preventDefault();}}}function w(W){P.startX=W.touches[0].clientX;
P.startY=W.touches[0].clientY;P.startCount=W.touches.length;if(W.touches.length===2){P.startSpan=I({x:W.touches[1].clientX,y:W.touches[1].clientY},{x:P.startX,y:P.startY});
}}function S(ab){if(!P.handled){var Z=ab.touches[0].clientX;var Y=ab.touches[0].clientY;if(ab.touches.length===2&&P.startCount===2){var aa=I({x:ab.touches[1].clientX,y:ab.touches[1].clientY},{x:P.startX,y:P.startY});
if(Math.abs(P.startSpan-aa)>P.threshold){P.handled=true;if(aa<P.startSpan){C();}else{R();}}}else{if(ab.touches.length===1){var X=Z-P.startX,W=Y-P.startY;
if(X>P.threshold&&Math.abs(X)>Math.abs(W)){P.handled=true;x();}else{if(X<-P.threshold&&Math.abs(X)>Math.abs(W)){P.handled=true;i();}else{if(W>P.threshold){P.handled=true;
r();}else{if(W<-P.threshold){P.handled=true;B();}}}}}}ab.preventDefault();}}function L(W){P.handled=false;}function m(W){clearTimeout(v);v=setTimeout(function(){var X=W.detail||-W.wheelDelta;
if(X>0){u();}else{N();}},100);}function t(W){D();}function E(){if(J){var X=document.querySelectorAll("#reveal .slides section a:not(.image)");for(var Y=0,W=X.length;
Y<W;Y++){var Z=X[Y];if(Z.textContent&&!Z.querySelector("img")&&(!Z.className||!Z.classList.contains(Z,"roll"))){Z.classList.add("roll");Z.innerHTML='<span data-title="'+Z.text+'">'+Z.innerHTML+"</span>";
}}}}function C(){d.wrapper.classList.add("overview");var W=Array.prototype.slice.call(document.querySelectorAll(j));for(var ab=0,Z=W.length;ab<Z;ab++){var Y=W[ab],af="translateZ(-2500px) translate("+((ab-k)*105)+"%, 0%)";
Y.setAttribute("data-index-h",ab);Y.style.display="block";Y.style.WebkitTransform=af;Y.style.MozTransform=af;Y.style.msTransform=af;Y.style.OTransform=af;
Y.style.transform=af;if(!Y.classList.contains("stack")){Y.addEventListener("click",z,true);}var ae=Array.prototype.slice.call(Y.querySelectorAll("section"));
for(var aa=0,X=ae.length;aa<X;aa++){var ad=ae[aa],ac="translate(0%, "+((aa-c)*105)+"%)";ad.setAttribute("data-index-h",ab);ad.setAttribute("data-index-v",aa);
ad.style.display="block";ad.style.WebkitTransform=ac;ad.style.MozTransform=ac;ad.style.msTransform=ac;ad.style.OTransform=ac;ad.style.transform=ac;ad.addEventListener("click",z,true);
}}}function R(){d.wrapper.classList.remove("overview");var Z=Array.prototype.slice.call(document.querySelectorAll("#reveal .slides section"));for(var Y=0,W=Z.length;
Y<W;Y++){var X=Z[Y];X.style.WebkitTransform="";X.style.MozTransform="";X.style.msTransform="";X.style.OTransform="";X.style.transform="";X.removeEventListener("click",z);
}b();}function O(){return d.wrapper.classList.contains("overview");}function z(W){if(O()){W.preventDefault();R();k=this.getAttribute("data-index-h");c=this.getAttribute("data-index-v");
b();}}function V(X,Z){var ab=Array.prototype.slice.call(document.querySelectorAll(X)),ac=ab.length;if(ac){if(H.loop){Z%=ac;if(Z<0){Z=ac+Z;}}Z=Math.max(Math.min(Z,ac-1),0);
for(var aa=0;aa<ac;aa++){var W=ab[aa];if(O()===false){var ad=Math.abs((Z-aa)%(ac-3))||0;W.style.display=ad>3?"none":"block";}ab[aa].classList.remove("past");
ab[aa].classList.remove("present");ab[aa].classList.remove("future");if(aa<Z){ab[aa].classList.add("past");}else{if(aa>Z){ab[aa].classList.add("future");
}}if(W.querySelector("section")){ab[aa].classList.add("stack");}}ab[Z].classList.add("present");var Y=ab[Z].getAttribute("data-state");if(Y){U=U.concat(Y.split(" "));
}}else{Z=0;}return Z;}function b(){var Z=U.concat();U.length=0;k=V(j,k);c=V(a,c);stateLoop:for(var Y=0,W=U.length;Y<W;Y++){for(var X=0;X<Z.length;X++){if(Z[X]===U[Y]){Z.splice(X,1);
continue stateLoop;}}document.documentElement.classList.add(U[Y]);o(U[Y]);}while(Z.length){document.documentElement.classList.remove(Z.pop());}if(H.progress){d.progressbar.style.width=(k/(document.querySelectorAll(j).length-1))*window.innerWidth+"px";
}if(O()){C();}p();clearTimeout(y);y=setTimeout(g,1500);o("slidechanged",{indexh:k,indexv:c});}function p(){var W=f();[d.controlsLeft,d.controlsRight,d.controlsUp,d.controlsDown].forEach(function(X){X.classList.remove("enabled");
});if(W.left){d.controlsLeft.classList.add("enabled");}if(W.right){d.controlsRight.classList.add("enabled");}if(W.up){d.controlsUp.classList.add("enabled");
}if(W.down){d.controlsDown.classList.add("enabled");}}function f(){var W=document.querySelectorAll(j);var X=document.querySelectorAll(a);return{left:k>0,right:k<W.length-1,up:c>0,down:c<X.length-1};
}function D(){var W=window.location.hash.slice(2).split("/");k=parseInt(W[0])||0;c=parseInt(W[1])||0;F(k,c);}function g(){if(H.history){var W="/";if(k>0||c>0){W+=k;
}if(c>0){W+="/"+c;}window.location.hash=W;}}function o(X,W){var Y=document.createEvent("HTMLEvents",1,2);Y.initEvent(X,true,true);q(Y,W);d.wrapper.dispatchEvent(Y);
}function s(){if(document.querySelector(a+".present")){var X=document.querySelectorAll(a+".present .fragment:not(.visible)");if(X.length){X[0].classList.add("visible");
o("fragmentshown",{fragment:X[0]});return true;}}else{var W=document.querySelectorAll(j+".present .fragment:not(.visible)");if(W.length){W[0].classList.add("visible");
o("fragmentshown",{fragment:W[0]});return true;}}return false;}function G(){if(document.querySelector(a+".present")){var X=document.querySelectorAll(a+".present .fragment.visible");
if(X.length){X[X.length-1].classList.remove("visible");o("fragmenthidden",{fragment:X[0]});return true;}}else{var W=document.querySelectorAll(j+".present .fragment.visible");
if(W.length){W[W.length-1].classList.remove("visible");o("fragmenthidden",{fragment:W[0]});return true;}}return false;}function F(X,W){k=X===undefined?k:X;
c=W===undefined?c:W;b();}function x(){if(O()||G()===false){k--;c=0;b();}}function i(){if(O()||s()===false){k++;c=0;b();}}function r(){if(O()||G()===false){c--;
b();}}function B(){if(O()||s()===false){c++;b();}}function N(){if(G()===false){if(f().up){r();}else{var W=document.querySelector("#reveal .slides>section.past:nth-child("+k+")");
if(W){c=(W.querySelectorAll("section").length+1)||0;k--;b();}}}}function u(){if(s()===false){f().down?B():i();}}function M(){if(O()){R();}else{C();}}return{initialize:h,navigateTo:F,navigateLeft:x,navigateRight:i,navigateUp:r,navigateDown:B,toggleOverview:M,addEventListener:function(X,Y,W){(d.wrapper||document.querySelector("#reveal")).addEventListener(X,Y,W);
},removeEventListener:function(X,Y,W){(d.wrapper||document.querySelector("#reveal")).removeEventListener(X,Y,W);}};})();