// Anything with "null" requires a translation. Contribute to translation via a PR!
const TRANSLATIONS = {
  onboarding: {
    home: {
      getStarted: "開始使用",
      welcome: "歡迎",
    },
    llm: {
      title: "LLM 偏好",
      description:
        "AnythingLLM 可搭配多種 LLM 提供者使用。這項服務會負責處理對話。",
    },
    userSetup: {
      title: "使用者設定",
      description: "設定使用者偏好。",
      howManyUsers: "這套系統會有多少位使用者？",
      justMe: "只有我",
      myTeam: "我的團隊",
      instancePassword: "系統密碼",
      setPassword: "要設定密碼嗎？",
      passwordReq: "密碼必須至少包含 8 個字元。",
      passwordWarn: "請務必妥善保存此密碼，因為目前沒有復原方式。",
      adminUsername: "管理員帳號使用者名稱",
      adminPassword: "管理員帳號密碼",
      adminPasswordReq: "密碼必須至少包含 8 個字元。",
      teamHint:
        "預設只有您擁有管理員權限。完成初始設定後，即可建立帳號並邀請其他人成為使用者或管理員。請勿遺失密碼，因為只有管理員能重設密碼。",
    },
    data: {
      title: "資料處理與隱私",
      description: "對於個人資料的處理方式，我們致力於提供透明度與控制權。",
      settingsHint: "這些設定之後都可以在設定頁面重新調整。",
    },
    survey: {
      title: "歡迎使用 AnythingLLM",
      description: "協助我們打造更符合需求的 AnythingLLM。此問卷為選填。",
      email: "您的電子郵件是什麼？",
      useCase: "您將如何使用 AnythingLLM？",
      useCaseWork: "用於工作",
      useCasePersonal: "用於個人使用",
      useCaseOther: "其他",
      comment: "您是從哪裡知道 AnythingLLM 的？",
      commentPlaceholder:
        "例如 Reddit、Twitter、GitHub、YouTube 等，告訴我們您是怎麼找到 AnythingLLM 的！",
      skip: "略過問卷",
      thankYou: "感謝您的回饋！",
    },
  },
  common: {
    "workspaces-name": "工作區名稱",
    selection: "模型選擇",
    saving: "儲存中...",
    save: "儲存變更",
    previous: "上一頁",
    next: "下一頁",
    optional: "選填",
    yes: "是",
    no: "否",
    search: "搜尋",
    username_requirements:
      "使用者名稱必須為 2-32 個字元，以小寫字母開頭，且只能包含小寫字母、數字、底線、連字號和句點。",
    on: "關於",
    none: "沒有",
    stopped: "停止",
    loading: "載入",
    refresh: "重新整理",
  },
  settings: {
    title: "系統設定",
    invites: "邀請",
    users: "使用者",
    workspaces: "工作區",
    "workspace-chats": "工作區對話紀錄",
    customization: "自訂",
    "api-keys": "開發者 API",
    llm: "大型語言模型 (LLM)",
    transcription: "語音轉錄",
    embedder: "向量嵌入器",
    "text-splitting": "文字分割與切塊",
    "voice-speech": "語音與發音",
    "vector-database": "向量資料庫",
    embeds: "對話嵌入",
    security: "安全性",
    "event-logs": "事件記錄",
    privacy: "隱私與資料",
    "ai-providers": "AI 服務提供者",
    "agent-skills": "智慧代理人技能",
    admin: "管理",
    tools: "工具",
    "experimental-features": "實驗性功能",
    contact: "聯絡支援",
    "browser-extension": "瀏覽器擴充功能",
    "system-prompt-variables": "系統提示變數",
    interface: "介面偏好",
    branding: "品牌與白標設定",
    chat: "對話",
    "mobile-app": "AnythingLLM 行動版",
    "community-hub": {
      title: "社群中心",
      trending: "探索熱門",
      "your-account": "您的帳戶",
      "import-item": "匯入項目",
    },
    channels: "頻道",
    "available-channels": {
      telegram: "電訊",
    },
    "scheduled-jobs": "預約排定的工作",
    "model-router": "模型路由器",
  },
  login: {
    "multi-user": {
      welcome: "歡迎使用",
      "placeholder-username": "使用者名稱",
      "placeholder-password": "密碼",
      login: "登入",
      validating: "驗證中...",
      "forgot-pass": "忘記密碼",
      reset: "重設",
    },
    "sign-in": "輸入使用者名稱與密碼，以存取您的 {{appName}} 系統。",
    "password-reset": {
      title: "重設密碼",
      description: "請在下方提供必要資訊以重設您的密碼。",
      "recovery-codes": "復原碼",
      "back-to-login": "返回登入",
    },
  },
  "new-workspace": {
    title: "新增工作區",
    placeholder: "我的工作區",
  },
  "workspaces—settings": {
    general: "一般設定",
    chat: "對話設定",
    vector: "向量資料庫",
    members: "成員",
    agent: "智慧代理人設定",
  },
  general: {
    vector: {
      title: "向量計數",
      description: "向量資料庫中的向量總數。",
    },
    names: {
      description: "只會變更工作區的顯示名稱。",
    },
    message: {
      title: "建議對話訊息",
      description: "自訂要推薦給工作區使用者的訊息。",
      add: "新增訊息",
      save: "儲存訊息",
      heading: "請向我說明",
      body: "AnythingLLM 的優點",
    },
    delete: {
      title: "刪除工作區",
      description: "刪除此工作區及其所有資料。所有使用者都會失去這個工作區。",
      delete: "刪除工作區",
      deleting: "正在刪除工作區...",
      "confirm-start": "您即將刪除整個",
      "confirm-end":
        "工作區。這會移除向量資料庫中的所有向量嵌入內容。\n\n原始來源檔案不會受影響。此動作無法復原。",
    },
  },
  chat: {
    llm: {
      title: "工作區 LLM 提供者",
      description:
        "這個工作區要使用的 LLM 提供者與模型。預設會沿用系統層級的 LLM 提供者與設定。",
      search: "搜尋所有 LLM 提供者",
    },
    model: {
      title: "工作區對話模型",
      description:
        "這個工作區要使用的對話模型。若留空，會沿用系統層級的 LLM 偏好設定。",
    },
    mode: {
      title: "對話模式",
      chat: {
        title: "對話",
        description:
          "將提供答案，並利用 LLM 的通用知識和相關文件內容。您需要使用 @agent 命令來使用工具。",
      },
      query: {
        title: "查詢",
        description:
          "將提供答案，但僅在確認文件內容時.<b>您需要使用 `@agent` 命令來使用工具。",
      },
      automatic: {
        description:
          "如果模型和供應商支援原生工具調用，則系統會自動使用這些工具。<br />如果原生工具調用不受支援，您需要使用 `@agent` 命令來使用工具。",
        title: "經紀人",
      },
    },
    history: {
      title: "對話紀錄",
      "desc-start": "會納入回應短期記憶的過往對話訊息數量。",
      recommend: "建議值為 20。",
    },
    prompt: {
      title: "系統提示詞",
      description:
        "這是此工作區會使用的提示詞，用來定義 AI 產生回應時的脈絡與指示。請提供經過仔細設計的提示詞，讓 AI 能產生相關且準確的回應。",
      history: {
        title: "系統提示詞歷史記錄",
        clearAll: "清除全部",
        noHistory: "目前沒有系統提示詞歷史記錄",
        restore: "復原",
        delete: "刪除",
        deleteConfirm: "您確定要刪除此歷史記錄項目嗎？",
        clearAllConfirm: "您確定要刪除所有歷史記錄嗎？此操作無法復原。",
        expand: "展開",
        publish: "發布到社群中心",
      },
    },
    refusal: {
      title: "查詢模式拒絕訊息",
      "desc-start": "在",
      query: "查詢",
      "desc-end": "模式下，若找不到內容，您可以設定自訂的拒絕回應。",
      "tooltip-title": "我為什麼會看到這個？",
      "tooltip-description":
        "目前處於查詢模式，這個模式只會使用文件中的資訊。若想進行更彈性的對話，請切換到對話模式；或點選這裡前往文件，進一步了解對話模式。",
    },
    temperature: {
      title: "LLM 溫度",
      "desc-end":
        "數值越高，創意度越高。對於某些模型，設定過高可能會導致不連貫的回應。",
    },
  },
  "vector-workspace": {
    identifier: "向量資料庫識別碼",
    snippets: {
      title: "最大內容片段數",
      description: "這項設定會控制每次對話或查詢送給 LLM 的內容片段上限。",
      recommend: "建議值：4",
    },
    doc: {
      title: "文件相似度門檻",
      description:
        "來源至少要達到這個相似度分數，才會被視為與對話相關。數值越高，代表來源必須越接近對話內容。",
      zero: "不限制",
      low: "低（相似度分數 ≥ .25）",
      medium: "中（相似度分數 ≥ .50）",
      high: "高（相似度分數 ≥ .75）",
    },
    reset: {
      reset: "重設向量資料庫",
      resetting: "正在清除向量...",
      confirm:
        "您即將重設這個工作區的向量資料庫。這會移除目前所有已嵌入的向量。\n\n原始來源檔案不會受影響。此動作無法復原。",
      error: "無法重設工作區向量資料庫！",
      success: "工作區向量資料庫已重設！",
    },
  },
  agent: {
    "performance-warning":
      "對於未明確支援工具呼叫的 LLM，其效能高度仰賴模型本身的能力與準確度。部分功能可能受限，甚至無法使用。",
    provider: {
      title: "工作區智慧代理人 LLM 提供者",
      description: "這個工作區的 @agent 會使用的 LLM 提供者與模型。",
    },
    mode: {
      chat: {
        title: "工作區 @agent 對話模型",
        description: "這個工作區的 @agent 會使用的對話模型。",
      },
      title: "工作區 @agent 模型",
      description: "這個工作區的 @agent 會使用的 LLM 模型。",
      wait: "-- 正在等待模型 --",
    },
    skill: {
      rag: {
        title: "RAG 與長期記憶體",
        description:
          "讓智慧代理人可運用本機文件回答問題，也能要求智慧代理人「記住」特定內容片段，以供長期記憶擷取。",
      },
      view: {
        title: "檢視並摘要文件",
        description: "允許智慧代理人列出並摘要目前已嵌入的工作區檔案內容。",
      },
      scrape: {
        title: "擷取網站",
        description: "允許智慧代理人瀏覽並擷取網站內容。",
      },
      generate: {
        title: "產生圖表",
        description:
          "讓預設智慧代理人能夠根據提供的資料或對話中給定的資料來產生各種圖表。",
      },
      web: {
        title: "網頁搜尋",
        description:
          "透過連接網頁搜尋 (SERP) 提供者，讓智慧代理人能搜尋網路並回答問題。",
      },
      sql: {
        title: "SQL 連接器",
        description:
          "讓您的智慧代理人能夠利用 SQL 查詢來回答您的問題，只需連接到不同的 SQL 資料庫提供者即可。",
      },
      default_skill: "這項技能預設為啟用；若不希望智慧代理人使用，也可以停用。",
      filesystem: {
        title: "檔案系統存取",
        description:
          "允許您的代理程式在指定目錄中讀取、寫入、搜尋和管理檔案。支援檔案編輯、目錄導航和內容搜尋功能。",
        learnMore: "了解更多關於如何運用這項技能的資訊",
        configuration: "設定",
        readActions: "閱讀行動",
        writeActions: "撰寫動作",
        warning:
          "訪問檔案系統可能存在風險，因為它可能會修改或刪除檔案。在啟用之前，請務必查閱相關<a>文件</a>。",
        skills: {
          "read-text-file": {
            title: "開啟檔案",
            description: "閱讀檔案內容（包括文字、程式碼、PDF 文件、圖片等）",
          },
          "read-multiple-files": {
            title: "閱讀多個檔案",
            description: "同時讀取多個檔案",
          },
          "list-directory": {
            title: "名錄索引",
            description: "列出指定資料夾中的檔案和目錄",
          },
          "search-files": {
            title: "搜尋檔案",
            description: "按檔案名稱或內容來搜尋",
          },
          "get-file-info": {
            title: "取得檔案資訊",
            description: "獲取關於檔案的詳細元數據",
          },
          "edit-file": {
            title: "編輯檔案",
            description: "能夠對文字檔案進行行別編輯。",
          },
          "create-directory": {
            title: "建立資料夾",
            description: "建立新的資料夾",
          },
          "move-file": {
            title: "移動/更名檔案",
            description: "移動或更名檔案和資料夾",
          },
          "copy-file": {
            title: "複製檔案",
            description: "複製檔案和目錄",
          },
          "write-text-file": {
            title: "撰寫文字檔案",
            description: "建立新的文字檔，或覆蓋現有的文字檔。",
          },
        },
      },
      createFiles: {
        title: "文件建立",
        description:
          "允許您的代理創建二元文件格式，例如PowerPoint簡報、Excel電子表格、Word文件和PDF文件。 文件可以直接從聊天窗口下載。",
        configuration: "可用的文件類型",
        skills: {
          "create-text-file": {
            title: "文字檔",
            description:
              "能夠創建包含任何內容和檔案擴展名（例如：.txt、.md、.json、.csv 等）的文字檔案。",
          },
          "create-pptx": {
            title: "PowerPoint 簡報",
            description: "創建新的 PowerPoint 簡報，包含幻燈片、標題和要點",
          },
          "create-pdf": {
            title: "PDF 文件",
            description:
              "能夠從 Markdown 或純文字檔案中，使用基本的格式設定，創建 PDF 文件。",
          },
          "create-xlsx": {
            title: "Excel 試算表",
            description: "建立包含表格資料、工作表和樣式的 Excel 文件",
          },
          "create-docx": {
            title: "Word 格式的文件",
            description: "建立包含基本樣式和格式的 Word 文件",
          },
        },
      },
      gmail: {
        title: "Gmail 連接器",
        description:
          "讓您的代理能夠與 Gmail 互動：搜尋郵件、閱讀郵件討論、撰寫草稿、發送郵件，以及管理您的收件匣。請參閱相關文件。",
        multiUserWarning:
          "由於安全考量，Gmail 整合功能在多使用者模式下無法使用。請停用多使用者模式才能使用此功能。",
        configuration: "Gmail 設定",
        deploymentId: "部署 ID",
        deploymentIdHelp: "您的 Google Apps Script 網頁應用程式的部署 ID",
        apiKey: "API 關鍵字",
        apiKeyHelp: "您在 Google Apps Script 部署中設定的 API 金鑰",
        configurationRequired: "請設定部署 ID 和 API 關鍵，以啟用 Gmail 功能。",
        configured: "設定",
        searchSkills: "搜尋技巧...",
        noSkillsFound: "沒有符合您搜尋條件的結果。",
        categories: {
          search: {
            title: "搜尋和閱讀電子郵件",
            description: "搜尋並閱讀您 Gmail 收件匣中的電子郵件。",
          },
          drafts: {
            title: "草稿郵件",
            description: "創建、編輯和管理電子郵件草稿",
          },
          send: {
            title: "發送和回覆電子郵件",
            description: "立即發送電子郵件並回覆討論串",
          },
          threads: {
            title: "管理電子郵件串",
            description: "管理電子郵件對話 - 標示已讀/未讀、歸檔、刪除",
          },
          account: {
            title: "整合統計",
            description: "查看郵箱統計資料和帳戶資訊",
          },
        },
        skills: {
          search: {
            title: "搜尋郵件",
            description: "使用 Gmail 的查詢語法搜尋電子郵件",
          },
          readThread: {
            title: "閱讀主題",
            description: "閱讀由 ID 創建的完整電子郵件對話",
          },
          createDraft: {
            title: "建立草稿",
            description: "建立新的電子郵件草稿",
          },
          createDraftReply: {
            title: "撰寫草稿回覆",
            description: "撰寫一份針對已有的討論串的回覆草稿。",
          },
          updateDraft: {
            title: "更新草稿",
            description: "更新現有電子郵件草稿",
          },
          getDraft: {
            title: "取得草稿",
            description: "根據 ID 取得特定草稿",
          },
          listDrafts: {
            title: "草稿清單",
            description: "列出所有草稿電子郵件",
          },
          deleteDraft: {
            title: "刪除草稿",
            description: "刪除草稿電子郵件",
          },
          sendDraft: {
            title: "發送草稿",
            description: "發送現有電子郵件草稿",
          },
          sendEmail: {
            title: "發送電子郵件",
            description: "立即發送電子郵件",
          },
          replyToThread: {
            title: "回覆主題",
            description: "立即回覆電子郵件討論串",
          },
          markRead: {
            title: "馬克·瑞德",
            description: "標示某個主題已閱讀",
          },
          markUnread: {
            title: "標示為未讀",
            description: "將某個主題標示為未讀",
          },
          moveToTrash: {
            title: "移至垃圾桶",
            description: "將主題移動到垃圾桶",
          },
          moveToArchive: {
            title: "檔案",
            description: "將主題歸檔",
          },
          moveToInbox: {
            title: "移動到收件匣",
            description: "將主題移動到收件匣",
          },
          getMailboxStats: {
            title: "郵箱統計",
            description: "查看未讀郵件數量及郵箱統計數據",
          },
          getInbox: {
            title: "開啟收件匣",
            description: "簡潔的方式，讓您能輕鬆取得 Gmail 郵箱中的郵件。",
          },
        },
      },
      outlook: {
        title: "Outlook 連接器",
        description:
          "讓您的代理能夠與 Microsoft Outlook 互動 - 搜尋郵件、閱讀討論串、撰寫草稿、發送郵件，以及透過 Microsoft Graph API 管理您的收件匣。 詳情請參考<a>相關文件</a>。",
        multiUserWarning:
          "由於安全原因，Outlook 整合功能在多使用者模式下無法使用。請先停用多使用者模式，才能使用此功能。",
        configuration: "視圖配置",
        authType: "帳戶類型",
        authTypeHelp:
          "選擇哪些類型的 Microsoft 帳戶可以進行驗證。「所有帳戶」支援個人帳戶和工作/學校帳戶。「僅限個人帳戶」僅支援個人 Microsoft 帳戶。「僅限組織帳戶」僅支援特定 Azure AD 租戶中的工作/學校帳戶。",
        authTypeCommon: "所有帳戶（個人帳戶及工作/學校帳戶）",
        authTypeConsumers: "僅限個人 Microsoft 帳戶",
        authTypeOrganization: "僅限於組織帳戶（需要租戶 ID）",
        clientId: "申請者（客戶）編號",
        clientIdHelp: "您的 Azure AD 應用程式註冊產生的應用程式 ID",
        tenantId: "租戶編號",
        tenantIdHelp:
          "您的 Azure AD 應用程式註冊的「租戶 ID」。僅用於組織內單向驗證。",
        clientSecret: "客戶密鑰",
        clientSecretHelp: "您的 Azure AD 應用程式註冊時所使用的客戶端秘密值",
        configurationRequired:
          "請設定 Client ID 和 Client Secret，以便啟用 Outlook 相關功能。",
        authRequired:
          "首先儲存您的帳戶資訊，然後再透過 Microsoft 進行驗證，以完成設定。",
        authenticateWithMicrosoft: "使用 Microsoft 驗證",
        authenticated: "已成功與 Microsoft Outlook 驗證連線。",
        revokeAccess: "撤銷權限",
        configured: "設定",
        searchSkills: "搜尋技巧...",
        noSkillsFound: "沒有符合您搜尋條件的結果。",
        categories: {
          search: {
            title: "搜尋和閱讀電子郵件",
            description: "搜尋並閱讀您 Outlook 收件匣中的電子郵件",
          },
          drafts: {
            title: "草稿郵件",
            description: "創建、編輯和管理電子郵件草稿",
          },
          send: {
            title: "發送電子郵件",
            description: "即時發送新的電子郵件或回覆訊息",
          },
          account: {
            title: "整合統計數據",
            description: "查看郵箱統計資料和帳戶資訊",
          },
        },
        skills: {
          getInbox: {
            title: "開啟收件匣",
            description: "從您的 Outlook 郵箱取得最近的郵件",
          },
          search: {
            title: "搜尋電子郵件",
            description: "使用 Microsoft 搜尋語法來搜尋電子郵件",
          },
          readThread: {
            title: "閱讀對話",
            description: "閱讀完整的電子郵件對話紀錄",
          },
          createDraft: {
            title: "建立草稿",
            description: "建立新的電子郵件草稿，或回覆現有訊息的草稿。",
          },
          updateDraft: {
            title: "更新草稿",
            description: "更新現有電子郵件草稿",
          },
          listDrafts: {
            title: "草稿清單",
            description: "列出所有草稿電子郵件",
          },
          deleteDraft: {
            title: "刪除草稿",
            description: "刪除草稿郵件",
          },
          sendDraft: {
            title: "發送草稿",
            description: "發送現有電子郵件草稿",
          },
          sendEmail: {
            title: "發送電子郵件",
            description: "發送新的電子郵件或立即回覆現有訊息",
          },
          getMailboxStats: {
            title: "郵箱統計",
            description: "取得資料夾數量和郵箱統計數據",
          },
        },
      },
      googleCalendar: {
        title: "Google 日曆連線",
        description:
          "讓您的代理能夠與 Google 日曆互動：查看日曆、取得活動資訊、創建和更新活動，以及管理確認出席。 詳情請參考<a>文件</a>。",
        multiUserWarning:
          "由於安全原因，Google 日曆的整合功能在多使用者模式下無法使用。請先停用多使用者模式，然後再使用此功能。",
        configuration: "Google 日曆設定",
        deploymentId: "部署 ID",
        deploymentIdHelp: "您的 Google Apps Script 網頁應用程式的部署 ID",
        apiKey: "API 關鍵字",
        apiKeyHelp: "您在 Google Apps Script 部署中設定的 API 金鑰。",
        configurationRequired:
          "請設定部署 ID 和 API 鑰，以啟用 Google 日曆功能。",
        configured: "已設定",
        searchSkills: "搜尋技巧...",
        noSkillsFound: "沒有符合您搜尋條件的結果。",
        categories: {
          calendars: {
            title: "日曆",
            description: "檢視和管理您的 Google 日曆",
          },
          readEvents: {
            title: "閱讀活動",
            description: "查看和搜尋日曆活動",
          },
          writeEvents: {
            title: "建立與更新活動",
            description: "創建新的活動，並修改現有的活動。",
          },
          rsvp: {
            title: "請假確認管理",
            description: "管理您參加活動的回應狀態",
          },
        },
        skills: {
          listCalendars: {
            title: "日曆清單",
            description: "列出您擁有的或訂閱的全部日曆",
          },
          getCalendar: {
            title: "獲取日曆細節",
            description: "獲取有關特定日曆的詳細資訊",
          },
          getEvent: {
            title: "取得活動",
            description: "獲取有關特定活動的詳細資訊",
          },
          getEventsForDay: {
            title: "獲取特定日期的活動",
            description: "列出特定日期的所有活動",
          },
          getEvents: {
            title: "取得活動（日期範圍）",
            description: "取得指定日期範圍內的活動",
          },
          getUpcomingEvents: {
            title: "查看即將到來的活動",
            description: "使用簡單的關鍵字，即可查詢今日、本週或本月的活動",
          },
          quickAdd: {
            title: "快速新增活動",
            description:
              "從自然語言（例如：「明天下午 3 點舉行會議」）創建活動。",
          },
          createEvent: {
            title: "建立活動",
            description: "創建一個新的活動，並擁有對所有屬性的完全控制。",
          },
          updateEvent: {
            title: "活動更新",
            description: "更新現有的日曆事件",
          },
          setMyStatus: {
            title: "設定確認參加狀態",
            description: "接受、拒絕或表示暫時接受活動",
          },
        },
      },
      scheduledJob: {
        title: "建立排程工作",
        description:
          "允許經理根據聊天內容，設定重複執行的工作（例如：「每天早上9點，請自動整理我的收件匣並將摘要發送至我的電子郵件」）。僅適用於單一使用者模式。",
      },
    },
    mcp: {
      title: "MCP 伺服器",
      "loading-from-config": "從設定檔中載入 MCP 伺服器",
      "learn-more": "了解更多關於 MCP 伺服器的資訊。",
      "no-servers-found": "未找到任何 MCP 伺服器",
      "tool-warning": "為了獲得最佳效能，建議關閉不必要的工具，以節省資源。",
      "stop-server": "停止 MCP 伺服器",
      "start-server": "啟動 MCP 伺服器",
      "delete-server": "刪除 MCP 伺服器",
      "tool-count-warning":
        "這個 MCP 伺服器已啟用 <b> 工具，這些工具會消耗聊天中的語境 </b>。建議停用不需要的工具，以節省語境。",
      "startup-command": "啟動指令",
      command: "指令",
      arguments: "辯論",
      "not-running-warning":
        "這個 MCP 伺服器目前處於停止狀態，可能是因為已停止運作，或是啟動時出現錯誤。",
      "tool-call-arguments": "工具呼叫的參數",
      "tools-enabled": "已啟用工具",
    },
    settings: {
      title: "代理人技能設定",
      "max-tool-calls": {
        title: "每次回應的最大工具呼叫次數",
        description:
          "這設定了代理可以串聯使用的最大工具數量，以確保每次回應只會呼叫有限的工具，並避免無限循環。",
      },
      "intelligent-skill-selection": {
        title: "智能技能選擇",
        "beta-badge": "β 版本",
        description:
          "啟用無限多個工具，並將每個查詢的 token 使用量最多降低 80% — AnythingLLM 能夠自動選擇最適合的技能，以處理每一個提示。",
        "max-tools": {
          title: "馬克斯工具",
          description:
            "可選取的工具的最大數量，適用於每個查詢。我們建議將此值設定為較高的值，以適用於較大的模型。",
        },
      },
      "clarifying-questions": {
        title: "允許經紀人提出確認性問題",
        "beta-badge": "測試版",
        description:
          "啟用後，代理可以暫停，並向您提出簡短的澄清問題，以釐清您的指示。",
        "max-per-turn": {
          title: "每回合可以提出的問題數量",
          description: "經理在單次調查中，可以提出多少澄清問題？",
        },
      },
    },
  },
  recorded: {
    title: "工作區對話紀錄",
    description: "這裡列出所有已記錄的對話與訊息，依建立時間排序。",
    export: "匯出",
    table: {
      id: "編號",
      by: "傳送者",
      workspace: "工作區",
      prompt: "提示詞",
      response: "回應",
      at: "傳送時間",
    },
  },
  api: {
    title: "API 金鑰",
    description:
      "API 金鑰可讓持有人透過程式方式存取並管理這個 AnythingLLM 系統。",
    link: "閱讀 API 文件",
    generate: "產生新的 API 金鑰",
    empty: "找不到 API 金鑰",
    actions: "操作",
    messages: {
      error: "錯誤：{{error}}",
    },
    modal: {
      title: "建立新的 API 金鑰",
      cancel: "取消",
      close: "關閉",
      create: "建立 API 金鑰",
      helper:
        "建立後，API 金鑰可用於以程式方式存取並設定這個 AnythingLLM 執行個體。",
      name: {
        label: "名稱",
        placeholder: "正式環境整合",
        helper: "選填。請使用易於辨識的名稱，方便你之後識別這把金鑰。",
      },
    },
    row: {
      copy: "複製 API 金鑰",
      copied: "已複製",
      unnamed: "--",
      deleteConfirm:
        "確定要停用此 API 金鑰嗎？\n停用後將無法再使用。\n\n此操作無法復原。",
    },
    table: {
      name: "名稱",
      key: "API 金鑰",
      by: "建立者",
      created: "建立時間",
    },
  },
  llm: {
    title: "LLM 偏好設定",
    description:
      "這裡設定偏好的 LLM 對話與嵌入提供者之認證資訊與參數。請確認金鑰保持最新且正確，否則 AnythingLLM 可能無法正常運作。",
    provider: "LLM 提供者",
    providers: {
      azure_openai: {
        azure_service_endpoint: "Azure 服務端點",
        api_key: "API 金鑰",
        chat_deployment_name: "對話部署名稱",
        chat_model_token_limit: "對話模型 Token 上限",
        model_type: "模型類型",
        default: "預設",
        reasoning: "推理",
        model_type_tooltip:
          "如果您的部署使用推理模型（例如 o1、o1-mini、o3-mini 等），請將此設定設為「推理」。否則，您的對話請求可能會失敗。",
      },
    },
  },
  transcription: {
    title: "語音轉錄模型偏好設定",
    description:
      "這裡設定偏好的語音轉錄模型提供者之認證資訊與參數。請確認金鑰保持最新且正確，否則媒體檔與音訊可能無法完成轉錄。",
    provider: "語音轉錄提供者",
    "warn-start":
      "在記憶體或 CPU 資源有限的電腦上使用本機 Whisper 模型時，處理媒體檔案可能會讓 AnythingLLM 卡住。",
    "warn-recommend": "建議至少保留 2 GB 記憶體，且上傳檔案小於 10 MB。",
    "warn-end": "內建模型將會在第一次使用時自動下載。",
  },
  embedding: {
    title: "嵌入模型偏好設定",
    "desc-start":
      "使用原生不支援嵌入引擎的 LLM 時，可能需要另外提供文字嵌入的認證資訊。",
    "desc-end":
      "嵌入是把文字轉成向量的過程。這些認證資訊用來把檔案與提示詞轉成 AnythingLLM 可處理的格式。",
    provider: {
      title: "向量嵌入提供者",
    },
  },
  text: {
    title: "文字分割與切塊偏好設定",
    "desc-start":
      "有時您可能想調整新文件在寫入向量資料庫前的預設分割與切塊方式。",
    "desc-end":
      "只有在清楚了解文字分割的運作方式及其副作用時，才建議調整此設定。",
    size: {
      title: "文字區塊大小",
      description: "單一向量可包含的最大字元長度。",
      recommend: "嵌入模型的最大長度為",
    },
    overlap: {
      title: "文字切塊重疊",
      description: "切塊時兩個相鄰文字區塊之間允許的最大重疊字元數。",
    },
  },
  vector: {
    title: "向量資料庫",
    description:
      "這裡設定 AnythingLLM 系統運作所需的認證資訊與參數。請務必確認金鑰保持最新且正確。",
    provider: {
      title: "向量資料庫提供者",
      description: "使用 LanceDB 不需要任何設定。",
    },
  },
  embeddable: {
    title: "可嵌入對話元件",
    description:
      "可嵌入對話元件是綁定單一工作區、可對外公開的對話介面。您可以建立工作區，再將它發布給外部使用。",
    create: "建立嵌入元件",
    table: {
      workspace: "工作區",
      chats: "已傳送對話",
      active: "啟用中的網域",
      created: "建立",
    },
  },
  "embed-chats": {
    title: "嵌入對話記錄",
    export: "匯出",
    description: "這裡列出所有來自已發布嵌入元件的對話與訊息紀錄。",
    table: {
      embed: "嵌入",
      sender: "傳送者",
      message: "訊息",
      response: "回應",
      at: "傳送時間",
    },
  },
  event: {
    title: "事件記錄",
    description: "檢視這套系統上發生的所有動作與事件，以便監控。",
    clear: "清除事件記錄",
    table: {
      type: "事件類型",
      user: "使用者",
      occurred: "發生時間",
    },
  },
  privacy: {
    title: "隱私與資料處理",
    description: "這裡設定已連線的第三方提供者與 AnythingLLM 會如何處理資料。",
    anonymous: "已啟用匿名遙測",
  },
  connectors: {
    "search-placeholder": "搜尋資料連接器",
    "no-connectors": "未找到資料連接器。",
    github: {
      name: "GitHub 儲存庫",
      description: "一鍵匯入整個公開或私有的 GitHub 儲存庫。",
      URL: "GitHub 儲存庫網址",
      URL_explained: "您希望收集的 GitHub 儲存庫網址。",
      token: "GitHub 存取權杖",
      optional: "可選",
      token_explained: "存取權杖以防止速率限制。",
      token_explained_start: "若沒有 ",
      token_explained_link1: "個人存取權杖",
      token_explained_middle:
        "，GitHub API 可能會因為速率限制而限制可收集的檔案數量。您可以 ",
      token_explained_link2: "建立一個臨時的存取權杖",
      token_explained_end: " 來避免此問題。",
      ignores: "忽略檔案",
      git_ignore:
        "以 .gitignore 格式列出以忽略特定檔案。每輸入一個條目後按 Enter 鍵儲存。",
      task_explained: "完成後，所有檔案將可供嵌入到工作區中的檔案選擇器。",
      branch: "您希望收集檔案的分支。",
      branch_loading: "-- 載入可用分支 --",
      branch_explained: "您希望收集檔案的分支。",
      token_information:
        "若未填寫 <b>GitHub 存取權杖</b>，此資料連接器僅能收集儲存庫的 <b>頂層</b> 檔案，因 GitHub 的公開 API 速率限制。",
      token_personal: "在此獲取免費的 GitHub 個人存取權杖。",
    },
    gitlab: {
      name: "GitLab 儲存庫",
      description: "一鍵匯入整個公開或私有的 GitLab 儲存庫。",
      URL: "GitLab 儲存庫網址",
      URL_explained: "您希望收集的 GitLab 儲存庫網址。",
      token: "GitLab 存取權杖",
      optional: "可選",
      token_description: "選擇要從 GitLab API 中擷取的其他實體。",
      token_explained_start: "若沒有 ",
      token_explained_link1: "個人存取權杖",
      token_explained_middle:
        "，GitLab API 可能會因為速率限制而限制可收集的檔案數量。您可以 ",
      token_explained_link2: "建立一個臨時的存取權杖",
      token_explained_end: " 來避免此問題。",
      fetch_issues: "擷取問題作為文件",
      ignores: "忽略檔案",
      git_ignore:
        "以 .gitignore 格式列出以忽略特定檔案。每輸入一個條目後按 Enter 鍵儲存。",
      task_explained: "完成後，所有檔案將可供嵌入到工作區中的檔案選擇器。",
      branch: "您希望收集檔案的分支",
      branch_loading: "-- 載入可用分支 --",
      branch_explained: "您希望收集檔案的分支。",
      token_information:
        "若未填寫 <b>GitLab 存取權杖</b>，此資料連接器僅能收集儲存庫的 <b>頂層</b> 檔案，因 GitLab 的公開 API 速率限制。",
      token_personal: "在此獲取免費的 GitLab 個人存取權杖。",
    },
    youtube: {
      name: "YouTube 文字稿",
      description: "從連結匯入整個 YouTube 影片的文字稿。",
      URL: "YouTube 影片網址",
      URL_explained_start:
        "輸入任何 YouTube 影片的網址以擷取其文字稿。該影片必須擁有 ",
      URL_explained_link: "字幕",
      URL_explained_end: " 來提供文字稿。",
      task_explained: "完成後，文字稿將可供嵌入到工作區中的檔案選擇器。",
    },
    "website-depth": {
      name: "批次連結擷取器",
      description: "擷取網站及其子連結，直到指定深度。",
      URL: "網站網址",
      URL_explained: "您希望擷取的網站網址。",
      depth: "擷取深度",
      depth_explained: "系統會從起始網址往下追蹤的子連結層數。",
      max_pages: "最大頁數",
      max_pages_explained: "最大擷取連結數量。",
      task_explained:
        "完成後，所有擷取的內容將可供嵌入到工作區中的檔案選擇器。",
    },
    confluence: {
      name: "Confluence",
      description: "一鍵匯入整個 Confluence 頁面。",
      deployment_type: "Confluence 部署類型",
      deployment_type_explained:
        "確認 Confluence 環境是託管於 Atlassian 雲端，還是自行託管。",
      base_url: "Confluence 基本網址",
      base_url_explained: "這是您的 Confluence 空間的基本網址。",
      space_key: "Confluence 空間金鑰",
      space_key_explained:
        "這是 Confluence 環境要使用的空間金鑰，通常會以 ~ 開頭。",
      username: "Confluence 使用者名稱",
      username_explained: "請輸入 Confluence 使用者名稱。",
      auth_type: "Confluence 認證類型",
      auth_type_explained: "選擇您希望用來存取 Confluence 頁面的認證類型。",
      auth_type_username: "使用者名稱和存取權杖",
      auth_type_personal: "個人存取權杖",
      token: "Confluence 存取權杖",
      token_explained_start: "需要提供存取權杖才能完成驗證。您可以在 ",
      token_explained_link: "這裡",
      token_desc: "用於認證的存取權杖",
      pat_token: "Confluence 個人存取權杖",
      pat_token_explained: "您的 Confluence 個人存取權杖。",
      task_explained: "完成後，頁面內容將可供嵌入到工作區中的檔案選擇器。",
      bypass_ssl: "跳過 SSL 憑證驗證",
      bypass_ssl_explained:
        "若是使用自簽憑證的自行託管 Confluence 環境，可啟用此選項略過 SSL 憑證驗證。",
    },
    manage: {
      documents: "文件",
      "data-connectors": "資料連接器",
      "desktop-only":
        "編輯這些設定僅在桌面裝置上可用。請在桌面上開啟此頁面以繼續。",
      dismiss: "忽略",
      editing: "編輯中",
    },
    directory: {
      "my-documents": "我的文件",
      "new-folder": "新資料夾",
      "search-document": "搜尋文件",
      "no-documents": "無文件",
      "move-workspace": "移動到工作區",
      "delete-confirmation":
        "您確定要刪除這些檔案和資料夾嗎？\n這將從系統中刪除這些檔案並自動從任何現有工作區中移除它們。\n此操作無法還原。",
      "removing-message":
        "正在刪除 {{count}} 份文件和 {{folderCount}} 個資料夾，請稍候。",
      "move-success": "已成功移動 {{count}} 份文件。",
      no_docs: "無文件",
      select_all: "全選",
      deselect_all: "取消全選",
      remove_selected: "移除選擇的項目",
      save_embed: "儲存並嵌入",
      "total-documents_one": "{{count}} 文件",
      "total-documents_other": "{{count}} 文件",
    },
    upload: {
      "processor-offline": "文件處理器無法使用",
      "processor-offline-desc":
        "目前無法上傳檔案，因為文件處理器已離線。請稍後再試。",
      "click-upload": "點選以上傳，或直接拖放檔案",
      "file-types": "支援文字檔、CSV、試算表、音訊檔等格式！",
      "or-submit-link": "或貼上連結",
      "placeholder-link": "https://example.com",
      fetching: "正在擷取...",
      "fetch-website": "擷取網站",
      "privacy-notice":
        "這些檔案會上傳到此 AnythingLLM 系統上的文件處理器，不會傳送給或分享給第三方。",
    },
    pinning: {
      what_pinning: "什麼是文件釘選？",
      pin_explained_block1:
        "當您在 AnythingLLM 中<b>釘選</b>文件時，系統會把整份文件的內容注入提示詞輸入區，讓 LLM 能完整理解。",
      pin_explained_block2:
        "這最適合搭配<b>大上下文模型</b>，或對知識庫很重要的小型文件。",
      pin_explained_block3:
        "如果 AnythingLLM 在預設情況下給不出想要的答案，釘選文件是快速提升回答品質的好方法。",
      accept: "好的，明白了",
    },
    watching: {
      what_watching: "追蹤文件有何作用？",
      watch_explained_block1:
        "當您在 AnythingLLM 中<b>追蹤</b>文件時，系統會<i>自動</i>定期從原始來源同步內容，並更新所有管理這份文件的工作區。",
      watch_explained_block2:
        "目前這項功能只支援線上來源內容，手動上傳的文件無法使用。",
      watch_explained_block3_start: "您可以從 ",
      watch_explained_block3_link: "檔案管理器",
      watch_explained_block3_end: " 管理頁面查看及管理追蹤中的文件。",
      accept: "好的，明白了",
    },
    obsidian: {
      vault_location: "Vault 位置",
      vault_description:
        "選擇您的 Obsidian Vault 資料夾以匯入所有筆記及其連結。",
      selected_files: "找到 {{count}} 個 Markdown 檔案",
      importing: "正在匯入 Vault...",
      import_vault: "匯入 Vault",
      processing_time: "這可能需要一段時間，具體取決於您的 Vault 大小。",
      vault_warning: "為避免任何衝突，請確保您的 Obsidian Vault 目前未開啟。",
    },
  },
  chat_window: {
    send_message: "傳送訊息",
    attach_file: "將檔案附加到這段對話",
    text_size: "調整文字大小。",
    microphone: "以語音輸入提示詞。",
    send: "將提示詞送到工作區",
    attachments_processing: "附件正在處理中，請稍後...",
    tts_speak_message: "朗讀訊息",
    copy: "複製",
    regenerate: "重新產生",
    regenerate_response: "重新產生回應",
    good_response: "標記為優質回應",
    more_actions: "更多操作",
    fork: "分支對話",
    delete: "刪除",
    cancel: "取消",
    edit_prompt: "編輯提示詞",
    edit_response: "編輯回應",
    preset_reset_description: "清除聊天紀錄並開始新的聊天",
    add_new_preset: "新增預設",
    command: "指令",
    your_command: "your-command",
    placeholder_prompt: "這段內容會插入在提示詞前方。",
    description: "描述",
    placeholder_description: "回應一首關於 LLM 的詩。",
    save: "儲存",
    small: "小",
    normal: "一般",
    large: "大",
    workspace_llm_manager: {
      search: "搜尋 LLM 提供者",
      loading_workspace_settings: "正在載入工作區設定...",
      available_models: "{{provider}} 可用模型",
      available_models_description: "選擇要在此工作區使用的模型。",
      save: "使用此模型",
      saving: "正在將模型設為工作區預設值...",
      missing_credentials: "此提供者缺少憑證！",
      missing_credentials_description: "點選以設定認證資訊",
    },
    submit: "送出",
    edit_info_user: "「送出」會重新產生 AI 回應。「儲存」只會更新訊息內容。",
    edit_info_assistant: "您的修改將直接儲存到此處。",
    see_less: "顯示較少",
    see_more: "查看更多",
    tools: "工具",
    text_size_label: "文字大小",
    select_model: "選擇模型",
    sources: "來源",
    document: "文件",
    similarity_match: "相符度",
    source_count_one: "{{count}} 筆參考資料",
    source_count_other: "{{count}} 筆參考資料",
    add_new: "新增",
    edit: "編輯",
    publish: "發佈",
    stop_generating: "停止產生回應",
    slash_commands: "斜線指令",
    agent_skills: "智慧代理人技能",
    manage_agent_skills: "管理智慧代理人技能",
    agent_skills_disabled_in_session:
      "啟用智慧代理人工作階段時無法修改技能。請先使用 /exit 指令結束目前工作階段。",
    start_agent_session: "開始智慧代理人工作階段",
    use_agent_session_to_use_tools:
      "若要在對話中使用工具，請在提示詞開頭加上 '@agent'，即可開始智慧代理人工作階段。",
    agent_invocation: {
      model_wants_to_call: "模型想要撥打電話",
      approve: "批准",
      reject: "拒絕",
      always_allow: "請務必確保 {{skillName}}",
      tool_call_was_approved: "工具請求已獲得批准。",
      tool_call_was_rejected: "請求已遭拒絕",
      clarifying_skip: "讓代理決定",
      clarifying_submit: "提交",
      clarifying_skipped: "您可以讓代理人自行決定。",
      clarifying_timeout: "未在規定時間內提交回覆。",
      clarifying_pagination: "{{current}} 在 {{total}}",
      clarifying_prev_aria: "上一問題",
      clarifying_next_aria: "接下來的問題",
      clarifying_close_aria: "關閉和跳過",
      clarifying_other: "其他",
      clarifying_other_placeholder: "請在此處輸入您的答案",
      batch_progress: "{{answered}} 在 {{total}} 的問題已得到解答",
      batch_skip_this: "跳過",
      batch_submit_all: "提交所有",
      batch_next: "接下來",
      answer_skipped: "[使用者跳過]",
    },
    custom_skills: "客製化技能",
    agent_flows: "代理人流",
    no_tools_found: "未找到匹配的工具",
    loading_mcp_servers: "正在載入 MCP 伺服器...",
    app_integrations: "應用程式整合",
    sub_skills: "細項技能",
    memories: {
      title: "回憶",
      empty:
        "目前還沒有相關的回憶。當您與聊天機器人互動後，相關的回憶就會逐漸產生。",
      empty_cta: "創造新的回憶",
      tab_workspace: "工作空間",
      tab_global: "全球",
      toggle: {
        label: "啟用個人化功能",
        description:
          "讓您的助手能夠回憶關於您或這個工作空間的相關資訊，並在對話中使用這些資訊。",
      },
      auto_extraction: {
        label: "自動回憶",
        description: "請讓您的助理自動在背景中建立記憶",
      },
      menu: {
        edit: "編輯",
        delete: "刪除",
        move_to_global: "擴展至全球",
        move_to_workspace: "遷移至工作空間",
      },
      modal: {
        create_title: "建立回憶",
        edit_title: "編輯記憶",
        create_description:
          "回憶應該簡潔明瞭，用單一的陳述來表達。例如：「使用者更偏好 Python 語言，而非 JavaScript 語言」。",
        edit_description: "更新此記憶的內容。",
        label: "記憶",
        placeholder: "例如：使用者姓名為 Joe，使用者正在使用 AnythingLLM 等。",
        create: "創造",
        save: "儲存",
        cancel: "取消",
      },
    },
    stt_unsupported: "本瀏覽器不支援麥克風功能。",
    stt_mic_denied: "無法存取麥克風。請先授權，然後再嘗試。",
    stt_transcription_failed: "轉錄失敗：{{error}}",
    export: "匯出對話內容為…",
    exporting: "出口...",
  },
  profile_settings: {
    edit_account: "編輯帳戶",
    profile_picture: "個人資料圖片",
    remove_profile_picture: "移除個人資料圖片",
    username: "使用者名稱",
    new_password: "新密碼",
    password_description: "密碼長度必須至少為 8 個字元",
    cancel: "取消",
    update_account: "更新帳戶",
    theme: "主題偏好",
    language: "慣用語言",
    failed_upload: "上傳個人資料圖片失敗：{{error}}",
    upload_success: "個人資料圖片已上傳。",
    failed_remove: "移除個人資料圖片失敗：{{error}}",
    profile_updated: "個人資料已更新。",
    failed_update_user: "更新使用者資料失敗：{{error}}",
    account: "帳戶",
    support: "支援",
    signout: "登出",
  },
  customization: {
    interface: {
      title: "介面偏好設定",
      description: "設定 AnythingLLM 的介面偏好。",
    },
    branding: {
      title: "品牌與白標設定",
      description: "透過自訂品牌元素，將 AnythingLLM 白標化。",
    },
    chat: {
      title: "對話",
      description: "設定 AnythingLLM 的對話偏好。",
      auto_submit: {
        title: "語音輸入自動送出",
        description: "在一段靜默後自動送出語音輸入",
      },
      auto_speak: {
        title: "自動語音回應",
        description: "自動朗讀 AI 的回應內容",
      },
      spellcheck: {
        title: "啟用拼字檢查",
        description: "在對話輸入框中啟用或停用拼字檢查",
      },
    },
    items: {
      theme: {
        title: "主題",
        description: "選擇偏好的應用程式色彩主題。",
      },
      "show-scrollbar": {
        title: "顯示捲軸",
        description: "在對話視窗中啟用或停用捲軸。",
      },
      "support-email": {
        title: "支援信箱",
        description: "設定當使用者需要協助時可聯絡的支援電子郵件地址。",
      },
      "app-name": {
        title: "名稱",
        description: "設定顯示在登入頁面、讓所有使用者都看得到的名稱。",
      },
      "display-language": {
        title: "顯示語言",
        description: "選擇 AnythingLLM 介面的顯示語言；若已有翻譯就會套用。",
      },
      logo: {
        title: "品牌標誌",
        description: "上傳自訂標誌，顯示於所有頁面。",
        add: "新增自訂標誌",
        recommended: "建議尺寸：800 x 200",
        remove: "移除",
        replace: "更換",
      },
      "browser-appearance": {
        title: "瀏覽器外觀",
        description: "自訂應用程式在瀏覽器分頁中的外觀與標題。",
        tab: {
          title: "分頁標題",
          description: "當應用程式在瀏覽器中開啟時設定自訂的分頁標題。",
        },
        favicon: {
          title: "網站圖示 (Favicon)",
          description: "為瀏覽器分頁設定自訂網站圖示。",
        },
      },
      "sidebar-footer": {
        title: "側邊欄頁尾項目",
        description: "自訂側邊欄底部顯示的項目。",
        icon: "圖示",
        link: "連結",
      },
      "render-html": {
        title: "在對話中渲染 HTML",
        description:
          "在助理回應中渲染 HTML 內容。\n這能顯著提升呈現精細度，但也可能帶來潛在安全風險。",
      },
    },
  },
  "main-page": {
    quickActions: {
      createAgent: "建立智慧代理人",
      editWorkspace: "編輯工作區",
      uploadDocument: "上傳文件",
    },
    greeting: "今天想做什麼？",
  },
  "keyboard-shortcuts": {
    title: "鍵盤快速鍵",
    shortcuts: {
      settings: "開啟設定",
      workspaceSettings: "開啟目前工作區設定",
      home: "前往首頁",
      workspaces: "管理工作區",
      apiKeys: "API 金鑰設定",
      llmPreferences: "LLM 偏好設定",
      chatSettings: "對話設定",
      help: "顯示快速鍵說明",
      showLLMSelector: "顯示工作區 LLM 選擇器",
    },
  },
  community_hub: {
    publish: {
      system_prompt: {
        success_title: "成功！",
        success_description: "您的系統提示詞已發布到社群中心！",
        success_thank_you: "感謝您分享到社群！",
        view_on_hub: "在社群中心查看",
        modal_title: "發布系統提示詞",
        name_label: "名稱",
        name_description: "這是系統提示詞的顯示名稱。",
        name_placeholder: "我的系統提示詞",
        description_label: "描述",
        description_description: "這是系統提示詞的描述，可用來說明用途。",
        tags_label: "標籤",
        tags_description:
          "標籤用來標示系統提示詞，方便搜尋。可新增多個標籤，最多 5 個，每個標籤最多 20 個字元。",
        tags_placeholder: "輸入並按 Enter 鍵添加標籤",
        visibility_label: "可見範圍",
        public_description: "公開的系統提示詞對所有人都可見。",
        private_description: "私人系統提示詞只有您看得到。",
        publish_button: "發布到社群中心",
        submitting: "發布中...",
        prompt_label: "提示詞",
        prompt_description: "這是實際會用來引導 LLM 的系統提示詞。",
        prompt_placeholder: "在此輸入系統提示詞...",
      },
      agent_flow: {
        success_title: "成功！",
        success_description: "您的代理流程已發布到社群中心！",
        success_thank_you: "感謝您分享到社群！",
        view_on_hub: "在社群中心查看",
        modal_title: "發布代理流程",
        name_label: "名稱",
        name_description: "這是代理流程的顯示名稱。",
        name_placeholder: "我的代理流程",
        description_label: "描述",
        description_description: "這是代理流程的描述，可用來說明用途。",
        tags_label: "標籤",
        tags_description:
          "標籤用來標示代理流程，方便搜尋。可新增多個標籤，最多 5 個，每個標籤最多 20 個字元。",
        tags_placeholder: "輸入並按 Enter 鍵添加標籤",
        visibility_label: "可見範圍",
        submitting: "發布中...",
        submit: "發布到社群中心",
        privacy_note:
          "代理流程一律會先以私人方式上傳，以保護敏感資料。發布後可再到社群中心調整可見範圍。發布前請先確認流程中不含任何敏感或私人資訊。",
      },
      generic: {
        unauthenticated: {
          title: "需要驗證",
          description: "發布項目前，需先完成 AnythingLLM 社群中心驗證。",
          button: "連接到社群中心",
        },
      },
      slash_command: {
        success_title: "成功！",
        success_description: "您的斜線指令已發布到社群中心！",
        success_thank_you: "感謝您分享到社群！",
        view_on_hub: "在社群中心查看",
        modal_title: "發布斜線指令",
        name_label: "名稱",
        name_description: "這是斜線指令的顯示名稱。",
        name_placeholder: "我的斜線指令",
        description_label: "描述",
        description_description: "這是斜線指令的描述，可用來說明用途。",
        tags_label: "標籤",
        tags_description:
          "標籤用來標示斜線指令，方便搜尋。可新增多個標籤，最多 5 個，每個標籤最多 20 個字元。",
        tags_placeholder: "輸入並按 Enter 鍵添加標籤",
        visibility_label: "可見範圍",
        public_description: "公開的斜線指令對所有人都可見。",
        private_description: "私人斜線指令只有您看得到。",
        publish_button: "發布到社群中心",
        submitting: "發布中...",
        prompt_label: "提示詞",
        prompt_description: "這是觸發斜線指令時會使用的提示詞。",
        prompt_placeholder: "在此輸入提示詞...",
      },
    },
  },
  security: {
    title: "安全性設定",
    multiuser: {
      title: "多使用者模式",
      description: "啟用多使用者模式，讓這套系統支援團隊使用。",
      enable: {
        "is-enable": "多使用者模式已啟用",
        enable: "啟用多使用者模式",
        description:
          "預設只有您具備管理員權限。身為管理員，您需要為所有新使用者或管理員建立帳號。請勿遺失密碼，因為只有管理員可以重設密碼。",
        username: "管理員帳號使用者名稱",
        password: "管理員帳號密碼",
      },
    },
    password: {
      title: "密碼保護",
      description:
        "使用密碼保護 AnythingLLM 系統。若忘記此密碼，將無法復原，請務必妥善保存。",
      "password-label": "系統密碼",
    },
  },
  home: {
    welcome: "歡迎",
    chooseWorkspace: "選擇一個工作區開始對話！",
    notAssigned:
      "您目前尚未被分配到任何工作區。\n請聯絡您的管理員以申請工作區的存取權限。",
    goToWorkspace: '前往 "{{workspace}}"',
  },
  telegram: {
    title: "Telegram 機器人",
    description:
      "將您的 AnythingLLM 實例連接到 Telegram，以便您可以在任何裝置上與您的工作空間進行對話。",
    setup: {
      step1: {
        title: "第一步：建立您的 Telegram 機器人",
        description:
          '在 Telegram 中開啟 @BotFather，將 "<code>/newbot" 訊息發送至 <code>@BotFather</code>，按照指示操作，並複製 API 令牌。',
        "open-botfather": "開啟 BotFather",
        "instruction-1": "1. 點擊連結或掃描 QR 碼",
        "instruction-2":
          "2. 將 <code>/newbot</code> 傳送至 <code>@BotFather</code>",
        "instruction-3": "3. 為您的機器人選擇一個名稱和使用者名稱。",
        "instruction-4": "4. 複製您收到的 API 令牌",
      },
      step2: {
        title: "步驟 2：連接您的機器人",
        description:
          "請將您從 @BotFather 處獲得的 API 令牌複製並貼上，然後選擇一個預設的工作空間，讓您的機器人與其對話。",
        "bot-token": "機器人代幣",
        connecting: "正在連接...",
        "connect-bot": "連線機器人",
      },
      security: {
        title: "建議的安全設定",
        description: "為了額外保障，請在 @BotFather 中設定這些選項。",
        "disable-groups": "— 阻止自動程式加入群組",
        "disable-inline": "— 阻止機器人被用於內嵌式搜尋",
        "obscure-username":
          "使用一個不顯眼的機器人帳號名稱，以降低被發現的機會。",
      },
      "toast-enter-token": "請輸入機器人憑證。",
      "toast-connect-failed": "無法連接機器人。",
    },
    connected: {
      status: "連接",
      "status-disconnected": "無法連接 — 可能是 token 已經過期或無效",
      "placeholder-token": "黏貼新的機器人代碼...",
      reconnect: "重新建立聯繫",
      workspace: "工作空間",
      "bot-link": "機器人連結",
      "voice-response": "語音回應",
      disconnecting: "斷線...",
      disconnect: "斷開連接",
      "voice-text-only": "僅提供文字",
      "voice-mirror": "語音回覆 (使用者發送語音時，系統會回覆語音)",
      "voice-always": "請務必在回覆中加入語音 (發送音訊)。",
      "toast-disconnect-failed": "未能成功斷開機器人。",
      "toast-reconnect-failed": "無法重新連線機器人。",
      "toast-voice-failed": "無法更新語音模式。",
      "toast-approve-failed": "無法驗證使用者。",
      "toast-deny-failed": "未能阻止使用者。",
      "toast-revoke-failed": "未能取消使用者權限。",
    },
    users: {
      "pending-description":
        "等待驗證的使用者。請將這裡顯示的配對碼與他們在 Telegram 聊天中顯示的配對碼對齊。",
      unknown: "未知的",
    },
  },
  scheduledJobs: {
    title: "預約排定的工作",
    enableNotifications: "啟用瀏覽器通知，以便收到工作結果",
    description:
      "建立可重複執行的 AI 任務，並設定執行時間表。每個任務會執行一個指令，並可選地使用工具，然後將結果儲存以供後續檢閱。",
    newJob: "新的工作",
    loading: "載入中...",
    emptyTitle: "目前沒有預約的任務",
    emptySubtitle: "先從一個開始。",
    table: {
      name: "姓名",
      schedule: "時間表",
      status: "狀態",
      lastRun: "最後一次",
      nextRun: "下一次活動",
      actions: "行動",
    },
    confirmDelete: "您確定要刪除這個預約的任務嗎？",
    toast: {
      deleted: "已刪除",
      triggered: "工作已成功啟動",
      triggerFailed: "未能觸發工作",
      triggerSkipped: "目前，這個項目已經啟動。",
      killed: "工作已成功停止",
      killFailed: "未能成功終止工作",
    },
    row: {
      neverRun: "請勿急於完成",
      viewRuns: "觀看次數",
      runNow: "現在就開始行動",
      enable: "啟用",
      disable: "停用",
      edit: "編輯",
      delete: "刪除",
    },
    modal: {
      titleEdit: "編輯排程工作",
      titleNew: "新的排程工作",
      nameLabel: "姓名",
      namePlaceholder: "例如：每日新聞摘要",
      promptLabel: "提示",
      promptPlaceholder: "指示內容為：在每次執行時執行...",
      scheduleLabel: "時間表",
      modeBuilder: "建築師",
      modeCustom: "客製化",
      cronPlaceholder: "Cron 運算式（例如：0 9 * * *）",
      currentSchedule: "目前時間表：",
      toolsLabel: "工具（可選）",
      toolsDescription:
        "請選擇此工作可以使用的工具。如果沒有選擇任何工具，則工作將不使用任何工具。",
      toolsSearch: "搜尋",
      toolsNoResults: "沒有任何工具符合",
      required: "必需",
      requiredFieldsBanner: "請務必填寫所有必要欄位，以便建立工作。",
      cancel: "取消",
      saving: "儲存...",
      updateJob: "更新工作",
      createJob: "建立工作",
      jobUpdated: "工作資訊已更新",
      jobCreated: "已創建工作",
    },
    builder: {
      fallbackWarning:
        "這個表達方式無法透過視覺編輯來修改。請選擇「自訂」選項來保留它，或修改以下內容以覆蓋它。",
      run: "跑步",
      frequency: {
        minute: "每分鐘",
        hour: "每小時",
        day: "每天",
        week: "每週",
        month: "每月",
      },
      every: "每一個",
      minuteOne: "1 分鐘",
      minuteOther: "{{count}} 分鐘",
      atMinute: "每分鐘",
      pastEveryHour: "過去每小時",
      at: "在",
      on: "關於",
      onDay: "在某一天",
      ofEveryMonth: "每個月",
      weekdays: {
        sun: "太陽",
        mon: "星期一",
        tue: "週二",
        wed: "星期三",
        thu: "星期四",
        fri: "週五",
        sat: "星期六",
      },
    },
    runHistory: {
      back: "返回工作機會",
      title: "運行歷史：{{name}}",
      schedule: "時間表：",
      emptyTitle: "目前這個工作尚未有任何進展。",
      emptySubtitle: "現在執行此任務，並查看結果。",
      runNow: "立即行動",
      table: {
        status: "狀態",
        started: "開始",
        duration: "時間",
        error: "錯誤",
      },
      stopJob: "停止工作",
    },
    runDetail: {
      loading: "載入執行記錄詳細...",
      notFound: "未找到程式。",
      back: "返回",
      unknownJob: "未知的職位",
      runHeading: "{{name}} — 執行 #{{id}}",
      duration: "時間：{{value}}",
      creating: "創作...",
      threadFailed: "未能建立執行緒",
      sections: {
        prompt: "提示",
        error: "錯誤",
        thinking: "想法 ({{count}})",
        toolCalls: "工具呼叫 ({{count}})",
        files: "檔案 ({{count}})",
        response: "回覆",
        metrics: "指標",
      },
      metrics: {
        promptTokens: "提示詞：",
        completionTokens: "完成標記：",
      },
      stopJob: "停止工作",
      killing: "停止...",
      continueInThread: "繼續聊天",
    },
    toolCall: {
      arguments: "論點：",
      showResult: "顯示結果",
      hideResult: "隱藏結果",
    },
    file: {
      unknown: "未知的檔案",
      download: "下載",
      downloadFailed: "無法下載檔案",
      types: {
        powerpoint: "PowerPoint",
        pdf: "PDF 文件",
        word: "Word 檔案",
        spreadsheet: "電子表格",
        generic: "檔案",
      },
    },
    status: {
      completed: "已完成",
      failed: "失敗",
      timed_out: "時間到",
      running: "跑步",
      queued: "排隊",
    },
  },
  "model-router": {
    title: "模型路由器",
    description:
      "模型路由器讓您能夠定義規則，根據特定條件自動將聊天訊息路由到不同的 LLM 供應商和模型。",
    table: {
      name: "姓名",
      fallback: "備用方案",
      rules: "規則",
      workspaces: "工作空間",
    },
    "no-routers": "目前還沒有推出任何型號的路由器。",
    "empty-description": "目前尚未設定任何路由器。請先建立一個，以便開始使用。",
    "new-router-button": "新的路由器",
    "delete-confirm":
      '您確定要刪除路由器 "{{name}}" 嗎？\n這將會刪除所有相關規則，並斷開使用該路由器的所有工作空間。\n\n此操作不可撤銷。',
    "toast-deleted": "路由器已刪除",
    "toast-delete-failed": "無法刪除路由器：{{error}}",
    "new-router": {
      title: "建立新的路由器",
      name: "姓名",
      "name-placeholder": "例如：成本優化器",
      description: "描述",
      "description-placeholder": "可選說明",
      "fallback-label": "主要供應商及模型",
      "fallback-description":
        "當沒有任何路由規則符合時，也會使用此方法。此外，也可用於評估由大型語言模型（LLM）分類的規則。",
      "cooldown-label": "緩存冷卻時間 (秒)",
      "cooldown-help":
        "路由決策在重新評估規則之前，會被暫存多長時間？將此設定設為 0 則會停用暫存功能。",
      "name-required": "請提供您的姓名。",
      "fallback-required": "需要提供主要供應商和模型資訊。",
      cancel: "取消",
      create: "建立路由器",
    },
    "edit-router": {
      "back-to-routers": "返回：網路路由器",
      title: "編輯路由器：{{name}}",
      save: "儲存變更",
      "toast-update-failed": "無法更新路由器",
    },
    rules: {
      title: "路由規則",
      "title-with-name": "路由規則：{{name}}",
      description: "明確說明哪些規則決定聊天訊息應該發送給哪些供應商和模型。",
      "add-rule": "新增規則",
      "delete-confirm": '刪除規則 "{{title}}"？',
      "toast-delete-failed": "刪除規則失敗",
      "toast-reorder-failed": "未能重新建立規則",
      "no-rules": "目前還沒有任何規則。",
      "empty-description": "新增規則，以便將聊天訊息路由到特定的供應商和模型。",
      "new-rule-button": "新規定",
      "calculated-section-label": "預先設定的規則 — 依照優先順序進行評估",
      "llm-section-label": "LLM 規則：若沒有任何規則符合計算結果，則判定為一組",
      "llm-rule-body":
        "執行 <desc>「{{description}}」</desc>，然後將其路由到 <route>{{route}}</route>",
      "calculated-no-conditions":
        "沒有任何限制 — 路線為 <route>{{route}}</route>",
      "calculated-single-condition":
        "如果符合 <prop>、{{property}}、</prop> 的條件，則前往 {{comparator}}、<val>、「{{value}}」、</val>，然後前往 <route>、{{route}}、</route>。",
      "calculated-multi-condition":
        "如果 {{quantifier}} 符合 <cond> 的條件，則將路線設定為 </cond>{{route}}</route>",
      "comparator-contains": "包含",
      "comparator-matches": "比賽",
      "comparator-between": "之間",
      "badge-llm": "大型語言模型",
      "badge-calculated": "計算出來",
      "aria-drag-to-reorder": "拖動以重新排序",
      "aria-edit-rule": "編輯規則",
      "aria-delete-rule": "刪除規則",
      "quantifier-any": "任何",
      "quantifier-all": "全部",
    },
    "rule-form": {
      "title-label": "標題",
      "rule-type": "規則類型",
      "property-label": "房產",
      "property-select": "選擇",
      "comparator-label": "比較器",
      "comparator-select": "選擇",
      "value-label": "價值",
      "add-condition": "添加條件",
      "remove-condition": "移除條件",
      "conditions-incomplete":
        "條件 {{index}} 尚未完成 — 請填寫「屬性」、「比較器」和「值」。",
      "match-description-label": "比賽描述",
      "match-description-placeholder":
        "例如，使用者詢問的是法律相關議題、合約或合規性等方面",
      "match-description-help":
        "說明您希望此規則適用於哪些情況。您的 LLM 將評估這些情況，以判斷是否應該使用該規則。",
      "route-to-label": "前往服務提供者及模型",
      "route-to-description": "當此規則成立時，請使用此供應商/模型。",
      cancel: "取消",
      saving: "儲存...",
      "update-rule": "更新規則",
      "create-rule": "建立規則",
      "title-required": "標題必填",
      "toast-save-failed": "未能儲存規則",
      "type-calculated-label": "計算得出",
      "type-calculated-description":
        "根據訊息的屬性，例如內容、字數或發送時間，進行比對。",
      "type-llm-label": "LLM 類別",
      "type-llm-description":
        "利用大型語言模型，根據您提供的描述，對訊息進行分類。",
      "prop-prompt-content": "提示內容",
      "prop-token-count": "對話 Token 數量",
      "prop-message-count": "對話訊息數量",
      "prop-current-hour": "當前時間 (0-23)",
      "prop-has-image": "是否包含圖片",
      "cmp-contains": "包含",
      "cmp-matches-regex": "匹配 (正規表達式)",
      "cmp-equals": "等於",
      "cmp-not-equals": "不等於",
      "cmp-greater-than": "超過",
      "cmp-greater-than-or-equal": "大於或等於",
      "cmp-less-than": "少於",
      "cmp-less-than-or-equal": "小於或等於",
      "cmp-between": "包含（包括）",
      "placeholder-between-hour": "例如：9:00-17:00",
      "placeholder-between-numeric": "例如：10.50",
      "placeholder-hour": "例如：18 (0-23)",
      "placeholder-message-count": "例如：10",
      "placeholder-numeric": "例如：4000",
      "placeholder-contains": "例如：程式碼、Python、Rust",
      "placeholder-matches": "例如：/\\bpython\\b/i",
      "placeholder-default": "例如：程式碼",
      "help-contains":
        "以逗號分隔的列表 — 如果提示包含任何這些值（不區分大小寫），則匹配。",
      "help-matches":
        "正規表示式模式。使用 `/模式/旗標` 進行大小寫區分 (預設為不區分大小寫)。",
      "bool-true": "正確",
      "bool-false": "錯誤",
    },
    "provider-picker": {
      "select-provider": "選擇供應商",
      "setup-required": "（需要進行設定）",
      "loading-models": "正在載入模型...",
      "select-model": "選擇模型",
      "enter-model": "請輸入模型名稱",
      "select-provider-first": "首先選擇一個供應商",
      "configure-to-continue": "設定 {{name}} 以繼續執行",
      "configure-provider": "設定 {{name}}",
      "setup-credentials": "請輸入必要的憑證，以便使用 {{name}} 作為路由目標。",
      cancel: "取消",
      "save-settings": "儲存設定",
      "toast-save-failed": "無法儲存設定：{{error}}",
    },
    "router-selection": {
      "loading-routers": "正在載入自定義路由器...",
      "no-routers-prefix-settings": "目前尚未設定任何路由器模型。",
      "no-routers-prefix-workspace": "沒有設定任何路由器。",
      "no-routers-link": "在模型路由器設定中建立一個",
      "model-router-label": "模型路由器",
      "select-router": "選擇一個路由器",
      "select-description": "請選擇用於此工作空間的路由器。",
      "no-routers-chat":
        "目前沒有設定任何路由器。請前往「設定」>「AI 提供者」>「模型路由器」處建立一個。",
      "rule-count": "({{count}} 規則)",
    },
    metrics: {
      "model-router-default": "模型路由器",
    },
    chat: {
      "select-router-error": "選擇一個路由器",
      "invalid-model": "模型選擇無效",
      "routed-to": "已路由至 <route>{{model}}</route>",
      "routed-to-rule":
        "經由 <route> {{model}} </route>，並通過 <rule> {{ruleTitle}} </rule> 進行。",
    },
  },
};

export default TRANSLATIONS;
