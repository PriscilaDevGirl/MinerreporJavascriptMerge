// moment.js language configuration
// language : romanian (ro)
// author : Vlad Gurdiga : https://github.com/gurdiga
// author : Valentin Agachi : https://github.com/avaly
(function () {
    var lang = {
            months : "Ianuarie_Februarie_Martie_Aprilie_Mai_Iunie_Iulie_August_Septembrie_Octombrie_Noiembrie_Decembrie".split("_"),
            monthsShort : "Ian_Feb_Mar_Apr_Mai_Iun_Iul_Aug_Sep_Oct_Noi_Dec".split("_"),
            weekdays : "Duminică_Luni_Marţi_Miercuri_Joi_Vineri_Sâmbătă".split("_"),
            weekdaysShort : "Dum_Lun_Mar_Mie_Joi_Vin_Sâm".split("_"),
            weekdaysMin : "Du_Lu_Ma_Mi_Jo_Vi_Sâ".split("_"),
            longDateFormat : {
                LT : "H:mm",
                L : "DD/MM/YYYY",
                LL : "D MMMM YYYY",
                LLL : "D MMMM YYYY H:mm",
                LLLL : "dddd, D MMMM YYYY H:mm"
            },
            calendar : {
                sameDay: "[azi la] LT",
                nextDay: '[mâine la] LT',
                nextWeek: 'dddd [la] LT',
                lastDay: '[ieri la] LT',
                lastWeek: '[fosta] dddd [la] LT',
                sameElse: 'L'
            },
            relativeTime : {
                future : "peste %s",
                past : "%s în urmă",
                s : "câteva secunde",
                m : "un minut",
                mm : "%d minute",
                h : "o oră",
                hh : "%d ore",
                d : "o zi",
                dd : "%d zile",
                M : "o lună",
                MM : "%d luni",
                y : "un an",
                yy : "%d ani"
            },
            ordinal : function (number) {
                return '';
            },
            week : {
                dow : 1, // Monday is the first day of the week.
                doy : 7  // The week that contains Jan 1st is the first week of the year.
            }
        };

    // Node
    if (typeof module !== 'undefined') {
        module.exports = lang;
    }
    // Browser
    if (typeof window !== 'undefined' && this.moment && this.moment.lang) {
        this.moment.lang('ro', lang);
    }
}());
